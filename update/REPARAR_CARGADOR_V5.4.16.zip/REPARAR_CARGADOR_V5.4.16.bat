@echo off
setlocal
set "DEST=%LOCALAPPDATA%\CargadorFacturasAutosur\App"
if not exist "%DEST%" (
  echo No se encontro la instalacion del Cargador de Facturas Autosur.
  pause
  exit /b 1
)
copy /Y "%DEST%\pagos_rivadavia.py" "%DEST%\pagos_rivadavia.py.v5.4.15_danado" >nul 2>&1
copy /Y "%~dp0pagos_rivadavia.py" "%DEST%\pagos_rivadavia.py" >nul
if errorlevel 1 goto ERROR
copy /Y "%~dp0version.txt" "%DEST%\version.txt" >nul
if errorlevel 1 goto ERROR
echo.
echo Reparacion V5.4.16 completada correctamente.
echo Ya puede abrir Cargador de Facturas Autosur desde el acceso directo.
pause
exit /b 0
:ERROR
echo.
echo No se pudo completar la reparacion. Cierre la aplicacion y ejecute este archivo nuevamente.
pause
exit /b 1
