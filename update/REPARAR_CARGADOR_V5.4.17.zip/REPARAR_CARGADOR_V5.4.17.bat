@echo off
setlocal
set "DEST=%LOCALAPPDATA%\CargadorFacturasAutosur\App"
if not exist "%DEST%" (
 echo No se encontro la instalacion.
 pause
 exit /b 1
)
copy /Y "%DEST%\pagos_rivadavia.py" "%DEST%\pagos_rivadavia.py.antes_v5.4.17" >nul 2>&1
copy /Y "%~dp0pagos_rivadavia.py" "%DEST%\pagos_rivadavia.py" >nul
if errorlevel 1 goto ERROR
copy /Y "%~dp0version.txt" "%DEST%\version.txt" >nul
if errorlevel 1 goto ERROR
echo.
echo Reparacion V5.4.17 completada.
echo Abra nuevamente Cargador de Facturas Autosur.
pause
exit /b 0
:ERROR
echo Cierre la aplicacion y vuelva a ejecutar este reparador.
pause
exit /b 1
