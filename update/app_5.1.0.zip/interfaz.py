import html
import os
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# El Python embebido de Windows no incluye automáticamente la carpeta del
# script en sys.path. Se agrega antes de importar los módulos del cargador.
APP_SOURCE_DIR = Path(__file__).resolve().parent
if str(APP_SOURCE_DIR) not in sys.path:
    sys.path.insert(0, str(APP_SOURCE_DIR))

import interfaz_rivadavia
import interfaz_san_cristobal


RIVADAVIA_FOLDER = Path(r"T:\SHAR-REN\JUAN AMARANTE\factura\rivadavia")
SAN_CRISTOBAL_FOLDER = Path(r"T:\SHAR-REN\JUAN AMARANTE\factura\san cristobal")
APP_VERSION = "5.1.0"
UPDATER_PATH = APP_SOURCE_DIR.parent / "actualizador.py"


STYLE = """
:root{font-family:Segoe UI,Arial,sans-serif;color:#172033;background:#eef3f8}*{box-sizing:border-box}body{margin:0}
.top{background:#14233d;color:white;padding:28px}.top h1{margin:0;font-size:28px}.top p{margin:7px 0 0;opacity:.82}
.wrap{max-width:1050px;margin:36px auto;padding:0 20px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:20px}
.card{background:white;border-radius:16px;padding:24px;box-shadow:0 6px 24px #15314e18;border-top:5px solid #0875c9}.card.sc{border-color:#4145e7}.card h2{margin:0 0 8px}.card p{color:#5d697a;min-height:48px}.path{font:12px Consolas,monospace;background:#f4f6f9;padding:10px;border-radius:8px;overflow-wrap:anywhere}.button{display:inline-block;margin-top:18px;padding:12px 20px;border-radius:9px;background:#0875c9;color:white;text-decoration:none;font-weight:700}.sc .button{background:#4145e7}.disabled{display:inline-block;margin-top:18px;padding:12px 20px;border-radius:9px;background:#ccd2da;color:#69717c;font-weight:700}.note{margin-top:25px;padding:15px;background:#fff7d8;border-left:4px solid #e8aa21;border-radius:8px;color:#674d11}.update{display:inline-block;margin-top:18px;margin-left:10px;padding:12px 20px;border-radius:9px;background:#1d9a66;color:white;text-decoration:none;font-weight:700}
"""


class HomeHandler(BaseHTTPRequestHandler):
    ports = {}

    def log_message(self, _format, *_args):
        pass

    def do_GET(self):
        if self.path.startswith("/actualizar"):
            self.start_update()
            return
        cards = []
        platforms = [
            ("rivadavia", "Seguros Rivadavia", RIVADAVIA_FOLDER, "Motor estable V4.12 para Google Forms.", ""),
            ("san", "San Cristóbal", SAN_CRISTOBAL_FOLDER, "Carga por portal, credenciales cifradas y control por lote.", "sc"),
        ]
        for key, title, folder, description, css in platforms:
            port = self.ports.get(key)
            action = f'<a class="button" href="http://127.0.0.1:{port}/">Abrir cargador</a>' if port else '<span class="disabled">Carpeta no disponible</span>'
            cards.append(f'<div class="card {css}"><h2>{html.escape(title)}</h2><p>{html.escape(description)}</p><div class="path">{html.escape(str(folder))}</div>{action}</div>')
        update_button = '<a class="update" href="/actualizar">Buscar actualizaciones</a>' if UPDATER_PATH.exists() else ""
        page = f"""<!doctype html><html><head><meta charset="utf-8"><title>Cargador de facturas Autosur V{APP_VERSION}</title><style>{STYLE}</style></head><body>
        <div class="top"><h1>Cargador de facturas Autosur V{APP_VERSION}</h1><p>Elegí la aseguradora. Cada plataforma mantiene su propio registro de enviados.</p></div>
        <div class="wrap"><div class="grid">{''.join(cards)}</div><div class="note">Primero utilizá <b>Probar primera sin enviar</b>. Cuando confirmes que todos los datos están correctos, continuá con el lote.</div>{update_button}</div></body></html>""".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def start_update(self):
        if not UPDATER_PATH.exists():
            page = b"El actualizador no esta instalado."
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(page)))
            self.end_headers()
            self.wfile.write(page)
            return
        page = """<!doctype html><meta charset="utf-8"><style>body{font:18px Segoe UI;padding:40px;background:#eef3f8;color:#172033}</style><h2>Buscando actualizaciones...</h2><p>La aplicación se cerrará y volverá a abrir automáticamente.</p>""".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

        def restart_with_updater():
            time.sleep(1)
            subprocess.Popen(
                [sys.executable, str(UPDATER_PATH), "--force", "--wait-pid", str(os.getpid())],
                cwd=str(UPDATER_PATH.parent),
            )
            time.sleep(0.5)
            os._exit(0)

        threading.Thread(target=restart_with_updater, daemon=True).start()


def serve(server):
    threading.Thread(target=server.serve_forever, daemon=True).start()


def main():
    home = ThreadingHTTPServer(("127.0.0.1", 0), HomeHandler)
    home_port = home.server_port
    ports = {}

    if RIVADAVIA_FOLDER.exists():
        state = interfaz_rivadavia.AppState(RIVADAVIA_FOLDER)
        interfaz_rivadavia.HOME_PORT = home_port
        server = ThreadingHTTPServer(("127.0.0.1", 0), interfaz_rivadavia.handler_for(state))
        ports["rivadavia"] = server.server_port
        serve(server)

    if SAN_CRISTOBAL_FOLDER.exists():
        state = interfaz_san_cristobal.AppState(SAN_CRISTOBAL_FOLDER)
        server = ThreadingHTTPServer(("127.0.0.1", 0), interfaz_san_cristobal.handler_for(state, home_port))
        ports["san"] = server.server_port
        serve(server)

    HomeHandler.ports = ports
    url = f"http://127.0.0.1:{home_port}/"
    webbrowser.open(url)
    interfaz_rivadavia.cargador.messagebox.showinfo(
        "Cargador de facturas Autosur",
        "Se abrió el panel de plataformas.\n\nNo cierres esta ventana negra mientras estés trabajando.",
    )
    home.serve_forever()


if __name__ == "__main__":
    main()

