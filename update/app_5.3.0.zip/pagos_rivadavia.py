"""Consulta de solo lectura: nunca marca cheques como recibidos."""
import base64
import io
import json
import os
import re
import tempfile
import time
from pathlib import Path
from urllib.parse import urljoin, urlparse
import urllib.request
import fitz
from selenium import webdriver
from selenium.common.exceptions import StaleElementReferenceException, NoSuchFrameException, ElementClickInterceptedException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait

LOGIN = 'https://www.sistemas.segurosrivadavia.com/sistemas/login/login.php?u=B'
DEFAULT_FOLDER = r'C:\Users\Usuario\Desktop\pagos rivadavia'

def no_payments(text):
    text = ' '.join(text.lower().split())
    return 'no existen pagos para el comprobante' in text

def invoices(text):
    result = []
    for line in text.splitlines():
        if not line.strip():
            continue
        m = re.fullmatch(r'\s*(\d{1,5})\s*[-;/\t]\s*(\d{1,8})\s*', line)
        if not m:
            raise ValueError('Factura inválida: ' + line + '. Usá punto-número, una por línea.')
        value = m[1].zfill(4) + '-' + m[2].zfill(8)
        if value not in result:
            result.append(value)
    if not result:
        raise ValueError('Ingresá al menos una factura.')
    return result

def screenshot_pdf(png):
    doc = fitz.open()
    image = fitz.open(stream=png, filetype='png')
    rect = image[0].rect
    # A4 horizontal; divide capturas altas en páginas sin reducir la letra.
    width, height, margin = 842, 595, 24
    scale = (width - 2 * margin) / rect.width
    slice_height = (height - 2 * margin) / scale
    y = 0
    while y < rect.height:
        clip = fitz.Rect(0, y, rect.width, min(rect.height, y + slice_height))
        pix = image[0].get_pixmap(clip=clip)
        page = doc.new_page(width=width, height=height)
        page.insert_image(fitz.Rect(margin, margin, width-margin, margin+clip.height*scale), stream=pix.tobytes('png'))
        y += slice_height
    image.close()
    return doc

def combined_pdf(destination, captures, retentions):
    doc=fitz.open()
    page=None
    y=24
    width,height,margin=842,595,24
    def new_page():
        return doc.new_page(width=width,height=height)
    def draw(raw):
        nonlocal page,y
        im=fitz.open(stream=raw,filetype='png')
        h=im[0].rect.height*(width-2*margin)/im[0].rect.width
        if h>height-2*margin:
            raise ValueError('Una fila supera el alto imprimible; requiere revisión para no cortar datos.')
        if page is None or y+h>height-margin:
            page=new_page();y=margin
        page.insert_image(fitz.Rect(margin,y,width-margin,y+h),stream=raw)
        y+=h
        im.close()
    for capture in captures:
        if not isinstance(capture,dict):
            draw(capture);y+=12;continue
        header=capture['header']
        def image_height(raw):
            im=fitz.open(stream=raw,filetype='png');r=im[0].rect;im.close()
            return r.height*(width-2*margin)/r.width
        hh=image_height(header)
        first=image_height(capture['rows'][0]) if capture['rows'] else 0
        if page is None or y+26+hh+first>height-margin:
            page=new_page();y=margin
        page.insert_text((margin,y+12),capture['title'],fontsize=11);y+=22
        draw(header)
        for raw in capture['rows']:
            rh=image_height(raw)
            if y+rh>height-margin:
                page=new_page();y=margin
                if hh+rh>height-2*margin:raise ValueError('Fila demasiado alta para imprimir completa.')
                draw(header)
            draw(raw)
        y+=16
    for raw in retentions:
        part=fitz.open(stream=raw,filetype='pdf')
        if part.needs_pass and not part.authenticate(''):
            raise ValueError('La retención requiere contraseña.')
        doc.insert_pdf(part);part.close()
    if not doc.page_count:raise ValueError('No hay páginas para guardar.')
    destination=Path(destination);temp=destination.with_suffix('.tmp.pdf')
    try:
        doc.save(temp,garbage=4,deflate=True);doc.close()
        with fitz.open(temp) as check:
            if not check.page_count:raise ValueError('PDF vacío.')
        os.replace(temp,destination)
    finally:temp.unlink(missing_ok=True)


def aligned_cell(cells, header_rect):
    center=header_rect['x']+header_rect['width']/2
    matches=[]
    for cell in cells:
        rect=cell.rect
        if rect['width']>0 and rect['x']-1 <= center <= rect['x']+rect['width']+1:
            matches.append(cell)
    if len(matches)!=1:
        raise RuntimeError('No se pudo alinear la celda con su encabezado. No se abrió ningún importe.')
    return matches[0]

class Portal:
    def __init__(self, stopped, status):
        self.stopped, self.status = stopped, status
        options = webdriver.ChromeOptions()
        options.add_experimental_option('prefs', {'credentials_enable_service': False, 'profile.password_manager_enabled': False})
        self.driver = webdriver.Chrome(options=options)
        self.driver.set_window_size(1440, 1000)
        self.driver.set_page_load_timeout(60)
    def check(self):
        if self.stopped.is_set():
            raise InterruptedError('Búsqueda detenida.')
    def find_context(self, predicate):
        d = self.driver
        d.switch_to.default_content()
        def visit(depth):
            value = predicate()
            if value:
                return value
            if depth > 5:
                return None
            frames = d.find_elements(By.CSS_SELECTOR, 'frame,iframe')
            for frame in frames:
                d.switch_to.frame(frame)
                value = visit(depth+1)
                if value:
                    return value
                d.switch_to.parent_frame()
            return None
        return visit(0)
    def wait(self, predicate, seconds=45):
        def poll(_):
            self.check()
            try:
                return self.find_context(predicate)
            except (StaleElementReferenceException, NoSuchFrameException, ElementClickInterceptedException):
                self.driver.switch_to.default_content()
                return False
        return WebDriverWait(self.driver, seconds).until(poll)
    def links(self, text):
        return next((e for e in self.driver.find_elements(By.CSS_SELECTOR, 'a,button,input[type=submit],input[type=button]') if e.is_displayed() and (e.text.strip() or e.get_attribute('value') or '').lower() == text.lower()), None)
    def click(self, text):
        self.wait(lambda: self._click_found(self.links(text)))
    @staticmethod
    def _click_found(element):
        if element is None:
            return False
        if not element.is_displayed() or not element.is_enabled():
            return False
        element.click()
        return True

    def login(self, user, cuit, password):
        self.driver.get(LOGIN)
        for key, value in [('usuario', user), ('cuit', re.sub(r'\D','',cuit)), ('password', password)]:
            element = self.driver.find_element(By.ID, key)
            element.clear()
            element.send_keys(value)
        self.wait(lambda: self._click_found(next(iter(self.driver.find_elements(By.ID, 'btn_ingresar')), None)), 120)
        self.status('Accediendo. Si aparece una validación, completala en Chrome; sigo esperando.')
        submitted_tokens = set()
        def access_ready():
            link = next((e for e in self.driver.find_elements(By.TAG_NAME,'a') if 'Consulta Gral. de Pagos' in e.text),None)
            if link:
                self.status('Ingreso confirmado. Continuando búsqueda.')
                return link
            # Solo observa la respuesta que generó la resolución manual.
            tokens = self.driver.find_elements(By.CSS_SELECTOR, 'textarea[name="g-recaptcha-response"],textarea[name="h-captcha-response"],input[name="cf-turnstile-response"]')
            for element in tokens:
                token = element.get_attribute('value') or ''
                if token and token not in submitted_tokens:
                    buttons = self.driver.find_elements(By.ID, 'btn_ingresar')
                    if buttons and buttons[0].is_displayed():
                        buttons[0].click()
                        submitted_tokens.add(token)
                    break
            return False
        self.status('Esperando ingreso. Si aparece CAPTCHA, resolvelo en Chrome; continuaré automáticamente (hasta 10 minutos).')
        self.wait(access_ready, 600)
    def search(self, invoice):
        for attempt in range(3):
            try:
                return self._search_once(invoice)
            except (StaleElementReferenceException, NoSuchFrameException, ElementClickInterceptedException):
                if attempt == 2:
                    raise RuntimeError("El portal cambió de pantalla repetidamente. Reintentá la factura.") from None
                self.status("El portal renovó la página. Reintentando consulta " + str(attempt+1) + "/2...")
                self.driver.switch_to.default_content()
        return []

    def _search_once(self, invoice):
        # Reabre la consulta por su enlace; nunca utiliza Marcar recibidos.
        link = self.wait(lambda: next((e for e in self.driver.find_elements(By.TAG_NAME,'a') if 'Consulta Gral. de Pagos' in e.text),None))
        link.click()
        def form():
            for e in self.driver.find_elements(By.TAG_NAME,'select'):
                if e.is_displayed() and any(o.text.strip()=='Factura' for o in Select(e).options):
                    return e
        select = self.wait(form)
        Select(select).select_by_visible_text('Factura')
        self.wait(lambda: form() if form() and Select(form()).first_selected_option.text.strip() == 'Factura' else False)
        select = self.wait(form)
        row = select.find_element(By.XPATH, './ancestor::*[.//input[not(@type="hidden")]][1]')
        fields = [e for e in row.find_elements(By.TAG_NAME,'input') if e.is_displayed() and (e.get_attribute('type') or 'text') in ('text','number','tel')]
        if len(fields) != 2:
            raise RuntimeError('No se identificaron de forma inequívoca los dos campos de factura.')
        for field, value in zip(fields, invoice.split('-')):
            field.clear(); field.send_keys(value)
        self.click('Aplicar')
        def result_ready():
            body = self.driver.find_element(By.TAG_NAME,'body').text.lower()
            if no_payments(body):
                return 'NO_PAYMENTS'
            return self.links('Consulta') or ('sin resultados' in body) or ('no se encontraron' in body)
        outcome = self.wait(result_ready)
        if outcome == 'NO_PAYMENTS':
            self.click('Aceptar')
            self.wait(lambda: not no_payments(self.driver.find_element(By.TAG_NAME,'body').text))
            self.status('Sin pago encontrado. Continuando con la próxima factura.')
            return []
        body = self.driver.find_element(By.TAG_NAME,'body').text
        if not self.links('Consulta'):
            return []
        # Captura la pantalla completa, incluidos resultados debajo del pliegue.
        if re.search(r'Página\s+\d+\s*/\s*(?:[2-9]|[1-9]\d+)\b', body):
            raise RuntimeError('Hay varias páginas de pagos; requiere revisión manual en esta primera versión.')
        # La lista inicial solo filtra la factura: no se imprime.
        rows = self.payment_links()
        results_url = self.driver.current_url
        saved = []
        for index in range(len(rows)):
            self.check()
            links = self.payment_links()
            links[index].click()
            self.wait(lambda: 'Retención' in self.driver.find_element(By.TAG_NAME,'body').text)
            if re.search(r'Página\s+\d+\s*/\s*(?:[2-9]|[1-9]\d+)\b', self.driver.find_element(By.TAG_NAME,'body').text):
                raise RuntimeError('Hay varias páginas de cheques; requiere revisión manual.')
            tables = self.driver.find_elements(By.TAG_NAME,'table')
            table = next((t for t in tables if 'Retención' in t.text and 'Cheque' in t.text),None)
            if table is None:
                raise RuntimeError('No se identificó la tabla de detalle de pago.')
            header_row = next((row for row in table.find_elements(By.TAG_NAME,'tr')
                if any('retenci' in cell.text.strip().lower() for cell in row.find_elements(By.XPATH,'./th|./td'))), None)
            if header_row is None:
                raise RuntimeError('No se encontró el encabezado Retención.')
            # Incluye también el TD vacío de la casilla; mezclar solo TH
            # con los TD de datos desplazaba la columna al importe bruto.
            header_cells = header_row.find_elements(By.XPATH,'./th|./td')
            def header(label):
                matches=[c for c in header_cells if label in c.text.strip().lower()]
                if len(matches)!=1:raise RuntimeError('Encabezado ambiguo: '+label)
                return matches[0]
            retention_header=header('retenci')
            cheque_header=header('cheque')
            company_header=header('empresa')
            date_header=header('fecha')
            gross_header=header('bruto')
            cheque_capture = self.table_capture(table, header_row, 'Listado de cheques')
            data_rows = [r for r in table.find_elements(By.TAG_NAME,'tr') if r.find_elements(By.CSS_SELECTOR,'input[type=checkbox]')]
            if not data_rows:
                raise RuntimeError('No se identificó el cheque para agrupar el respaldo.')
            for r in data_rows:
                cells = r.find_elements(By.XPATH,'./td|./th')
                retention_cell = aligned_cell(cells, retention_header.rect)
                cheque_cell = aligned_cell(cells, cheque_header.rect)
                company_cell = aligned_cell(cells, company_header.rect)
                date_cell = aligned_cell(cells, date_header.rect)
                key = '|'.join(c.text.strip() for c in [company_cell,cheque_cell,date_cell])
                if not cheque_cell.text.strip():
                    raise RuntimeError('El pago no tiene identificador para agrupar el respaldo.')
                pdfs=[]
                retention_links=retention_cell.find_elements(By.TAG_NAME,'a')
                if not retention_links and any(c in '123456789' for c in retention_cell.text):
                    raise RuntimeError('La retención tiene importe pero no se encontró su enlace PDF.')
                for a in retention_links:
                    pdfs.append(self.download_retention(a))
                # Al cerrar retenciones puede cambiar el contexto del frame.
                self.wait(lambda: 'Retención' in self.driver.find_element(By.TAG_NAME,'body').text)
                gross_cell=aligned_cell(cells,gross_header.rect)
                gross_links=gross_cell.find_elements(By.TAG_NAME,'a')
                if len(gross_links)!=1:raise RuntimeError('No se identificó el enlace de Importe bruto.')
                paid_numbers, detail_captures = self.payment_detail(gross_links[0])
                if invoice not in paid_numbers:
                    raise RuntimeError('El detalle no incluye la factura buscada; no se completó el pago.')
                saved.append({'key':key,'numbers':paid_numbers,'captures':[cheque_capture]+detail_captures,'pdfs':pdfs})
                self.status('Retención descargada. Preparando el respaldo del pago...')
            # El último cheque ya está completo: devolver los datos para generar
            # el PDF antes de efectuar cualquier navegación adicional.
            if index + 1 < len(rows):
                self.driver.get(results_url)
                self.wait(lambda: self.links('Consulta'))
        # Si hay más páginas, fallar explícitamente para no declarar completo un respaldo parcial.
        if re.search(r'Página\s+\d+\s*/\s*[2-9]\d*', body):
            raise RuntimeError('Hay varias páginas de pagos. Requiere revisión; no se declaró completada la factura.')
        return saved
    def table_capture(self,table,header,title):
        rows=table.find_elements(By.TAG_NAME,'tr')
        return {'title':title,'header':header.screenshot_as_png,'rows':[r.screenshot_as_png for r in rows if r.id!=header.id and r.is_displayed() and r.find_elements(By.XPATH,'./td|./th')]}

    def payment_detail(self,link):
        d=self.driver;old=d.current_window_handle;handles=set(d.window_handles);url=d.current_url
        link.click()
        def ready(_):
            self.check()
            for h in [h for h in d.window_handles if h not in handles]+[old]:
                d.switch_to.window(h)
                def locate():
                    for table in d.find_elements(By.TAG_NAME,'table'):
                        for row in table.find_elements(By.TAG_NAME,'tr'):
                            cells=row.find_elements(By.XPATH,'./td|./th')
                            if any(re.search(r'n[°ºo]?\.?\s*factura',c.text.lower()) for c in cells):return table,row,cells
                    return False
                found=self.find_context(locate)
                if found:return found
            return False
        numbers=[];captures=[]
        try:
            while True:
                table,header,cells=WebDriverWait(d,90).until(ready)
                factura_header=next(c for c in cells if re.search(r'n[°ºo]?\.?\s*factura',c.text.lower()))
                for row in table.find_elements(By.TAG_NAME,'tr'):
                    if row.id==header.id:continue
                    cells=row.find_elements(By.XPATH,'./td|./th')
                    if not cells:continue
                    try:text=aligned_cell(cells,factura_header.rect).text.strip()
                    except RuntimeError:continue
                    for number in re.findall(r'\b\d{1,5}\s*-\s*\d{1,8}\b',text):
                        normalized=invoices(number)[0]
                        if normalized not in numbers:numbers.append(normalized)
                captures.append(self.table_capture(table,header,'Detalle completo del pago'))
                body=d.find_element(By.TAG_NAME,'body').text
                pages=re.search(r'Página\s+(\d+)\s*/\s*(\d+)',body)
                if not pages or int(pages[1])>=int(pages[2]):break
                candidates=[a for a in d.find_elements(By.TAG_NAME,'a') if a.is_displayed() and (a.text.strip() in ('›','»','>') or 'siguiente' in (a.get_attribute('title') or '').lower())]
                if len(candidates)!=1:raise RuntimeError('El detalle tiene más páginas y no se identificó Siguiente. Se mantiene pendiente.')
                before=header
                candidates[0].click()
                WebDriverWait(d,30).until(lambda _: ('Página '+str(int(pages[1])+1)) in d.find_element(By.TAG_NAME,'body').text)
            if not numbers:raise RuntimeError('No se encontraron números de factura en el detalle del pago.')
            return numbers,captures
        finally:
            for h in list(d.window_handles):
                if h not in handles:d.switch_to.window(h);d.close()
            d.switch_to.window(old)
            if d.current_url!=url:d.get(url)

    def payment_links(self):
        self.wait(lambda: self.links('Consulta'))
        return [e for e in self.driver.find_elements(By.TAG_NAME,'a') if e.is_displayed() and e.text.strip()=='Consulta']
    def capture(self):
        # CDP captura el documento superior con todos sus frames visibles.
        d=self.driver
        metrics=d.execute_cdp_cmd('Page.getLayoutMetrics', {})
        size=metrics.get('cssContentSize',metrics['contentSize'])
        return base64.b64decode(d.execute_cdp_cmd('Page.captureScreenshot', {'captureBeyondViewport':True,'fromSurface':True,'clip':{'x':0,'y':0,'width':size['width'],'height':size['height'],'scale':1}})['data'])
    def download_retention(self, link):
        d=self.driver
        old=d.current_window_handle
        handles=set(d.window_handles)
        href=link.get_attribute('href') or ''
        parsed = urlparse(href)
        # El enlace ejecuta la generación; no es el PDF descargable todavía.
        if not (parsed.scheme in ('http','https') and parsed.path.lower().endswith('.pdf')):
            self.status('Generando comprobante de retención. Esperando el PDF...')
            link.click()
            def popup_ready(_):
                self.check()
                for handle in d.window_handles:
                    if handle not in handles:
                        d.switch_to.window(handle)
                        url=d.current_url
                        if urlparse(url).path.lower().endswith('.pdf'):
                            return url
                        # Algunos visores alojan el archivo dentro de embed/iframe.
                        for embedded in d.find_elements(By.CSS_SELECTOR,'embed[src],iframe[src]'):
                            url=embedded.get_attribute('src') or ''
                            if urlparse(url).path.lower().endswith('.pdf'):return url
                d.switch_to.window(old)
                return False
            href=WebDriverWait(d,120).until(popup_ready)
        url=urljoin(d.current_url,href)
        host=urlparse(url).hostname or ''
        if not (host=='segurosrivadavia.com' or host.endswith('.segurosrivadavia.com')):
            raise RuntimeError('Destino de retención inesperado.')
        cookie='; '.join(c['name']+'='+c['value'] for c in d.get_cookies() if host.endswith(c['domain'].lstrip('.')))
        request=urllib.request.Request(url, headers={'Cookie':cookie,'User-Agent':d.execute_script('return navigator.userAgent')})
        try:
            with urllib.request.urlopen(request,timeout=60) as response:
                raw=response.read()
            if not raw.startswith(b'%PDF-'):
                raise RuntimeError('El enlace no devolvió un PDF de retención válido.')
            return raw
        finally:
            if d.current_window_handle!=old:
                d.close(); d.switch_to.window(old)
