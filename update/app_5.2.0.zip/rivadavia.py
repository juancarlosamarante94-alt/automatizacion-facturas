import csv
import ctypes
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import traceback
import unicodedata
from dataclasses import dataclass, asdict
from datetime import datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from pypdf import PdfReader
from selenium import webdriver
from selenium.common.exceptions import ElementClickInterceptedException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait


FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLScjyIbs0hr4VD2n7WIsgWjBQ9pdXlWnaHTGMCivtYVxJEifow/viewform"
CORREO = "juanamarante@autosurpatagonia.com.ar"
CUIT = "30-61532797-9"
PROVINCIA = "Chubut"
CP = "9100"
PROFILE_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "CargadorRivadavia" / "Chrome"
DEBUG_PORT = 9227


class _Root:
    def withdraw(self):
        pass


def Tk():
    return _Root()


class _MessageBox:
    @staticmethod
    def _show(title, text, flags):
        return ctypes.windll.user32.MessageBoxW(0, str(text), str(title), flags)

    @classmethod
    def showinfo(cls, title, text, parent=None):
        return cls._show(title, text, 0x40)

    @classmethod
    def showwarning(cls, title, text, parent=None):
        return cls._show(title, text, 0x30)

    @classmethod
    def showerror(cls, title, text, parent=None):
        return cls._show(title, text, 0x10)

    @classmethod
    def askyesno(cls, title, text, parent=None):
        return cls._show(title, text, 0x04 | 0x20) == 6

    @classmethod
    def askyesnocancel(cls, title, text, parent=None):
        result = cls._show(title, text, 0x03 | 0x20)
        return True if result == 6 else False if result == 7 else None


class _FileDialog:
    @staticmethod
    def askdirectory(title="Elegí una carpeta", parent=None):
        script = (
            "$f=(New-Object -ComObject Shell.Application).BrowseForFolder(0,'"
            + title.replace("'", "''")
            + "',0,0); if($f){$f.Self.Path}"
        )
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-Command", script],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        return result.stdout.strip()


messagebox = _MessageBox
filedialog = _FileDialog


def norm(value):
    value = unicodedata.normalize("NFD", str(value or "").lower())
    value = "".join(c for c in value if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", value).strip()


def money_text(value):
    value = str(value or "").translate(str.maketrans({"¢": "9", "€": "8", "&": "8"}))
    value = re.sub(r"[^0-9,.-]", "", value)
    if not value:
        return ""
    if "," in value and "." in value:
        if value.rfind(".") > value.rfind(","):
            value = value.replace(",", "").replace(".", ",")
        else:
            value = value.replace(".", "")
    elif "." in value:
        left, right = value.rsplit(".", 1)
        value = left.replace(".", "") + ("," + right if len(right) == 2 else right)
    return value


def money_decimal(value):
    try:
        return Decimal(money_text(value).replace(",", "."))
    except (InvalidOperation, ValueError):
        return None


def normalize_date(value):
    bits = re.split(r"[/-]", value.strip())
    if len(bits) != 3:
        return value.strip()
    return f"{int(bits[0]):02d}/{int(bits[1]):02d}/{bits[2]}"


def normalize_claim(value):
    bits = re.split(r"[/-]", re.sub(r"\s+", "", value or ""))
    if len(bits) != 4 or not all(part.isdigit() for part in bits):
        return ""
    # Rivadavia rechaza ceros iniciales en los dos primeros bloques.
    return f"{int(bits[0])}-{int(bits[1])}-{bits[2]}-{bits[3]}"


def first_match(patterns, text, flags=re.I | re.S):
    for pattern in patterns:
        match = re.search(pattern, text, flags)
        if match:
            return match.group(1).strip()
    return ""


def is_electronic_credit_invoice(text):
    """Detecta Factura de Crédito Electrónica MiPyMEs aun con OCR sin tildes."""
    normalized = norm(text)
    return bool(
        re.search(r"\bfactura de credito(?: electronica)?\b", normalized)
        or re.search(r"\bfce\b", normalized)
    )


def invoice_suffix(text, boca):
    # Las FCE nuevas pueden usar boca 80. La naturaleza del comprobante tiene
    # prioridad sobre la regla histórica 80=C / 88=E.
    return "E" if is_electronic_credit_invoice(text) or int(boca) == 88 else "C"


@dataclass
class Invoice:
    archivo: str
    correo: str = CORREO
    cuit: str = CUIT
    provincia: str = PROVINCIA
    cp: str = CP
    siniestro: str = ""
    dominio: str = ""
    servicio: str = "Venta de repuestos"
    proceso: str = "Solo repuesto"
    entregados: str = "SI"
    neto: str = ""
    iva: str = ""
    factura: str = ""
    letra: str = "Factura A"
    fecha: str = ""
    cae: str = ""
    vencimiento: str = ""
    total: str = ""

    def validate(self):
        required = ("siniestro", "dominio", "neto", "iva", "factura", "fecha", "cae", "vencimiento", "total")
        missing = [field for field in required if not getattr(self, field)]
        if missing:
            return False, "faltan " + ", ".join(missing)
        net, tax, total = map(money_decimal, (self.neto, self.iva, self.total))
        if None in (net, tax, total):
            return False, "hay importes ilegibles"
        difference = abs((net + tax) - total)
        if difference > Decimal("0.02"):
            return False, f"neto + IVA no coincide con el total (diferencia {difference})"
        if not re.fullmatch(r"\d{1,2}-\d{1,2}-\d{5,8}-\d{2}", self.siniestro):
            return False, "formato de siniestro inválido"
        if not re.fullmatch(r"(?:[A-Z]{3}\d{3}|[A-Z]{2}\d{3}[A-Z]{2})", self.dominio):
            return False, "formato de patente inválido"
        return True, "OK"


MONEY = r"(?:\d{1,3}(?:[.,]\d{3})+|\d+)[.,]\d{2}"
DATE = r"\d{1,2}[/-]\d{1,2}[/-]\d{4}"


def extract_amounts(first_page):
    # La única fuente válida es el resumen fiscal de la primera hoja.
    # Cuando existe un descuento, el formulario debe recibir el importe de la
    # línea NETO (subtotal menos descuento), no el SUBTOTAL anterior.
    lines = first_page.splitlines()

    def amounts_without_percent(text):
        values = []
        for match in re.finditer(MONEY, text):
            if re.match(r"\s*%", text[match.end():]):
                continue
            values.append(money_text(match.group(0)))
        return values

    def on_labeled_line(label, source_lines=None):
        for line in source_lines or lines:
            if re.search(label, line, re.I):
                values = amounts_without_percent(line)
                if values:
                    return values[-1]
        return ""

    subtotal_index = next((i for i, line in enumerate(lines) if re.search(r"\bSUBTOTAL\b", line, re.I)), None)
    if subtotal_index is not None:
        summary_lines = lines[subtotal_index:subtotal_index + 18]
        summary_text = "\n".join(summary_lines)
        if re.search(r"\bDESCUENTO\b", summary_text, re.I) and re.search(r"^\s*NETO\b", summary_text, re.I | re.M):
            net = on_labeled_line(r"^\s*NETO\b", summary_lines)
            tax = on_labeled_line(r"^\s*IVA\b", summary_lines)
            total = on_labeled_line(r"^\s*TOTAL\b", summary_lines)
            if net and tax and total:
                return net, tax, total

            # Algunos PDF extraen primero todas las etiquetas y después la
            # columna completa de importes. Se descartan los porcentajes y se
            # usan las cinco cifras del resumen: subtotal, descuento, neto,
            # IVA y total.
            values = amounts_without_percent(summary_text)
            if len(values) >= 5:
                subtotal, discount, net, tax, total = values[-5:]
                parsed = [money_decimal(value) for value in (subtotal, discount, net, tax, total)]
                if None not in parsed:
                    subtotal_dec, discount_dec, net_dec, tax_dec, total_dec = parsed
                    if (
                        abs((subtotal_dec - discount_dec) - net_dec) <= Decimal("0.02")
                        and abs((net_dec + tax_dec) - total_dec) <= Decimal("0.02")
                    ):
                        return net, tax, total

    patterns = [
        rf"SUBTOTAL\s*\n\s*IVA[^\n]*\n\s*TOTAL\s*\n\s*({MONEY})\s*\n\s*({MONEY})\s*\n\s*({MONEY})",
        rf"SUBTOTAL\s+IVA[^\n]*\s+TOTAL\s+({MONEY})\s+({MONEY})\s+({MONEY})",
    ]
    for pattern in patterns:
        match = re.search(pattern, first_page, re.I)
        if match:
            return tuple(money_text(v) for v in match.groups())

    return (
        on_labeled_line(r"^\s*(?:SUBTOTAL|IMPORTE NETO(?: GRAVADO)?)\b"),
        on_labeled_line(r"^\s*IVA(?:\s+21)?\b"),
        on_labeled_line(r"^\s*TOTAL\b"),
    )


def tesseract_path():
    detected = shutil.which("tesseract")
    if detected:
        return detected
    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Tesseract-OCR/tesseract.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Tesseract-OCR/tesseract.exe",
    ]
    return str(next((p for p in candidates if p.exists()), ""))


def ocr_first_page(path):
    executable = tesseract_path()
    if not executable:
        return ""
    try:
        import fitz
        document = fitz.open(str(path))
        page = document[0]
        pixmap = page.get_pixmap(matrix=fitz.Matrix(2.5, 2.5), alpha=False)
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as temp:
            temp_path = Path(temp.name)
        try:
            pixmap.save(str(temp_path))
            result = subprocess.run(
                [executable, str(temp_path), "stdout", "--psm", "6"],
                capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=90,
            )
            return result.stdout if result.returncode == 0 else ""
        finally:
            try:
                temp_path.unlink()
            except OSError:
                pass
    except Exception:
        return ""


def extract_ocr_amounts(text):
    # Se aceptan sustituciones OCR únicamente junto a las etiquetas fiscales.
    # Nunca se toman importes de la orden de compra ni de otras páginas.
    def labeled(label):
        match = re.search(
            r"(?<!\w)(?:" + label + r")(?!\w)\s*(?:\$|S)?\s*([0-9][0-9., ]*[0-9¢€&])",
            text, re.I,
        )
        return money_text(match.group(1)) if match else ""

    # En facturas con descuento, NETO es el subtotal posterior al descuento.
    net = labeled(r"NETO") if re.search(r"\bDESCUENTO\b", text, re.I) else ""
    net = net or labeled(r"SUBTOTAL")
    tax = labeled(r"IVA\s+21[.,]00\s*%?")
    total = labeled(r"TOTAL")
    if not total:
        total = labeled(r"Son\s*:\s*PESOS")
    return net, tax, total


def parse_invoice(path, strict=True):
    reader = PdfReader(str(path))
    pages = [(page.extract_text() or "").replace("\x00", " ") for page in reader.pages]
    if not pages or not pages[0].strip():
        raise ValueError("la primera hoja no contiene texto legible")
    page1 = pages[0]
    page2 = pages[1] if len(pages) > 1 else ""

    invoice_match = re.search(
        r"FACTURA(?:\s+DE\s+VENTA)?[\s\S]{0,160}?Nro\.?\s*:\s*0*(80|88)\s*-\s*0*(\d+)",
        page1, re.I,
    ) or re.search(r"\b(80|88)[-_ ]0*(\d{2,7})\b", path.stem, re.I)
    if not invoice_match and strict:
        raise ValueError("no pude identificar el número de factura")
    if invoice_match:
        boca, number = invoice_match.groups()
        suffix = invoice_suffix(page1, boca)
        invoice_number = f"{int(boca)}-{int(number)}-{suffix}"
    else:
        invoice_number = ""

    fecha = first_match([rf"Fecha\s*:?\s*({DATE})", rf"Fecha de emisi[oó]n\s*:?\s*({DATE})"], page1)
    cae = first_match([r"CAE[\s\S]{0,100}?\b(\d{14})\b"], page1)
    vencimiento = first_match([
        rf"Fecha\s+vto[.:]*\s*(?:\n\s*)?(?:\d{{14}}\s*\n\s*)?({DATE})",
        rf"Vencimiento(?:\s+CAE)?\s*:?\s*({DATE})",
    ], page1)

    siniestro_patterns = [
        r"Nro\s*Siniestro\s*:\s*(?:\n\s*)?(\d{1,2}\s*[/-]\s*\d{1,2}\s*[/-]\s*\d{5,8}\s*[/-]\s*\d{2})",
        r"\b(\d{1,2}\s*[/-]\s*\d{1,2}\s*[/-]\s*\d{5,8}\s*[/-]\s*\d{2})\b",
    ]
    siniestro_raw = first_match(siniestro_patterns, page2) or first_match(siniestro_patterns, page1)
    dominio = first_match([
        r"Patente\s*:\s*(?:\n\s*)?([A-Z]{2}[- ]?\d{3}[- ]?[A-Z]{2}|[A-Z]{3}[- ]?\d{3})\b",
        r"\b([A-Z]{2}[- ]?\d{3}[- ]?[A-Z]{2}|[A-Z]{3}[- ]?\d{3})\b",
    ], page2).upper().replace("-", "").replace(" ", "")

    neto, iva, total = extract_amounts(page1)
    preliminary = [money_decimal(value) for value in (neto, iva, total)]
    amounts_valid = (
        None not in preliminary
        and abs((preliminary[0] + preliminary[1]) - preliminary[2]) <= Decimal("0.02")
    )
    if not amounts_valid:
        ocr_text = ocr_first_page(path)
        ocr_neto, ocr_iva, ocr_total = extract_ocr_amounts(ocr_text)
        neto = ocr_neto or neto
        iva = ocr_iva or iva
        total = ocr_total or total
    data = Invoice(
        archivo=str(path.resolve()),
        siniestro=normalize_claim(siniestro_raw),
        dominio=dominio,
        neto=neto,
        iva=iva,
        factura=invoice_number,
        fecha=normalize_date(fecha) if fecha else "",
        cae=cae,
        vencimiento=normalize_date(vencimiento) if vencimiento else "",
        total=total,
    )
    valid, reason = data.validate()
    if strict and not valid:
        raise ValueError(reason)
    return data


FIELD_ALIASES = {
    "correo": ("correo electronico", "email"),
    "cuit": ("cuit proveedor", "cuit del proveedor"),
    "provincia": ("provincia donde se ha emitido factura", "provincia"),
    "cp": ("codigo postal",),
    "siniestro": ("numero de siniestro", "nro siniestro", "siniestro"),
    "dominio": ("dominio", "patente"),
    "servicio": ("tipo de servicio prestado", "servicio prestado"),
    "proceso": ("tipo de proceso", "proceso"),
    "entregados": ("los repuestos fueron entregados", "repuestos fueron entregados"),
    "neto": ("precio neto gravado", "precio gravado", "importe neto gravado", "importe neto", "monto neto gravado", "neto gravado"),
    "iva": ("monto de iva", "importe iva", "iva"),
    "factura": ("datos factura", "numero de factura"),
    "letra": ("letra de factura", "tipo de factura", "letra"),
    "fecha": ("fecha de factura", "fecha de emision", "fecha emision factura", "fecha emision"),
    "cae": ("numero de cae", "cae"),
    "vencimiento": ("vencimiento cae", "vto. cae", "vto cae", "fecha de vencimiento del cae", "fecha vto cae"),
    "total": ("monto total de la factura", "total de la factura"),
}


def identify_field(title):
    title = norm(title)
    choices = []
    for key, aliases in FIELD_ALIASES.items():
        for alias in aliases:
            if norm(alias) in title:
                choices.append((len(norm(alias)), key))
    return max(choices)[1] if choices else None


def chrome_path():
    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    return next((p for p in candidates if p.exists()), None)


def port_open(port):
    with socket.socket() as sock:
        sock.settimeout(0.25)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def start_normal_chrome():
    chrome = chrome_path()
    if not chrome:
        raise RuntimeError("No encontré Google Chrome instalado")
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    if not port_open(DEBUG_PORT):
        subprocess.Popen([
            str(chrome), f"--remote-debugging-port={DEBUG_PORT}",
            f"--user-data-dir={PROFILE_DIR}", "--lang=es-AR",
            "--accept-lang=es-AR,es", "--start-maximized", FORM_URL,
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    deadline = time.time() + 30
    while time.time() < deadline and not port_open(DEBUG_PORT):
        time.sleep(0.25)
    if not port_open(DEBUG_PORT):
        raise RuntimeError("Chrome no habilitó la conexión del cargador")

    options = webdriver.ChromeOptions()
    options.debugger_address = f"127.0.0.1:{DEBUG_PORT}"
    driver = webdriver.Chrome(options=options)
    try:
        driver.execute_cdp_cmd("Emulation.setLocaleOverride", {"locale": "es-AR"})
    except Exception:
        pass
    return driver


def visible_blocks(driver):
    return [b for b in driver.find_elements(By.CSS_SELECTOR, "div[role='listitem']") if b.is_displayed()]


def clear_input(driver, element):
    """Vacía el campo y confirma que no quede ningún dato anterior."""
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    try:
        element.click()
    except ElementClickInterceptedException:
        # Una lista desplegable abierta no debe bloquear el campo siguiente.
        driver.switch_to.active_element.send_keys(Keys.ESCAPE)
        time.sleep(0.3)
        driver.execute_script("arguments[0].click();", element)
    element.send_keys("\ue009a")  # Ctrl+A
    element.send_keys("\ue003")   # Backspace
    driver.execute_script(
        "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
        "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));", element,
    )
    if str(element.get_attribute("value") or ""):
        driver.execute_script("""
            const el=arguments[0], proto=Object.getPrototypeOf(el);
            const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
            if(setter){ setter.call(el,''); } else { el.value=''; }
            el.dispatchEvent(new Event('input',{bubbles:true}));
            el.dispatchEvent(new Event('change',{bubbles:true}));
        """, element)
    if str(element.get_attribute("value") or ""):
        raise RuntimeError("no pude borrar el contenido anterior de un campo")


def set_input(driver, element, value):
    value = str(value)
    clear_input(driver, element)
    driver.execute_script(
        "arguments[0].setAttribute('autocomplete','off');"
        "arguments[0].setAttribute('autocorrect','off');", element,
    )
    element.send_keys(value)
    # Siempre reafirma el valor mediante el setter nativo. Esto evita que un
    # borrador anterior de Google Forms reaparezca al abandonar el campo.
    driver.execute_script("""
        const el=arguments[0], value=arguments[1];
        const proto=Object.getPrototypeOf(el);
        const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
        if(setter){ setter.call(el,value); } else { el.value=value; }
        el.dispatchEvent(new Event('input',{bubbles:true}));
        el.dispatchEvent(new Event('change',{bubbles:true}));
        el.blur();
    """, element, value)
    time.sleep(0.25)
    actual = str(element.get_attribute("value") or "")
    if actual != value:
        raise RuntimeError(f"Google modificó el valor '{value}' y dejó '{actual}'")


def set_date_inputs(driver, inputs, value):
    day, month, year = normalize_date(value).split("/")
    if len(inputs) >= 3:
        for element in inputs:
            label = norm(element.get_attribute("aria-label") or element.get_attribute("placeholder"))
            if "dia" in label:
                set_input(driver, element, day)
            elif "mes" in label:
                set_input(driver, element, month)
            elif "ano" in label:
                set_input(driver, element, year)
        return
    element = inputs[0]
    if (element.get_attribute("type") or "").lower() == "date":
        iso_value = f"{year}-{month}-{day}"
        clear_input(driver, element)
        # El valor interno obligatorio de HTML es AAAA-MM-DD, pero se fuerza
        # la presentación argentina DD/MM/AAAA en el control y en la página.
        driver.execute_script(
            "document.documentElement.lang='es-AR'; arguments[0].lang='es-AR';"
            "arguments[0].value=arguments[1];"
            "arguments[0].dispatchEvent(new Event('input',{bubbles:true}));"
            "arguments[0].dispatchEvent(new Event('change',{bubbles:true}));",
            element, iso_value,
        )
        element.send_keys("\ue004")  # Tab: confirma el control de fecha
        time.sleep(0.25)
        actual = str(element.get_attribute("value") or "")
        if actual != iso_value:
            raise RuntimeError(f"Google modificó la fecha {value}; valor interno: {actual}")
    else:
        set_input(driver, element, f"{day}/{month}/{year}")


def option_text(element):
    return norm(element.get_attribute("data-value") or element.get_attribute("aria-label") or element.text)


def choice_control_selected(block, value):
    """Confirma el valor real del radio o del listbox cerrado."""
    wanted = norm(value)
    radios = block.find_elements(By.CSS_SELECTOR, "[role='radio'][aria-checked='true']")
    if any(option_text(radio) == wanted for radio in radios):
        return True
    boxes = block.find_elements(By.CSS_SELECTOR, "[role='listbox'],[role='combobox']")
    for box in boxes:
        values = (
            box.get_attribute("data-value"),
            box.get_attribute("aria-label"),
            box.text,
        )
        if any(norm(candidate) == wanted for candidate in values if candidate):
            return True
    return False


def find_question_block(driver, title):
    """Vuelve a buscar la pregunta para evitar referencias obsoletas."""
    wanted = norm(title)
    for block in visible_blocks(driver):
        lines = [line.strip() for line in block.text.splitlines() if line.strip()]
        current = norm(lines[0] if lines else "")
        if current == wanted:
            return block
    return False


def choice_selected_by_title(driver, title, value):
    block = find_question_block(driver, title)
    return bool(block and choice_control_selected(block, value))


def select_option(driver, block, value):
    """Selecciona componentes personalizados de Google Forms y los verifica."""
    lines = [line.strip() for line in block.text.splitlines() if line.strip()]
    title = lines[0] if lines else ""
    wanted = norm(value)
    wait = WebDriverWait(
        driver,
        15,
        ignored_exceptions=(StaleElementReferenceException,),
    )

    current_block = wait.until(lambda d: find_question_block(d, title))
    if choice_control_selected(current_block, value):
        return True

    radios = [
        radio for radio in current_block.find_elements(By.CSS_SELECTOR, "[role='radio']")
        if radio.is_displayed()
    ]
    if radios:
        def exact_radio(d):
            fresh_block = find_question_block(d, title)
            if not fresh_block:
                return False
            for radio in fresh_block.find_elements(By.CSS_SELECTOR, "[role='radio']"):
                if radio.is_displayed() and option_text(radio) == wanted:
                    return radio
            return False

        target = wait.until(exact_radio)
        if not target:
            raise RuntimeError(f"no encontré la opción '{value}'")
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", target)
        try:
            wait.until(EC.element_to_be_clickable(target)).click()
        except ElementClickInterceptedException:
            driver.execute_script("arguments[0].click();", target)
        wait.until(lambda d: choice_selected_by_title(d, title, value))
        return True

    boxes = [
        box for box in current_block.find_elements(By.CSS_SELECTOR, "[role='listbox'],[role='combobox']")
        if box.is_displayed()
    ]
    if not boxes:
        return False

    box = boxes[0]
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", box)
    wait.until(EC.element_to_be_clickable(box)).click()

    # Google agrega las opciones del desplegable en una capa flotante global,
    # fuera del bloque de la pregunta. Se busca solamente la opción visible
    # cuyo data-value/aria-label/texto coincida exactamente.
    def exact_global_option(d):
        for option in d.find_elements(By.CSS_SELECTOR, "[role='option']"):
            if option.is_displayed() and option_text(option) == wanted:
                return option
        return False

    target = wait.until(exact_global_option)
    driver.execute_script("arguments[0].scrollIntoView({block:'nearest'});", target)
    try:
        wait.until(EC.element_to_be_clickable(target)).click()
    except ElementClickInterceptedException:
        try:
            ActionChains(driver).move_to_element(target).pause(0.15).click().perform()
        except Exception:
            driver.execute_script("arguments[0].click();", target)

    def selection_confirmed(d):
        fresh_block = find_question_block(d, title)
        if not fresh_block or not choice_control_selected(fresh_block, value):
            return False
        fresh_boxes = fresh_block.find_elements(
            By.CSS_SELECTOR, "[role='listbox'],[role='combobox']"
        )
        return bool(
            fresh_boxes
            and (fresh_boxes[0].get_attribute("aria-expanded") or "false").lower() != "true"
        )

    try:
        wait.until(selection_confirmed)
    except TimeoutException as exc:
        try:
            driver.switch_to.active_element.send_keys(Keys.ESCAPE)
        except Exception:
            pass
        raise RuntimeError(f"Google no confirmó la selección '{value}'") from exc
    return True


def find_file_input_recursive(driver):
    driver.switch_to.default_content()
    direct = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
    if direct:
        return direct[0]
    frames = driver.find_elements(By.TAG_NAME, "iframe")
    for frame in frames:
        try:
            driver.switch_to.default_content()
            driver.switch_to.frame(frame)
            direct = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
            if direct:
                return direct[0]
            nested = driver.find_elements(By.TAG_NAME, "iframe")
            for child in nested:
                try:
                    driver.switch_to.frame(child)
                    direct = driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
                    if direct:
                        return direct[0]
                    driver.switch_to.parent_frame()
                except Exception:
                    driver.switch_to.parent_frame()
        except Exception:
            pass
    driver.switch_to.default_content()
    return None


def set_file_with_cdp(driver, file_path):
    """Carga un archivo incluso si el input vive dentro del selector de Drive."""
    try:
        driver.execute_cdp_cmd("DOM.enable", {})
        document = driver.execute_cdp_cmd("DOM.getFlattenedDocument", {"depth": -1, "pierce": True})
        # El selector abierto por Google suele ser el último input agregado.
        # Recorrer al revés evita usar un input viejo de otra pregunta.
        for node in reversed(document.get("nodes", [])):
            if node.get("nodeName", "").upper() != "INPUT":
                continue
            attributes = node.get("attributes", [])
            attrs = dict(zip(attributes[0::2], attributes[1::2]))
            if attrs.get("type", "").lower() == "file":
                driver.execute_cdp_cmd("DOM.setFileInputFiles", {
                    "files": [str(Path(file_path).resolve())],
                    "backendNodeId": node["backendNodeId"],
                })
                return True
    except Exception:
        pass
    return False


def click_in_frames(driver, wanted_text, max_depth=5):
    """Busca y pulsa un botón visible, también dentro de iframes anidados."""
    wanted = norm(wanted_text)

    def search(depth):
        elements = driver.find_elements(By.CSS_SELECTOR, "div[role='button'],button")
        for element in elements:
            try:
                if element.is_displayed() and wanted in norm(element.text or element.get_attribute("aria-label")):
                    driver.execute_script("arguments[0].click();", element)
                    return True
            except Exception:
                continue
        if depth >= max_depth:
            return False
        for frame in driver.find_elements(By.TAG_NAME, "iframe"):
            try:
                driver.switch_to.frame(frame)
                if search(depth + 1):
                    return True
                driver.switch_to.parent_frame()
            except Exception:
                try:
                    driver.switch_to.parent_frame()
                except Exception:
                    driver.switch_to.default_content()
        return False

    driver.switch_to.default_content()
    found = search(0)
    driver.switch_to.default_content()
    return found


def choose_file_in_windows_dialog(file_path, timeout=20):
    """Completa la ventana nativa Abrir de Windows sin pyautogui."""
    user32 = ctypes.windll.user32
    WM_SETTEXT = 0x000C
    BM_CLICK = 0x00F5
    deadline = time.time() + timeout

    while time.time() < deadline:
        dialog = user32.FindWindowW("#32770", None)
        if dialog:
            edit = user32.GetDlgItem(dialog, 1148)  # Campo "Nombre de archivo"
            open_button = user32.GetDlgItem(dialog, 1)  # Botón Abrir
            if edit and open_button:
                user32.SendMessageW(edit, WM_SETTEXT, 0, str(Path(file_path).resolve()))
                user32.SendMessageW(open_button, BM_CLICK, 0, 0)
                return True
        time.sleep(0.25)
    return False


def upload_file(driver, block, file_path):
    filename = Path(file_path).name
    lines = [line.strip() for line in block.text.splitlines() if line.strip()]
    title = lines[0] if lines else ""
    if norm(filename) in norm(block.text):
        return

    def status(d):
        fresh = find_question_block(d, title)
        if not fresh:
            return ""
        text = norm(fresh.text)
        if norm(filename) in text and "subiendo" not in text:
            return "COMPLETO"
        if "subiendo" in text or "carga completa" in text:
            return "CARGANDO"
        return ""

    last_error = ""
    for attempt in range(2):
        current = find_question_block(driver, title) or block
        if norm(filename) in norm(current.text):
            return
        upload_button = next((
            element for element in current.find_elements(By.CSS_SELECTOR, "div[role='button'],button")
            if element.is_displayed()
            and any(word in norm((element.text or "") + " " + (element.get_attribute("aria-label") or "")) for word in ("agregar archivo", "anadir archivo"))
        ), None)
        if not upload_button:
            raise RuntimeError(f"no encontré Agregar archivo en '{title}'")
        driver.execute_script(
            "arguments[0].scrollIntoView({block:'center'}); arguments[0].click();",
            upload_button,
        )
        time.sleep(2)

        loaded = set_file_with_cdp(driver, file_path)
        if not loaded:
            picker = find_file_input_recursive(driver)
            if picker:
                picker.send_keys(str(Path(file_path).resolve()))
                loaded = True
        if not loaded:
            if not click_in_frames(driver, "Explorar"):
                last_error = "Google abrió el selector, pero no encontré Explorar"
            elif not choose_file_in_windows_dialog(file_path):
                last_error = "no pude completar la ventana Abrir de Windows"
            else:
                loaded = True

        driver.switch_to.default_content()
        if loaded:
            try:
                WebDriverWait(driver, 90).until(lambda d: status(d) in ("CARGANDO", "COMPLETO"))
                WebDriverWait(driver, 180).until(lambda d: status(d) == "COMPLETO")
                return
            except TimeoutException:
                last_error = f"Google no confirmó el archivo en la pregunta '{title}'"

        # Cierra una capa del selector que haya quedado abierta y hace un solo
        # reintento sobre la misma pregunta.
        try:
            driver.switch_to.default_content()
            driver.switch_to.active_element.send_keys(Keys.ESCAPE)
        except Exception:
            pass
        time.sleep(1)

    raise RuntimeError(last_error or f"no pude adjuntar {filename} en '{title}'")


def is_upload_block(block):
    """Google puede titular el adjunto 'Factura' sin mencionar 'archivo'."""
    try:
        for element in block.find_elements(By.CSS_SELECTOR, "div[role='button'],button"):
            label = norm((element.text or "") + " " + (element.get_attribute("aria-label") or ""))
            if "agregar archivo" in label or "anadir archivo" in label:
                return True
        return bool(block.find_elements(By.CSS_SELECTOR, "input[type='file']"))
    except StaleElementReferenceException:
        return False


def fill_current_page(driver, invoice):
    data = asdict(invoice)
    WebDriverWait(driver, 30).until(lambda d: visible_blocks(d))
    completed = set()
    for retry in range(5):
        try:
            for block in visible_blocks(driver):
                lines = [x.strip() for x in block.text.splitlines() if x.strip()]
                title = lines[0] if lines else ""
                title_norm = norm(title)
                if is_upload_block(block) or any(
                    word in title_norm for word in ("documentacion de respaldo", "adjuntar", "agregar archivo")
                ):
                    upload_file(driver, block, invoice.archivo)
                    continue
                key = identify_field(title)
                if not key or key in completed or not data.get(key):
                    continue
                inputs = [x for x in block.find_elements(By.CSS_SELECTOR, "input[type='text'],input[type='email'],input[type='date'],textarea") if x.is_displayed()]
                if inputs:
                    if key in ("fecha", "vencimiento"):
                        set_date_inputs(driver, inputs, data[key])
                    else:
                        set_input(driver, inputs[0], data[key])
                    completed.add(key)
                elif select_option(driver, block, data[key]):
                    completed.add(key)
            return completed
        except StaleElementReferenceException:
            time.sleep(0.5)
    raise RuntimeError("Google Forms actualizó la pantalla demasiadas veces")


def button(driver, label):
    wanted = norm(label)
    for element in driver.find_elements(By.CSS_SELECTOR, "div[role='button'],button,a"):
        try:
            if element.is_displayed() and norm(element.text) == wanted:
                return element
        except StaleElementReferenceException:
            continue
    return None


def page_signature(driver):
    return "|".join(norm(b.text.splitlines()[0] if b.text.splitlines() else "") for b in visible_blocks(driver))


def click_and_wait_next(driver):
    next_button = button(driver, "Siguiente")
    if not next_button:
        return False
    old = page_signature(driver)
    driver.execute_script("arguments[0].scrollIntoView({block:'center'}); arguments[0].click();", next_button)
    WebDriverWait(driver, 30).until(lambda d: page_signature(d) != old or button(d, "Enviar") is not None)
    errors = [x.text for x in driver.find_elements(By.CSS_SELECTOR, "[role='alert']") if x.is_displayed() and x.text.strip()]
    if errors:
        raise RuntimeError("Google rechazó un campo: " + " | ".join(errors[:3]))
    return True


def response_recorded(driver):
    body = norm(driver.find_element(By.TAG_NAME, "body").text)
    return (
        "se registro tu respuesta" in body
        or "se ha registrado tu respuesta" in body
        or "tu respuesta se ha registrado" in body
        or "formresponse" in driver.current_url.lower()
    )


def open_another_response(driver):
    """Abre y verifica un formulario vacío después de un envío."""
    try:
        another = WebDriverWait(driver, 20).until(lambda d: button(d, "Enviar otra respuesta"))
        driver.execute_script("arguments[0].scrollIntoView({block:'center'});", another)
        try:
            another.click()
        except Exception:
            driver.execute_script("arguments[0].click();", another)
        WebDriverWait(driver, 45).until(
            lambda d: bool(visible_blocks(d))
            and not response_recorded(d)
            and (button(d, "Siguiente") is not None or button(d, "Enviar") is not None)
        )
    except Exception:
        # La respuesta ya fue confirmada. Si Google cambia u oculta el enlace,
        # se vuelve al formulario base para evitar duplicar la factura enviada.
        driver.get(FORM_URL)
        WebDriverWait(driver, 60).until(
            lambda d: bool(visible_blocks(d))
            and (button(d, "Siguiente") is not None or button(d, "Enviar") is not None)
        )
    return "FORMULARIO_NUEVO"


def submit_prepared_form(driver, prepare_next=False):
    """Envía un formulario que ya recorrió exactamente el modo de prueba."""
    send = button(driver, "Enviar")
    if not send:
        raise RuntimeError("el formulario preparado no muestra el botón Enviar")
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", send)
    try:
        send.click()
    except Exception:
        driver.execute_script("arguments[0].click();", send)
    WebDriverWait(driver, 45).until(response_recorded)
    if prepare_next:
        open_another_response(driver)
    return "ENVIADA"


def complete_form(driver, invoice, submit):
    driver.switch_to.default_content()
    driver.get(FORM_URL)
    # No empezar a escribir solo porque cambió la URL: en lote Google puede
    # tardar en montar las preguntas. Se espera el formulario real.
    WebDriverWait(driver, 60).until(lambda d: bool(visible_blocks(d)))
    for section in range(1, 9):
        fill_current_page(driver, invoice)
        send = button(driver, "Enviar")
        if send:
            if not submit:
                return "LISTA_PARA_REVISAR"
            return submit_prepared_form(driver)
        if not click_and_wait_next(driver):
            raise RuntimeError(f"pantalla {section}: no encontré Siguiente ni Enviar")
    raise RuntimeError("el formulario tiene más pantallas de las previstas")


def log_path(folder):
    return Path(folder) / "registro_envios.csv"


def sent_numbers(folder):
    path = log_path(folder)
    if not path.exists():
        return set()
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return {
            (row.get("factura") or "").strip() for row in csv.DictReader(stream)
            if (row.get("estado") or "").strip().upper() == "ENVIADA"
        }


def register(invoice, folder, status, detail=""):
    path = log_path(folder)
    new = not path.exists()
    fields = ["fecha_hora", "factura", "siniestro", "dominio", "neto", "iva", "total", "archivo", "estado", "detalle"]
    with path.open("a", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        if new:
            writer.writeheader()
        writer.writerow({
            "fecha_hora": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "factura": invoice.factura, "siniestro": invoice.siniestro, "dominio": invoice.dominio,
            "neto": invoice.neto, "iva": invoice.iva, "total": invoice.total,
            "archivo": Path(invoice.archivo).name, "estado": status, "detalle": detail,
        })


def move_sent(invoice, folder):
    destination_dir = Path(folder) / "FACTURAS_ENVIADAS"
    destination_dir.mkdir(exist_ok=True)
    source = Path(invoice.archivo)
    destination = destination_dir / source.name
    if destination.exists():
        destination = destination_dir / f"{source.stem}_{datetime.now():%Y%m%d_%H%M%S}{source.suffix}"
    shutil.move(str(source), str(destination))


def write_preflight(folder, ready, problems, skipped):
    report = Path(folder) / "control_previo_facturas.csv"
    fields = ["archivo", "factura", "siniestro", "dominio", "neto", "iva", "total", "resultado"]
    with report.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for inv in ready:
            writer.writerow({**{k: getattr(inv, k) for k in fields if k != "resultado"}, "archivo": Path(inv.archivo).name, "resultado": "VALIDADA"})
        for filename, reason in problems:
            writer.writerow({"archivo": filename, "resultado": "ERROR: " + reason})
        for filename in skipped:
            writer.writerow({"archivo": filename, "resultado": "OMITIDA: ya enviada"})
    return report


def main():
    root = Tk()
    root.withdraw()
    default_folder = r"T:\SHAR-REN\JUAN AMARANTE\factura\rivadavia"
    folder = default_folder if Path(default_folder).exists() else filedialog.askdirectory(title="Elegí la carpeta con las facturas", parent=root)
    if not folder:
        return

    already_sent = sent_numbers(folder)
    ready, problems, skipped = [], [], []
    for path in sorted(Path(folder).glob("*.pdf")):
        try:
            invoice = parse_invoice(path)
            if invoice.factura in already_sent:
                skipped.append(path.name)
            else:
                ready.append(invoice)
        except Exception as exc:
            problems.append((path.name, str(exc)))

    report = write_preflight(folder, ready, problems, skipped)
    if problems:
        messagebox.showwarning(
            "Facturas observadas",
            f"Se validaron {len(ready)} facturas y se bloquearon {len(problems)}.\n\n"
            f"Las observadas NO se enviarán. Revisá:\n{report}", parent=root,
        )
    if not ready:
        messagebox.showinfo("Sin facturas pendientes", "No hay facturas válidas pendientes de envío.", parent=root)
        return

    mode = messagebox.askyesnocancel(
        "Modo de ejecución",
        f"Hay {len(ready)} facturas validadas.\n\n"
        "SÍ: enviar automáticamente todo el lote.\n"
        "NO: completar solamente la primera y detenerse antes de Enviar.\n"
        "CANCELAR: salir.\n\n"
        "En modo automático se adjuntarán los PDF y se enviarán datos a Seguros Rivadavia.",
        parent=root,
    )
    if mode is None:
        return
    if mode and not messagebox.askyesno(
        "Confirmar envíos",
        f"¿Confirmás el envío automático de {len(ready)} facturas a Seguros Rivadavia?",
        parent=root,
    ):
        return

    driver = start_normal_chrome()
    time.sleep(2)
    body_text = norm(driver.find_element(By.TAG_NAME, "body").text)
    if "accounts.google.com" in driver.current_url or ("inicia sesion" in body_text and not visible_blocks(driver)):
        messagebox.showinfo(
            "Iniciar sesión",
            "Iniciá sesión en Google en la ventana de Chrome y abrí el formulario.\n\n"
            "Cuando el formulario esté visible, presioná Aceptar.", parent=root,
        )
        driver.get(FORM_URL)
        WebDriverWait(driver, 120).until(lambda d: visible_blocks(d))

    sent, failed = 0, []
    for index, invoice in enumerate(ready, 1):
        try:
            result = complete_form(driver, invoice, submit=bool(mode))
            if result == "LISTA_PARA_REVISAR":
                messagebox.showinfo(
                    "Prueba preparada",
                    f"La factura {invoice.factura} quedó completa y no fue enviada.\n\n"
                    "Revisá especialmente neto, IVA, total, siniestro y adjunto.", parent=root,
                )
                return
            register(invoice, folder, "ENVIADA")
            move_sent(invoice, folder)
            sent += 1
        except Exception as exc:
            detail = str(exc)
            failed.append(f"{invoice.factura}: {detail}")
            register(invoice, folder, "ERROR", detail)
            error_dir = Path(folder) / "ERRORES_CARGADOR"
            error_dir.mkdir(exist_ok=True)
            try:
                driver.save_screenshot(str(error_dir / f"{invoice.factura.replace('-', '_')}.png"))
            except Exception:
                pass
            # El lote continúa con la factura siguiente.

    summary = f"Enviadas: {sent}\nCon error: {len(failed)}\nOmitidas por duplicado: {len(skipped)}"
    if failed:
        summary += "\n\n" + "\n".join(failed[:8])
    messagebox.showinfo("Proceso terminado", summary, parent=root)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        traceback.print_exc()
        try:
            messagebox.showerror("Error del cargador", str(exc))
        except Exception:
            pass
        input("Presioná Enter para cerrar...")
