import html
import json
import sys
import threading
import time
import urllib.parse
import webbrowser
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# El Python embebido de Windows usa un archivo ._pth y puede omitir la carpeta
# del script. Se agrega explícitamente antes de importar el motor del cargador.
APP_SOURCE_DIR = Path(__file__).resolve().parent
if str(APP_SOURCE_DIR) not in sys.path:
    sys.path.insert(0, str(APP_SOURCE_DIR))

import rivadavia as cargador

HOME_PORT = 0


EDITABLE = [
    ("factura", "Factura"), ("siniestro", "Siniestro"), ("dominio", "Dominio"),
    ("neto", "Neto gravado"), ("iva", "IVA"), ("total", "Total"),
    ("fecha", "Fecha"), ("cae", "CAE"), ("vencimiento", "Vto. CAE"),
]


class AppState:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.lock = threading.Lock()
        self.rows = []
        self.message = ""
        self.running = False
        self.waiting_review = False
        self.cancel_review = threading.Event()
        self.promote_to_batch = threading.Event()
        self.worker_thread = None
        self.corrections_path = self.folder / "correcciones_cargador.json"
        self.load()

    def corrections(self):
        try:
            return json.loads(self.corrections_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def load(self):
        saved = self.corrections()
        sent = cargador.sent_numbers(self.folder)
        rows = []
        for path in sorted(self.folder.glob("*.pdf")):
            try:
                invoice = cargador.parse_invoice(path, strict=False)
                for key, value in saved.get(path.name, {}).items():
                    if hasattr(invoice, key) and value:
                        setattr(invoice, key, value)
                valid, reason = invoice.validate()
                status = "ENVIADA" if invoice.factura in sent else "VALIDADA" if valid else "REVISAR"
                rows.append({"invoice": invoice, "valid": valid, "reason": reason, "status": status})
            except Exception as exc:
                invoice = cargador.Invoice(archivo=str(path.resolve()))
                rows.append({"invoice": invoice, "valid": False, "reason": str(exc), "status": "REVISAR"})
        with self.lock:
            self.rows = rows

    def save_form(self, values):
        corrections = self.corrections()
        with self.lock:
            for index, row in enumerate(self.rows):
                invoice = row["invoice"]
                file_data = corrections.setdefault(Path(invoice.archivo).name, {})
                for key, _label in EDITABLE:
                    value = (values.get(f"r{index}_{key}", [""])[0] or "").strip()
                    if key in ("neto", "iva", "total"):
                        value = cargador.money_text(value)
                    elif key == "siniestro":
                        value = cargador.normalize_claim(value)
                    elif key == "dominio":
                        value = value.upper().replace("-", "").replace(" ", "")
                    elif key in ("fecha", "vencimiento") and value:
                        value = cargador.normalize_date(value)
                    setattr(invoice, key, value)
                    file_data[key] = value
                valid, reason = invoice.validate()
                status = "ENVIADA" if row["status"] == "ENVIADA" else "VALIDADA" if valid else "REVISAR"
                row.update(valid=valid, reason=reason, status=status)
        self.corrections_path.write_text(json.dumps(corrections, ensure_ascii=False, indent=2), encoding="utf-8")

    def mark_sent(self, index):
        with self.lock:
            if self.running:
                self.message = "No se puede marcar manualmente mientras hay una carga en curso."
                return
            if index < 0 or index >= len(self.rows):
                self.message = "No encontré la factura seleccionada. Actualizá la carpeta."
                return
            row = self.rows[index]
            invoice = row["invoice"]
            if not invoice.factura:
                self.message = "La factura no tiene un número válido y no puede marcarse como enviada."
                return
            if row["status"] == "ENVIADA":
                self.message = f"{invoice.factura} ya estaba marcada como enviada."
                return

        try:
            cargador.register(invoice, self.folder, "ENVIADA", "Marcada manualmente desde la interfaz")
            with self.lock:
                row["status"] = "ENVIADA"
                row["reason"] = ""
            if Path(invoice.archivo).exists():
                cargador.move_sent(invoice, self.folder)
            with self.lock:
                self.message = f"{invoice.factura} fue marcada manualmente como enviada."
        except Exception as exc:
            with self.lock:
                if row["status"] == "ENVIADA":
                    self.message = f"{invoice.factura} quedó marcada como enviada, pero no pude mover el PDF: {exc}"
                else:
                    self.message = f"No pude marcar {invoice.factura} como enviada: {exc}"

    def run(self, submit):
        with self.lock:
            if self.running:
                if submit and self.waiting_review and self.worker_thread:
                    # La misma sesión que preparó la prueba continúa el lote.
                    # No se crea un segundo controlador sobre otra pestaña.
                    self.message = "Continuando la prueba como envío por lote..."
                    self.promote_to_batch.set()
                else:
                    self.message = "Ya hay una carga en curso. Esperá a que termine."
                return

        valid_rows = [r for r in self.rows if r["valid"] and r["status"] != "ENVIADA"]
        if not valid_rows:
            self.message = "No hay facturas validadas pendientes."
            return
        with self.lock:
            self.running = True
            self.waiting_review = False
            self.cancel_review = threading.Event()
            self.promote_to_batch = threading.Event()
            promote_to_batch = self.promote_to_batch
            self.message = "Abriendo Chrome y preparando el formulario..."

        def worker():
            driver = None
            sent = 0
            errors = 0
            try:
                driver = cargador.start_normal_chrome()
                targets = valid_rows
                batch_mode = submit
                for position, row in enumerate(targets, 1):
                    invoice = row["invoice"]
                    row["status"] = "CARGANDO"
                    self.message = f"Cargando {position} de {len(targets)}: {invoice.factura}..."
                    try:
                        # Prueba y lote recorren exactamente la misma preparación.
                        # En lote, la única acción adicional es el clic final Enviar.
                        result = cargador.complete_form(driver, invoice, submit=False)
                        if batch_mode:
                            if result != "LISTA_PARA_REVISAR":
                                raise RuntimeError("la factura no llegó completa a la pantalla final")
                            # Después de confirmar el envío, abre y verifica
                            # explícitamente "Enviar otra respuesta" antes de seguir.
                            result = cargador.submit_prepared_form(driver, prepare_next=True)
                        if result == "LISTA_PARA_REVISAR":
                            row["status"] = "LISTA PARA REVISAR"
                            self.message = f"{invoice.factura} está lista. Esperando que presiones Enviar en Chrome..."
                            with self.lock:
                                self.waiting_review = True
                            deadline = time.time() + 1800
                            manual_finished = False
                            while time.time() < deadline:
                                try:
                                    recorded = cargador.response_recorded(driver)
                                except Exception:
                                    recorded = False
                                if recorded:
                                    cargador.register(invoice, self.folder, "ENVIADA")
                                    cargador.move_sent(invoice, self.folder)
                                    row["status"] = "ENVIADA"
                                    self.message = f"{invoice.factura} fue enviada y registrada correctamente."
                                    sent += 1
                                    manual_finished = True
                                    break
                                if promote_to_batch.is_set():
                                    with self.lock:
                                        self.waiting_review = False
                                    batch_mode = True
                                    self.message = f"Enviando {invoice.factura} y continuando el lote..."
                                    result = cargador.submit_prepared_form(driver, prepare_next=True)
                                    break
                                time.sleep(0.75)
                            with self.lock:
                                self.waiting_review = False
                            if manual_finished:
                                break
                            if result == "LISTA_PARA_REVISAR":
                                row["status"] = "VALIDADA"
                                self.message = "La prueba sigue pendiente de envío."
                                break
                        cargador.register(invoice, self.folder, "ENVIADA")
                        cargador.move_sent(invoice, self.folder)
                        row["status"] = "ENVIADA"
                        sent += 1
                    except Exception as exc:
                        row["status"] = "ERROR"
                        row["reason"] = str(exc)
                        cargador.register(invoice, self.folder, "ERROR", str(exc))
                        errors += 1
                if batch_mode:
                    self.message = f"Proceso terminado: {sent} enviadas y {errors} con error."
            except Exception as exc:
                self.message = "No se pudo iniciar Chrome: " + str(exc)
            finally:
                with self.lock:
                    self.waiting_review = False
                    self.running = False
                    if self.worker_thread is threading.current_thread():
                        self.worker_thread = None

        thread = threading.Thread(target=worker, daemon=True)
        with self.lock:
            self.worker_thread = thread
        thread.start()


STYLE = """
:root{font-family:Segoe UI,Arial,sans-serif;color:#172033;background:#eef3f8}*{box-sizing:border-box}
body{margin:0}.top{background:#0868b8;color:white;padding:22px 28px}.top h1{margin:0;font-size:25px}.top p{margin:6px 0 0;opacity:.88}
.wrap{max-width:1500px;margin:20px auto;padding:0 18px}.panel{background:white;border-radius:14px;box-shadow:0 4px 18px #17324d18;padding:18px}
.notice{padding:12px 15px;background:#e8f3ff;border-left:4px solid #0875c9;border-radius:7px;margin-bottom:15px}
.table-wrap{overflow:auto;border:1px solid #dce4ed;border-radius:10px}table{border-collapse:collapse;width:100%;min-width:1450px}th{background:#edf4fa;text-align:left;font-size:12px;color:#506176;padding:10px;position:sticky;top:0}td{padding:9px;border-top:1px solid #e6ebf1;vertical-align:top}
input{width:126px;border:1px solid #bdc9d6;border-radius:6px;padding:8px;font-size:13px}input.wide{width:160px}.file{min-width:145px;font-weight:600}.reason{font-size:12px;color:#a12424;max-width:220px}
.badge{display:inline-block;padding:5px 8px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}.ok{background:#dff6e8;color:#146c3b}.bad{background:#ffe4e3;color:#a12424}.sent{background:#e2e9ff;color:#2647a1}.work{background:#fff0c9;color:#875d00}
.actions{display:flex;gap:10px;align-items:center;margin-top:16px;flex-wrap:wrap}button{border:0;border-radius:8px;padding:11px 18px;font-weight:700;cursor:pointer}.save{background:#e5edf5;color:#24425e}.test{background:#f5b942;color:#4b3500}.send{background:#0875c9;color:white}.summary{margin-left:auto;color:#4d5b6a;font-weight:600}
.reload{background:#dcefe5;color:#17613b}.manual{display:block;margin-top:8px;padding:7px 9px;background:#fff1cc;color:#765300;font-size:11px}
"""


def render(state):
    with state.lock:
        rows = list(state.rows)
        running = state.running
    body_rows = []
    for i, row in enumerate(rows):
        inv = row["invoice"]
        status = row["status"]
        cls = "sent" if status == "ENVIADA" else "ok" if status == "VALIDADA" else "work" if status in ("CARGANDO", "LISTA PARA REVISAR") else "bad"
        cells = [f'<td class="file">{html.escape(Path(inv.archivo).name)}</td>']
        for key, _label in EDITABLE:
            value = html.escape(str(getattr(inv, key)))
            wide = " wide" if key in ("factura", "siniestro", "cae") else ""
            cells.append(f'<td><input class="{wide}" name="r{i}_{key}" value="{value}"></td>')
        manual = "" if status == "ENVIADA" or running else (
            f'<button class="manual" name="action" value="mark_sent:{i}" '
            f'onclick="return confirm(\'\u00bfConfirmás que {html.escape(inv.factura or Path(inv.archivo).name)} ya fue enviada?\')">Marcar enviada</button>'
        )
        cells.append(f'<td><span class="badge {cls}">{html.escape(status)}</span>{manual}<div class="reason">{html.escape(row["reason"] if not row["valid"] or status == "ERROR" else "")}</div></td>')
        body_rows.append("<tr>" + "".join(cells) + "</tr>")
    headers = "".join(f"<th>{html.escape(label)}</th>" for _key, label in EDITABLE)
    valid = sum(1 for r in rows if r["valid"] and r["status"] != "ENVIADA")
    invalid = sum(1 for r in rows if not r["valid"])
    message = f'<div class="notice">{html.escape(state.message)}</div>' if state.message else ""
    refresh = '<meta http-equiv="refresh" content="8">' if state.running else ""
    return f"""<!doctype html><html><head><meta charset="utf-8">{refresh}<title>Rivadavia · Cargador V5.0</title><style>{STYLE}</style></head><body>
    <div class="top"><h1>Rivadavia · motor estable V4.12</h1><p><a style="color:white" href="http://127.0.0.1:{HOME_PORT}/">← Plataformas</a> · {html.escape(str(state.folder))}</p></div><div class="wrap"><div class="panel">{message}
    <form method="post"><div class="table-wrap"><table><thead><tr><th>Archivo</th>{headers}<th>Resultado</th></tr></thead><tbody>{''.join(body_rows)}</tbody></table></div>
    <div class="actions"><button class="reload" name="action" value="reload">Actualizar carpeta</button><button class="save" name="action" value="save">Guardar y validar</button><button class="test" name="action" value="test">Probar primera sin enviar</button><button class="send" name="action" value="batch" onclick="return confirm('¿Confirmás que querés enviar automáticamente todas las facturas validadas a Seguros Rivadavia?')">Enviar lote validado</button><span class="summary">Validadas: {valid} · Para revisar: {invalid}</span></div></form></div></div></body></html>"""


def handler_for(state):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _format, *_args):
            pass

        def do_GET(self):
            if self.path == "/reload":
                state.load()
                self.send_response(303); self.send_header("Location", "/"); self.end_headers(); return
            page = render(state).encode("utf-8")
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(page))); self.end_headers(); self.wfile.write(page)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0"))
            values = urllib.parse.parse_qs(self.rfile.read(length).decode("utf-8"), keep_blank_values=True)
            action = values.get("action", ["save"])[0]
            if action.startswith("mark_sent:"):
                with state.lock:
                    can_edit = not state.running
                if can_edit:
                    state.save_form(values)
                try:
                    state.mark_sent(int(action.split(":", 1)[1]))
                except (ValueError, IndexError):
                    state.message = "No pude identificar la factura que querés marcar."
            else:
                state.save_form(values)
            if action.startswith("mark_sent:"):
                pass
            elif action == "reload":
                if state.running:
                    state.message = "Esperá a que termine la carga actual antes de actualizar."
                else:
                    state.load()
                    state.message = "Carpeta actualizada. Se revisaron nuevamente todos los PDF."
            elif action == "test":
                state.run(False)
            elif action == "batch":
                state.run(True)
            else:
                state.message = "Datos guardados y validados."
            self.send_response(303); self.send_header("Location", "/"); self.end_headers()
    return Handler


def main():
    default = Path(r"T:\SHAR-REN\JUAN AMARANTE\factura\rivadavia")
    folder = str(default) if default.exists() else cargador.filedialog.askdirectory(title="Elegí la carpeta con las facturas")
    if not folder:
        return
    state = AppState(folder)
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler_for(state))
    url = f"http://127.0.0.1:{server.server_port}/"
    webbrowser.open(url)
    cargador.messagebox.showinfo("Cargador Rivadavia", "Se abrió el panel de control en tu navegador.\n\nNo cierres esta ventana negra mientras lo estés usando.")
    server.serve_forever()


if __name__ == "__main__":
    main()
