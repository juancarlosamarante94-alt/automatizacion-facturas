import html
import json
import os
import threading
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler
from pathlib import Path
import pagos_rivadavia as motor
import credenciales_pagos as credentials

class State:
    def __init__(self, data_path=None):
        self.lock=threading.Lock()
        self.stop=threading.Event()
        self.rows={}
        self.running=False
        self.portal=None
        self.portal_user=None
        self.message='Listo para buscar.'
        self.data_path = Path(data_path) if data_path else Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'CargadorFacturasAutosur' / 'Datos' / 'pagos_pendientes.json'
        self.completed = set()
        self.payments = {}
        self.folder = motor.DEFAULT_FOLDER
        self.load_queue()
    def load_queue(self):
        if not self.data_path.exists(): return
        data=json.loads(self.data_path.read_text(encoding='utf-8'))
        self.payments=dict(data.get('payments',{}))
        self.rows=dict(data.get('rows',{}))
        self.completed=set(data.get('completed',[]))
        self.folder=data.get('folder',motor.DEFAULT_FOLDER)
        for n in self.rows:
            if n not in self.completed:
                self.rows[n]='Pendiente'
    def save_queue(self):
        self.data_path.parent.mkdir(parents=True,exist_ok=True)
        temporary=self.data_path.with_suffix('.tmp')
        temporary.write_text(json.dumps({'rows':self.rows,'completed':sorted(self.completed),'folder':self.folder,'payments':self.payments},ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temporary,self.data_path)
    def set_status(self, number, text):
        with self.lock:
            self.rows[number]=text if number in self.completed or text.startswith('Completada') else 'Pendiente — '+text
            self.save_queue()
    def add_queue(self, values):
        text=values.get('facturas',[''])[0]
        numbers=motor.invoices(text) if text.strip() else []
        with self.lock:
            for n in numbers:self.rows.setdefault(n,'Pendiente')
            self.folder=values.get('folder',[self.folder])[0] or self.folder
            self.save_queue()
        return numbers
    def delete_pending(self, number):
        with self.lock:
            if self.running:
                raise ValueError('Detené la búsqueda y esperá a que termine antes de eliminar una factura.')
            if number not in self.rows or number in self.completed:
                raise ValueError('La factura no está pendiente.')
            del self.rows[number]
            self.save_queue()
            self.message='Factura '+number+' eliminada del listado.'
    def pending_text(self):
        with self.lock:
            return '\n'.join(n for n in self.rows if n not in self.completed)

    def run(self, values):
        self.add_queue(values)
        with self.lock:
            if self.running:
                raise ValueError('Ya hay una búsqueda en curso.')
            numbers=[n for n in self.rows if n not in self.completed]
            if not numbers:raise ValueError('No hay facturas pendientes.')
            user=values.get('usuario',[''])[0].strip()
            cuit=values.get('cuit',[''])[0].strip()
            password=values.get('password',[''])[0]
            saved_user, saved_cuit, saved_password = credentials.load_access()
            if not password and user == saved_user and motor.re.sub(r'\D','',cuit) == saved_cuit:
                password = saved_password
            if not user or len(motor.re.sub(r'\D','',cuit))!=11 or not password:
                raise ValueError('Completá usuario, CUIT de 11 dígitos y contraseña.')
            folder=Path(values.get('folder',[motor.DEFAULT_FOLDER])[0])
            folder.mkdir(parents=True,exist_ok=True)
            for n in numbers:self.rows[n]='Pendiente'
            self.save_queue()
            self.running=True
            self.stop.clear()
        threading.Thread(target=self.worker,args=(numbers,user,cuit,password,folder),daemon=True).start()
    def close_session(self):
        with self.lock:
            if self.running:
                raise ValueError('Detené la búsqueda y esperá a que termine antes de cerrar la sesión.')
            if self.portal:
                try:self.portal.driver.quit()
                except Exception:pass
            self.portal=None
            self.portal_user=None
            self.message='Sesión y navegador cerrados.'

    def get_portal(self,user,cuit,password):
        identity=(user,motor.re.sub(r'\D','',cuit))
        if self.portal:
            try:
                alive=bool(self.portal.driver.window_handles)
            except Exception:alive=False
            if not alive or self.portal_user!=identity:
                try:self.portal.driver.quit()
                except Exception:pass
                self.portal=None
        if self.portal is None:
            self.portal=motor.Portal(self.stop,lambda text:setattr(self,'message',text))
            self.portal_user=identity
            self.portal.login(user,cuit,password)
        else:
            self.portal.access=(user,cuit,password)
            self.message='Reutilizando la sesión abierta.'
        return self.portal

    def worker(self,numbers,user,cuit,password,folder):
        portal=None
        try:
            portal=self.get_portal(user,cuit,password)
            for number in numbers:
                if self.stop.is_set():break
                if number in self.completed:continue
                self.set_status(number,'Buscando')
                try:
                    records=portal.search(number)
                    if not records:
                        self.set_status(number,'Sin pago encontrado');continue
                    finished=[]
                    for record in records:
                        # Registrar descubrimientos antes del guardado, siempre pendientes.
                        with self.lock:
                            for n in record['numbers']:self.rows.setdefault(n,'Pendiente')
                            self.save_queue()
                        known=self.payments.get(record['key'])
                        if known and Path(known['path']).is_file() and set(known['numbers'])==set(record['numbers']):
                            path=Path(known['path'])
                        else:
                            path=folder/('_'.join(record['numbers'])+'.pdf')
                            if len(str(path))>240:
                                raise ValueError('El nombre con todas las facturas supera el límite de Windows. Elegí una carpeta de destino más corta.')
                            if path.exists():
                                import datetime
                                path=path.with_stem(path.stem+'_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
                            self.message='Guardando PDF de '+', '.join(record['numbers'])
                            motor.combined_pdf(path,record['captures'],record['pdfs'])
                            with self.lock:
                                self.payments[record['key']]={'path':str(path.resolve()),'numbers':record['numbers']}
                                self.save_queue()
                        finished.append((record,path))
                    # Solo completar después de generar todos los pagos de esta consulta.
                    with self.lock:
                        for record,path in finished:
                            for n in record['numbers']:
                                self.completed.add(n)
                                self.rows[n]='Completada — PDF guardado: '+path.name
                        self.save_queue()
                except InterruptedError:
                    self.set_status(number,'Detenida');break
                except Exception as exc:
                    detail=str(exc).strip() or type(exc).__name__
                    self.set_status(number,'Error: '+detail)
                    (self.data_path.parent/'ultimo_error_pagos.txt').write_text('Factura: '+number+'\n'+traceback.format_exc(),encoding='utf-8')
                    break
            self.message='Búsqueda finalizada. Revisá los estados antes de imprimir.'
        except Exception as exc:
            self.message='No se pudo completar: '+(str(exc).strip() or type(exc).__name__)
        finally:
            # Conservar la ventana y la sesión para el siguiente lote.
            self.running=False
            with self.lock:self.save_queue()


def handler_for(state,home_port):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def respond(self,content,kind='text/html; charset=utf-8'):
            raw=content.encode('utf-8'); self.send_response(200); self.send_header('Content-Type',kind); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
        def do_GET(self):
            if self.path=='/estado':
                self.respond(json.dumps({'message':state.message,'rows':dict(state.rows),'running':state.running,'completed':sorted(state.completed)},ensure_ascii=False),'application/json'); return
            try:
                user, cuit, password = credentials.load_access()
            except Exception:
                user, cuit, password = '', '', ''
            access = '<h2>Acceso al portal</h2><input name="usuario" placeholder="Usuario" value="'+html.escape(user,quote=True)+'" required><input name="cuit" placeholder="CUIT empresa" value="'+html.escape(cuit,quote=True)+'" required><input name="password" type="password" placeholder="'+('Contraseña guardada' if password else 'Contraseña')+'" autocomplete="new-password"><button formaction="/guardar" formnovalidate>Guardar datos de ingreso</button><p>La contraseña se guarda cifrada en Windows. Dejala vacía para utilizar la guardada.</p>'
            self.respond('''<!doctype html><meta charset="utf-8"><title>Pagos Rivadavia</title><style>body{font:16px Segoe UI;background:#eef3f8;color:#172033;max-width:1000px;margin:30px auto}section{background:white;padding:24px;border-radius:14px;margin:16px 0}input,textarea,button{font:inherit;padding:10px;margin:6px;border:1px solid #bcc9d7;border-radius:6px}textarea{width:90%;height:160px}button{background:#0875c9;color:white;cursor:pointer}td,th{padding:12px;text-align:left;border-bottom:1px solid #ddd}table{width:100%}</style>'''+f'<a href="http://127.0.0.1:{home_port}">← Inicio</a>'+'''<h1>Comprobantes de pagos — Rivadavia</h1><form method="post" action="/buscar"><section>'''+access+'''</section><section><h2>Facturas a buscar</h2><p>Pegá una por línea: 0083-00003243. También podés pegar dos columnas de Excel (punto y número).</p><textarea name="facturas">'''+html.escape(state.pending_text())+'''</textarea><button formaction="/lista" formnovalidate>Guardar pendientes</button><p>Carpeta de destino</p><input name="folder" style="width:90%" value="'''+html.escape(state.folder,quote=True)+'''"><p>Un PDF por cheque, con las facturas en el nombre. Incluye las capturas y todas las páginas de retenciones.</p><button>Iniciar búsqueda</button></section></form><form method="post" action="/detener"><button>Detener búsqueda</button></form><form method="post" action="/cerrar_sesion"><button>Cerrar sesión y navegador</button></form><section><p id="message"></p><table><thead><tr><th>Factura</th><th>Resultado</th><th>Acción</th></tr></thead><tbody id="rows"></tbody></table></section><script>const queue=document.querySelector('textarea[name=facturas]');let timer;let queueSave=Promise.resolve();queue.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>{const f=new FormData(queue.form);queueSave=fetch('/lista',{method:'POST',body:new URLSearchParams(f)})},800)});async function refresh(){const s=await(await fetch('/estado')).json();document.querySelector('#message').textContent=s.message;const b=document.querySelector('#rows');b.replaceChildren();for(const [n,v] of Object.entries(s.rows)){const r=document.createElement('tr');for(const [index,text] of [n,v].entries()){const c=document.createElement('td');if(index===1&&s.completed.includes(n)){c.textContent='Completa';c.title=text.replace(/^Completada — PDF guardado: /,'');c.tabIndex=0;c.setAttribute('aria-label','Completa. PDF: '+c.title)}else{c.textContent=text}r.append(c)}const action=document.createElement('td');if(!s.completed.includes(n)){const del=document.createElement('button');del.textContent='Eliminar';del.disabled=s.running;del.onclick=async()=>{if(!confirm('¿Eliminar '+n+' del listado de pendientes?'))return;clearTimeout(timer);await queueSave;queue.value=queue.value.split('\\n').filter(line=>{const m=line.trim().match(/^(\\d+)\\s*[-;/\t]\\s*(\\d+)$/);return !m||m[1].padStart(4,'0')+'-'+m[2].padStart(8,'0')!==n}).join('\\n');await fetch('/eliminar',{method:'POST',body:new URLSearchParams({factura:n})});refresh()};action.append(del)}r.append(action);b.append(r)}}setInterval(refresh,1500);refresh();</script>''')
        def do_POST(self):
            origin=self.headers.get('Origin')
            if origin and origin!='http://'+self.headers.get('Host',''):
                self.send_error(403);return
            length=int(self.headers.get('Content-Length',0))
            if length>1000000:self.send_error(413);return
            values=urllib.parse.parse_qs(self.rfile.read(length).decode())
            try:
                if self.path=='/guardar':
                    user=values.get('usuario',[''])[0].strip()
                    cuit=values.get('cuit',[''])[0]
                    password=values.get('password',[''])[0]
                    su,sc,sp=credentials.load_access()
                    if not password and user==su and motor.re.sub(r'\D','',cuit)==sc:password=sp
                    credentials.save_access(user,cuit,password)
                    state.message='Datos de ingreso guardados de forma cifrada en Windows.'
                elif self.path=='/cerrar_sesion':state.close_session()
                elif self.path=='/eliminar':state.delete_pending(values.get('factura',[''])[0])
                elif self.path=='/lista':state.add_queue(values);state.message='Lista de pendientes guardada.'
                elif self.path=='/buscar':state.run(values)
                elif self.path=='/detener':state.stop.set();state.message='Deteniendo en el próximo control.'
                else:self.send_error(404);return
            except Exception as exc:state.message=str(exc)
            self.send_response(303);self.send_header('Location','/');self.end_headers()
    return Handler
