@echo off
chcp 65001 >nul
setlocal
set "DEST=%LOCALAPPDATA%\CargadorFacturasAutosur\App"
if not exist "%DEST%" (echo No se encontro la aplicacion en: %DEST%&pause&exit /b 1)
taskkill /F /IM pythonw.exe >nul 2>&1
taskkill /F /IM python.exe >nul 2>&1
if exist "%DEST%\interfaz_pagos.py" copy /Y "%DEST%\interfaz_pagos.py" "%DEST%\interfaz_pagos.py.antes_v5.4.22" >nul
if exist "%DEST%\pagos_rivadavia.py" copy /Y "%DEST%\pagos_rivadavia.py" "%DEST%\pagos_rivadavia.py.antes_v5.4.22" >nul
copy /Y "%~dp0interfaz_pagos.py" "%DEST%\interfaz_pagos.py" >nul || goto :error
copy /Y "%~dp0pagos_rivadavia.py" "%DEST%\pagos_rivadavia.py" >nul || goto :error
copy /Y "%~dp0version.txt" "%DEST%\version.txt" >nul || goto :error
echo Reparacion V5.4.22 aplicada correctamente.
pause
exit /b 0
:error
echo No se pudo aplicar. Cerra la aplicacion y ejecuta este archivo otra vez.
pause
exit /b 1
