import html
import os
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

# El Python embebido de Windows no incluye automáticamente la carpeta del
# script en sys.path. Se agrega antes de importar los módulos del cargador.
APP_SOURCE_DIR = Path(__file__).resolve().parent
if str(APP_SOURCE_DIR) not in sys.path:
    sys.path.insert(0, str(APP_SOURCE_DIR))

import interfaz_rivadavia
import interfaz_san_cristobal
import interfaz_pagos


RIVADAVIA_FOLDER = Path(r"T:\SHAR-REN\JUAN AMARANTE\factura\rivadavia")
SAN_CRISTOBAL_FOLDER = Path(r"T:\SHAR-REN\JUAN AMARANTE\factura\san cristobal")
APP_VERSION = "5.2.7"
UPDATER_PATH = APP_SOURCE_DIR.parent / "actualizador.py"
APP_ROOT = APP_SOURCE_DIR.parent
PYTHONW_PATH = APP_ROOT / "Python" / "pythonw.exe"
ICON_PATH = APP_SOURCE_DIR / "assets" / "icono_cargador_facturas.ico"


STYLE = """
:root{font-family:Segoe UI,Arial,sans-serif;color:#172033;background:#eef3f8}*{box-sizing:border-box}body{margin:0}
.top{background:#14233d;color:white;padding:28px}.top h1{margin:0;font-size:28px}.top p{margin:7px 0 0;opacity:.82}
.wrap{max-width:1050px;margin:36px auto;padding:0 20px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:20px}
.card{background:white;border-radius:16px;padding:24px;box-shadow:0 6px 24px #15314e18;border-top:5px solid #0875c9}.card.sc{border-color:#4145e7}.card h2{margin:0 0 8px}.card p{color:#5d697a;min-height:48px}.path{font:12px Consolas,monospace;background:#f4f6f9;padding:10px;border-radius:8px;overflow-wrap:anywhere}.button{display:inline-block;margin-top:18px;padding:12px 20px;border-radius:9px;background:#0875c9;color:white;text-decoration:none;font-weight:700}.sc .button{background:#4145e7}.disabled{display:inline-block;margin-top:18px;padding:12px 20px;border-radius:9px;background:#ccd2da;color:#69717c;font-weight:700}.note{margin-top:25px;padding:15px;background:#fff7d8;border-left:4px solid #e8aa21;border-radius:8px;color:#674d11}.update{display:inline-block;margin-top:18px;margin-left:10px;padding:12px 20px;border-radius:9px;background:#1d9a66;color:white;text-decoration:none;font-weight:700}
"""


class HomeHandler(BaseHTTPRequestHandler):
    ports = {}

    def log_message(self, _format, *_args):
        pass

    def do_GET(self):
        if self.path.startswith("/actualizar"):
            self.start_update()
            return
        if self.path == "/retorno":
            page = b"Restaurando V5.1.3. Se abrira sin buscar actualizaciones."
            self.send_response(200); self.end_headers(); self.wfile.write(page)
            def rollback():
                subprocess.Popen([sys.executable, str(APP_SOURCE_DIR / "retorno.py"), str(os.getpid())], cwd=APP_SOURCE_DIR)
                time.sleep(1)
                os._exit(0)
            threading.Thread(target=rollback, daemon=True).start()
            return
        cards = []
        platforms = [
            ("rivadavia", "Seguros Rivadavia", RIVADAVIA_FOLDER, "Motor estable V4.12 para Google Forms.", ""),
            ("san", "San Cristóbal", SAN_CRISTOBAL_FOLDER, "Carga por portal, credenciales cifradas y control por lote.", "sc"),
        ]
        for key, title, folder, description, css in platforms:
            port = self.ports.get(key)
            action = f'<a class="button" href="http://127.0.0.1:{port}/">Abrir cargador</a>' if port else '<span class="disabled">Carpeta no disponible</span>'
            cards.append(f'<div class="card {css}"><h2>{html.escape(title)}</h2><p>{html.escape(description)}</p><div class="path">{html.escape(str(folder))}</div>{action}</div>')
        port = self.ports.get("pagos")
        cards.append(f'<div class="card"><h2>Comprobantes de pagos Rivadavia</h2><p>Consulta por lote y PDF combinado para imprimir.</p><a class="button" href="http://127.0.0.1:{port}/">Buscar pagos</a></div>')
        cards.append('<div class="card"><h2>Punto de retorno V5.1.3</h2><p>Restaura la versión anterior. Las credenciales, registros y PDF se conservan. Cerrá primero cualquier carga en curso.</p><a class="button" href="/retorno" onclick="return confirm(&quot;¿Cerrar la app y volver a V5.1.3?&quot;)">Volver a V5.1.3</a></div>')
        update_button = '<a class="update" href="/actualizar">Buscar actualizaciones</a>' if UPDATER_PATH.exists() else ""
        page = f"""<!doctype html><html><head><meta charset="utf-8"><title>Cargador de facturas Autosur V{APP_VERSION}</title><style>{STYLE}</style></head><body>
        <div class="top"><h1>Cargador de facturas Autosur V{APP_VERSION}</h1><p>Elegí la aseguradora. Cada plataforma mantiene su propio registro de enviados.</p></div>
        <div class="wrap"><div class="grid">{''.join(cards)}</div><div class="note">Primero utilizá <b>Probar primera sin enviar</b>. Cuando confirmes que todos los datos están correctos, continuá con el lote.</div>{update_button}</div></body></html>""".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

    def start_update(self):
        if not UPDATER_PATH.exists():
            page = b"El actualizador no esta instalado."
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(page)))
            self.end_headers()
            self.wfile.write(page)
            return
        page = """<!doctype html><meta charset="utf-8"><style>body{font:18px Segoe UI;padding:40px;background:#eef3f8;color:#172033}</style><h2>Buscando actualizaciones...</h2><p>La aplicación se cerrará y volverá a abrir automáticamente.</p>""".encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)

        def restart_with_updater():
            time.sleep(1)
            subprocess.Popen(
                [sys.executable, str(UPDATER_PATH), "--force", "--wait-pid", str(os.getpid())],
                cwd=str(UPDATER_PATH.parent),
            )
            time.sleep(0.5)
            os._exit(0)

        threading.Thread(target=restart_with_updater, daemon=True).start()


def serve(server):
    threading.Thread(target=server.serve_forever, daemon=True).start()


def relaunch_with_pythonw():
    """En la primera actualización, abandona python.exe y continúa sin consola."""
    if os.name != "nt" or Path(sys.executable).name.lower() != "python.exe":
        return False
    if not PYTHONW_PATH.exists():
        return False
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    subprocess.Popen(
        [str(PYTHONW_PATH), str(Path(__file__).resolve())],
        cwd=str(APP_SOURCE_DIR),
        close_fds=True,
        creationflags=creationflags,
    )
    return True


def ensure_gui_shortcut():
    """Migra el acceso directo antiguo para abrir la app sin consola."""
    if os.name != "nt" or not PYTHONW_PATH.exists() or not UPDATER_PATH.exists():
        return
    icon = ICON_PATH if ICON_PATH.exists() else PYTHONW_PATH
    script = f'''Set shell = CreateObject("WScript.Shell")
shortcut = shell.SpecialFolders("Desktop") & "\\Cargador Facturas Autosur.lnk"
Set link = shell.CreateShortcut(shortcut)
link.TargetPath = "{str(PYTHONW_PATH).replace(chr(34), chr(34) + chr(34))}"
link.Arguments = Chr(34) & "{str(UPDATER_PATH).replace(chr(34), chr(34) + chr(34))}" & Chr(34)
link.WorkingDirectory = "{str(APP_ROOT).replace(chr(34), chr(34) + chr(34))}"
link.IconLocation = "{str(icon).replace(chr(34), chr(34) + chr(34))},0"
link.Description = "Cargador de facturas Autosur"
link.Save
'''
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".vbs", encoding="utf-8-sig", delete=False
        ) as stream:
            stream.write(script)
            temporary = Path(stream.name)
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.run(
            ["wscript.exe", "//B", "//Nologo", str(temporary)],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creationflags,
        )
    except Exception:
        pass
    finally:
        if temporary:
            temporary.unlink(missing_ok=True)


def main():
    if relaunch_with_pythonw():
        return
    ensure_gui_shortcut()
    home = ThreadingHTTPServer(("127.0.0.1", 0), HomeHandler)
    home_port = home.server_port
    ports = {}

    if RIVADAVIA_FOLDER.exists():
        state = interfaz_rivadavia.AppState(RIVADAVIA_FOLDER)
        interfaz_rivadavia.HOME_PORT = home_port
        server = ThreadingHTTPServer(("127.0.0.1", 0), interfaz_rivadavia.handler_for(state))
        ports["rivadavia"] = server.server_port
        serve(server)

    if SAN_CRISTOBAL_FOLDER.exists():
        state = interfaz_san_cristobal.AppState(SAN_CRISTOBAL_FOLDER)
        server = ThreadingHTTPServer(("127.0.0.1", 0), interfaz_san_cristobal.handler_for(state, home_port))
        ports["san"] = server.server_port
        serve(server)

    payments = ThreadingHTTPServer(("127.0.0.1", 0), interfaz_pagos.handler_for(interfaz_pagos.State(), home_port))
    ports["pagos"] = payments.server_port
    serve(payments)
    HomeHandler.ports = ports
    url = f"http://127.0.0.1:{home_port}/"
    webbrowser.open(url)
    home.serve_forever()


if __name__ == "__main__":
    main()

