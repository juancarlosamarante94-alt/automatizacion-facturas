import csv
import ctypes
import json
import os
import re
import shutil
import socket
import subprocess
import time
import unicodedata
from ctypes import wintypes
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from pypdf import PdfReader
from selenium import webdriver
from selenium.common.exceptions import ElementClickInterceptedException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait

import rivadavia as common


LOGIN_URL = "https://proveedores.sancristobal.com.ar/auth/ingresar"
PROVINCIA = "Chubut"
RUBRO = "Repuestero"
IVA_ALICUOTA = "21%"
# Perfil exclusivo del cargador. Se cambia en V5.0.6 para no reutilizar el
# perfil anterior, donde Chrome pudo haber dejado abierto el aviso de
# contraseña comprometida. El administrador de contraseñas del navegador no
# es necesario: las credenciales ya se guardan cifradas por Windows.
PROFILE_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "CargadorFacturasAutosur" / "ChromeSanCristobalV506"
DEBUG_PORT = 9229
CREDENTIAL_TARGET = "CargadorFacturasAutosur/SanCristobal"


def norm(value):
    value = unicodedata.normalize("NFD", str(value or "").lower())
    value = "".join(c for c in value if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", value).strip()


def only_digits(value):
    return re.sub(r"\D", "", str(value or ""))


def login_cuit_digits(value):
    """Devuelve los 11 dígitos; el portal aplica su propia máscara de guiones."""
    digits = only_digits(value)
    if len(digits) != 11:
        raise ValueError("El CUIT guardado debe tener exactamente 11 dígitos")
    return digits


def normalize_claim(value):
    digits = only_digits(value)
    if len(digits) != 12:
        return ""
    return f"{digits[:2]}-{digits[2:4]}-{digits[4:]}"


def normalize_date(value):
    return common.normalize_date(value)


def money_text(value):
    return common.money_text(value)


def money_decimal(value):
    return common.money_decimal(value)


def first_match(patterns, text, flags=re.I | re.S):
    return common.first_match(patterns, text, flags)


def is_credit_invoice(text):
    return common.is_electronic_credit_invoice(text)


@dataclass
class Invoice:
    archivo: str
    punto_venta: str = ""
    numero: str = ""
    siniestro: str = ""
    fecha: str = ""
    tipo_comprobante: str = "Factura"
    letra: str = "A"
    moneda: str = "ARS"
    tipo_autorizacion: str = "CAE"
    cae: str = ""
    provincia: str = PROVINCIA
    rubro: str = RUBRO
    cantidad: str = "1"
    neto: str = ""
    iva: str = ""
    total: str = ""

    @property
    def factura(self):
        return f"{self.punto_venta}-{self.numero}" if self.punto_venta and self.numero else ""

    def validate(self):
        required = ("punto_venta", "numero", "siniestro", "fecha", "cae", "neto", "iva", "total")
        missing = [field for field in required if not getattr(self, field)]
        if missing:
            return False, "faltan " + ", ".join(missing)
        if not re.fullmatch(r"\d{4}", self.punto_venta):
            return False, "el punto de venta debe tener 4 dígitos"
        if not re.fullmatch(r"\d{8}", self.numero):
            return False, "el número de comprobante debe tener 8 dígitos"
        if not re.fullmatch(r"\d{2}-\d{2}-\d{8}", self.siniestro):
            return False, "el siniestro debe tener 12 dígitos"
        net, tax, total = map(money_decimal, (self.neto, self.iva, self.total))
        if None in (net, tax, total):
            return False, "hay importes ilegibles"
        if abs((net + tax) - total) > Decimal("0.03"):
            return False, "neto + IVA no coincide con el total"
        return True, "OK"


DATE = r"\d{1,2}[/-]\d{1,2}[/-]\d{4}"


def _extract_claim(page1, page2):
    # La orden (segunda hoja) es la fuente prioritaria. Nro Cotización de la
    # factura queda como respaldo para PDF con páginas faltantes.
    patterns_explicit = [
        r"Nro\s*Siniestro\s*:?\s*(?:\n\s*)?([0-9][0-9\s/-]{10,18}[0-9])",
        r"Siniestro\s*:?\s*(?:\n\s*)?([0-9][0-9\s/-]{10,18}[0-9])",
    ]
    patterns_quote = [
        r"Nro\s*Cotizaci[oó]n\s*[-:]?\s*([0-9][0-9\s/-]{10,18}[0-9])",
        r"Cotizaci[oó]n\s*[-:]?\s*([0-9][0-9\s/-]{10,18}[0-9])",
    ]
    value = first_match(patterns_explicit, page2)
    if len(only_digits(value)) != 12:
        value = first_match(patterns_explicit, page1)
    if len(only_digits(value)) != 12:
        value = first_match(patterns_quote, page1)
    return normalize_claim(value)


def parse_invoice(path, strict=True):
    path = Path(path)
    reader = PdfReader(str(path))
    pages = [(page.extract_text() or "").replace("\x00", " ") for page in reader.pages]
    if not pages or not pages[0].strip():
        raise ValueError("la primera hoja no contiene texto legible")
    page1 = pages[0]
    page2 = pages[1] if len(pages) > 1 else ""

    number_match = re.search(
        r"(?:Nro\.?|N[°º]\s*comprobante)\s*:?\s*0*(\d{1,4})\s*[-–]\s*0*(\d{1,8})",
        page1, re.I,
    )
    if not number_match:
        number_match = re.search(r"\b(\d{4})\s*[-_]\s*(\d{8})\b", page1)
    if not number_match:
        file_match = re.search(r"\b(\d{2,4})\s*[-_]\s*(\d{1,8})\b", path.stem)
        number_match = file_match

    point = number = ""
    if number_match:
        point = only_digits(number_match.group(1)).zfill(4)
        number = only_digits(number_match.group(2)).zfill(8)

    fecha = first_match([
        rf"Fecha\s*:?\s*({DATE})",
        rf"Fecha\s+de\s+emisi[oó]n\s*:?\s*({DATE})",
    ], page1)
    cae = first_match([r"CAE(?:\s*Nro\.?)?\s*:?\s*(\d{14})", r"\bCAE[\s\S]{0,80}?\b(\d{14})\b"], page1)
    neto, iva, total = common.extract_amounts(page1)
    values = [money_decimal(value) for value in (neto, iva, total)]
    if None in values or abs((values[0] + values[1]) - values[2]) > Decimal("0.03"):
        ocr = common.ocr_first_page(path)
        ocr_neto, ocr_iva, ocr_total = common.extract_ocr_amounts(ocr)
        neto, iva, total = ocr_neto or neto, ocr_iva or iva, ocr_total or total

    invoice = Invoice(
        archivo=str(path.resolve()),
        punto_venta=point,
        numero=number,
        siniestro=_extract_claim(page1, page2),
        fecha=normalize_date(fecha) if fecha else "",
        tipo_comprobante="Factura de Crédito Electrónica" if is_credit_invoice(page1) else "Factura",
        cae=cae,
        neto=neto,
        iva=iva,
        total=total,
    )
    valid, reason = invoice.validate()
    if strict and not valid:
        raise ValueError(reason)
    return invoice


class CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
        ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
        ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
        ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD),
        ("Attributes", wintypes.LPVOID), ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR),
    ]


def save_credentials(username, password):
    if os.name != "nt":
        raise RuntimeError("Las credenciales solo se guardan en Windows")
    if not username or not password:
        raise ValueError("Ingresá CUIT y contraseña")
    blob = password.encode("utf-16-le")
    buffer = (ctypes.c_ubyte * len(blob)).from_buffer_copy(blob)
    credential = CREDENTIALW()
    credential.Type = 1  # CRED_TYPE_GENERIC
    credential.TargetName = CREDENTIAL_TARGET
    credential.CredentialBlobSize = len(blob)
    credential.CredentialBlob = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
    credential.Persist = 2  # CRED_PERSIST_LOCAL_MACHINE
    credential.UserName = username
    if not ctypes.windll.advapi32.CredWriteW(ctypes.byref(credential), 0):
        raise ctypes.WinError()


def load_credentials():
    if os.name != "nt":
        return "", ""
    pointer = ctypes.POINTER(CREDENTIALW)()
    if not ctypes.windll.advapi32.CredReadW(CREDENTIAL_TARGET, 1, 0, ctypes.byref(pointer)):
        return "", ""
    try:
        credential = pointer.contents
        raw = ctypes.string_at(credential.CredentialBlob, credential.CredentialBlobSize)
        return credential.UserName or "", raw.decode("utf-16-le")
    finally:
        ctypes.windll.advapi32.CredFree(pointer)


def chrome_path():
    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    return next((path for path in candidates if path.exists()), None)


def port_open(port):
    with socket.socket() as sock:
        sock.settimeout(0.25)
        return sock.connect_ex(("127.0.0.1", port)) == 0


def prepare_chrome_profile():
    """Desactiva el gestor de claves solo en el perfil aislado del cargador."""
    default_dir = PROFILE_DIR / "Default"
    preferences_path = default_dir / "Preferences"
    default_dir.mkdir(parents=True, exist_ok=True)
    preferences = {}
    if preferences_path.exists():
        try:
            preferences = json.loads(preferences_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            preferences = {}
    preferences["credentials_enable_service"] = False
    profile = preferences.setdefault("profile", {})
    profile["password_manager_enabled"] = False
    profile["password_manager_leak_detection"] = False
    temporary = preferences_path.with_suffix(".tmp")
    temporary.write_text(json.dumps(preferences, ensure_ascii=False), encoding="utf-8")
    temporary.replace(preferences_path)


def chrome_automation_arguments():
    return [
        f"--remote-debugging-port={DEBUG_PORT}",
        f"--user-data-dir={PROFILE_DIR}",
        "--lang=es-AR",
        "--start-maximized",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-save-password-bubble",
        "--disable-features=PasswordLeakDetection,PasswordManagerOnboarding",
    ]


def start_chrome():
    chrome = chrome_path()
    if not chrome:
        raise RuntimeError("No encontré Google Chrome instalado")
    if not port_open(DEBUG_PORT):
        prepare_chrome_profile()
        subprocess.Popen(
            [str(chrome), *chrome_automation_arguments(), LOGIN_URL],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    deadline = time.time() + 35
    while time.time() < deadline and not port_open(DEBUG_PORT):
        time.sleep(0.25)
    if not port_open(DEBUG_PORT):
        raise RuntimeError("Chrome no habilitó la conexión del cargador")
    options = webdriver.ChromeOptions()
    options.debugger_address = f"127.0.0.1:{DEBUG_PORT}"
    driver = webdriver.Chrome(options=options)
    driver.set_window_size(1400, 950)
    return driver


def body_text(driver):
    try:
        return norm(driver.find_element(By.TAG_NAME, "body").text)
    except Exception:
        return ""


def visible(elements):
    result = []
    for element in elements:
        try:
            if element.is_displayed():
                result.append(element)
        except StaleElementReferenceException:
            continue
    return result


def clear_and_type(driver, element, value, numeric=False):
    value = str(value)
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    try:
        element.click()
    except ElementClickInterceptedException:
        driver.execute_script("arguments[0].click();", element)
    element.send_keys(Keys.CONTROL, "a")
    element.send_keys(Keys.BACKSPACE)
    element.send_keys(value)
    element.send_keys(Keys.TAB)
    time.sleep(0.25)
    current = str(element.get_attribute("value") or "")
    if numeric:
        if only_digits(current) != only_digits(value):
            raise RuntimeError(f"El portal modificó '{value}' y dejó '{current}'")
    elif value and norm(value) not in norm(current) and norm(current) not in norm(value):
        raise RuntimeError(f"El portal modificó '{value}' y dejó '{current}'")


SPANISH_MONTHS = {
    "enero": 1, "febrero": 2, "marzo": 3, "abril": 4,
    "mayo": 5, "junio": 6, "julio": 7, "agosto": 8,
    "septiembre": 9, "setiembre": 9, "octubre": 10,
    "noviembre": 11, "diciembre": 12,
}


def calendar_month(text):
    normalized = norm(text)
    for name, number in SPANISH_MONTHS.items():
        match = re.search(rf"\b{name}\s+(20\d{{2}})\b", normalized)
        if match:
            return int(match.group(1)), number
    return None


def visible_calendar_header(driver):
    candidates = []
    for element in visible(driver.find_elements(By.XPATH, "//*[self::div or self::span or self::button]")):
        try:
            parsed = calendar_month(element.text)
            if parsed:
                rect = element.rect
                height = rect.get("height", 9999)
                width = rect.get("width", 0)
                # La barra azul mide aproximadamente 50 px de alto. Se evita
                # elegir el panel completo, que también contiene mes y año.
                geometry_penalty = 0 if height <= 90 and width >= 180 else 1
                candidates.append((geometry_penalty, len((element.text or "").strip()), element, parsed))
        except StaleElementReferenceException:
            continue
    if not candidates:
        return None
    _, length, element, parsed = min(candidates, key=lambda item: (item[0], item[1]))
    return length, element, parsed


def calendar_arrow(driver, header, direction):
    wanted_words = ("anterior", "previous", "prev") if direction < 0 else ("siguiente", "next")
    current = header
    for _ in range(7):
        try:
            buttons = visible(current.find_elements(By.CSS_SELECTOR, "button,[role='button']"))
            for button in buttons:
                description = norm(" ".join(filter(None, [
                    button.text, button.get_attribute("aria-label"), button.get_attribute("title")
                ])))
                if any(word in description for word in wanted_words):
                    return button
            # Los dos botones sin texto que rodean al encabezado son las flechas.
            if len(buttons) >= 2:
                ordered = sorted(buttons, key=lambda item: item.rect.get("x", 0))
                return ordered[0] if direction < 0 else ordered[-1]
            current = current.find_element(By.XPATH, "..")
        except Exception:
            break
    return None


def click_calendar_arrow(driver, header, direction):
    """Pulsa la flecha gráfica usando su posición en la barra azul."""
    clicked = driver.execute_script("""
        const header=arguments[0], direction=arguments[1];
        const rect=header.getBoundingClientRect();
        const x=direction < 0 ? rect.left + 24 : rect.right - 24;
        const y=rect.top + rect.height / 2;
        let target=document.elementFromPoint(x,y);
        if(!target)return false;
        const control=target.closest('button,[role="button"],a') || target;
        for(const type of ['pointerdown','mousedown','pointerup','mouseup','click']){
            control.dispatchEvent(new MouseEvent(type,{
                bubbles:true,cancelable:true,clientX:x,clientY:y,view:window
            }));
        }
        return true;
    """, header, direction)
    if clicked:
        return True
    arrow = calendar_arrow(driver, header, direction)
    if not arrow:
        return False
    try:
        arrow.click()
    except Exception:
        driver.execute_script("arguments[0].click();", arrow)
    return True


def calendar_container(header):
    """Devuelve el contenedor más pequeño que reúne la grilla del calendario."""
    current = header
    best = None
    for _ in range(8):
        try:
            numeric = current.find_elements(
                By.XPATH,
                ".//*[self::button or @role='button' or self::td or self::div or self::span]"
                "[string-length(normalize-space(text())) <= 2 and number(normalize-space(text())) >= 1]",
            )
            if len(numeric) >= 20:
                best = current
                break
            current = current.find_element(By.XPATH, "..")
        except Exception:
            break
    return best


def set_date(driver, element, value):
    day_text, month_text, year_text = normalize_date(value).split("/")
    target_day, target_month, target_year = int(day_text), int(month_text), int(year_text)
    display_value = f"{target_day:02d}/{target_month:02d}/{target_year:04d}"
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    try:
        element.click()
    except Exception:
        driver.execute_script("arguments[0].click();", element)

    def exact_header(d):
        month = year = None
        for button in visible(d.find_elements(By.CSS_SELECTOR, "button.current")):
            text = norm(button.text)
            if text in SPANISH_MONTHS:
                month = SPANISH_MONTHS[text]
            elif re.fullmatch(r"20\d{2}", text):
                year = int(text)
        return (year, month) if year and month else False

    shown_year, shown_month = WebDriverWait(driver, 15).until(exact_header)
    for _ in range(240):
        difference = (target_year - shown_year) * 12 + target_month - shown_month
        if difference == 0:
            break
        previous = (shown_year, shown_month)
        selector = "button.previous" if difference < 0 else "button.next"
        arrows = visible(driver.find_elements(By.CSS_SELECTOR, selector))
        if not arrows:
            raise RuntimeError(f"No encontré {selector} en el calendario")
        arrows[0].click()

        def changed_calendar(d):
            current = exact_header(d)
            return current if current and current != previous else False

        shown_year, shown_month = WebDriverWait(driver, 10).until(changed_calendar)
    else:
        raise RuntimeError(f"El calendario no pudo llegar a {target_month:02d}/{target_year}")

    def target_date(d):
        # El diagnóstico real del portal muestra que el evento está conectado
        # al SPAN, no al TD. Los días grises se distinguen por is-other-month.
        for candidate in visible(d.find_elements(
            By.CSS_SELECTOR, "table.days.weeks td span"
        )):
            try:
                classes = norm(candidate.get_attribute("class"))
                if (
                    candidate.text.strip() == str(target_day)
                    and "is-other-month" not in classes
                    and "disabled" not in classes
                ):
                    return candidate
            except StaleElementReferenceException:
                continue
        return False

    day_span = WebDriverWait(driver, 15).until(target_date)
    # Clic nativo directo sobre el span que tiene enlazado el manejador Angular.
    day_span.click()
    try:
        WebDriverWait(driver, 10).until(
            lambda _d: date_value_matches(element.get_attribute("value"), display_value)
        )
    except TimeoutException as exc:
        current = element.get_attribute("value") or "vacío"
        raise RuntimeError(
            f"El calendario no confirmó {display_value}; el campo quedó en {current}"
        ) from exc


def date_value_matches(current, expected):
    current_digits = only_digits(current)
    day, month, year = normalize_date(expected).split("/")
    return current_digits in {f"{day}{month}{year}", f"{year}{month}{day}"}


def close_calendar(driver):
    """Cierra ngx-bootstrap datepicker antes de completar otros campos."""
    calendars = visible(driver.find_elements(By.CSS_SELECTOR, "bs-datepicker-container"))
    if not calendars:
        return
    try:
        driver.switch_to.active_element.send_keys(Keys.ESCAPE)
    except Exception:
        pass
    try:
        WebDriverWait(driver, 5).until(
            lambda d: not visible(d.find_elements(By.CSS_SELECTOR, "bs-datepicker-container"))
        )
        return
    except TimeoutException:
        pass
    # Respaldo: un clic en el título queda fuera del calendario y Angular
    # ejecuta el cierre normal por pérdida de foco.
    headings = visible(driver.find_elements(
        By.XPATH, "//*[self::h1 or self::h2 or self::h3][contains(normalize-space(.),'Datos Adicionales')]"
    ))
    if headings:
        driver.execute_script("arguments[0].click();", headings[0])
    WebDriverWait(driver, 5).until(
        lambda d: not visible(d.find_elements(By.CSS_SELECTOR, "bs-datepicker-container"))
    )


def exact_input(driver, element_id, label):
    try:
        element = driver.find_element(By.ID, element_id)
    except Exception as exc:
        raise RuntimeError(f"No encontré {label} ({element_id})") from exc
    if not element.is_displayed():
        raise RuntimeError(f"El campo {label} no está visible")
    return element


def select_dropdown_by_id(driver, element_id, option, label, timeout=25):
    """Selecciona una opción del sc-select usando el id real del portal."""
    wanted = norm(option)

    def control(d):
        try:
            element = d.find_element(By.ID, element_id)
            return element if element.is_displayed() else False
        except Exception:
            return False

    ctl = WebDriverWait(driver, timeout).until(control)
    if wanted in norm(ctl.get_attribute("value")):
        return
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", ctl)
    ctl.click()

    def option_element(d):
        selectors = ".sc-select__item,[role='option'],li"
        for candidate in visible(d.find_elements(By.CSS_SELECTOR, selectors)):
            if norm(candidate.text) == wanted:
                return candidate
        return False

    target = WebDriverWait(driver, timeout).until(option_element)
    target.click()
    try:
        WebDriverWait(driver, timeout).until(
            lambda d: wanted in norm(control(d).get_attribute("value")) if control(d) else False
        )
    except TimeoutException as exc:
        current = ctl.get_attribute("value") or "vacío"
        raise RuntimeError(
            f"El portal no confirmó {label} '{option}'; quedó en '{current}'"
        ) from exc


def find_input(driver, *names):
    wanted = [norm(name) for name in names if name]
    for element in visible(driver.find_elements(By.CSS_SELECTOR, "input,textarea")):
        text = " ".join(filter(None, [
            element.get_attribute("placeholder"), element.get_attribute("aria-label"),
            element.get_attribute("name"), element.get_attribute("id"),
        ]))
        normalized = norm(text)
        if any(name in normalized or normalized in name for name in wanted if normalized):
            return element
    for name in names:
        escaped = str(name).replace("'", "")
        xpath = (
            f"//*[self::label or self::legend or self::span or self::div][contains(normalize-space(.),'{escaped}')]/"
            "ancestor::*[.//input or .//textarea][1]//input[not(@type='file')]|"
            f"//*[self::label or self::legend or self::span or self::div][contains(normalize-space(.),'{escaped}')]/"
            "ancestor::*[.//input or .//textarea][1]//textarea"
        )
        matches = visible(driver.find_elements(By.XPATH, xpath))
        if matches:
            return matches[0]
    return None


def click_text(driver, text, timeout=25):
    wanted = norm(text)

    def locate(d):
        selectors = "button,a,[role='button'],[role='menuitem'],[role='tab']"
        for element in visible(d.find_elements(By.CSS_SELECTOR, selectors)):
            if norm(element.text or element.get_attribute("aria-label")) == wanted:
                return element
        for element in visible(d.find_elements(By.XPATH, "//*[normalize-space(text())=" + repr(text) + "]")):
            return element
        return False

    element = WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(locate)
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    try:
        element.click()
    except Exception:
        driver.execute_script("arguments[0].click();", element)
    return element


def select_dropdown(driver, label, option, timeout=25):
    wanted = norm(option)

    def control(d):
        label_elements = visible(d.find_elements(By.XPATH,
            "//*[self::label or self::legend or self::span or self::div][normalize-space(text())=" + repr(label) + "]"
        ))
        for label_element in label_elements:
            current = label_element
            for _ in range(6):
                try:
                    candidates = visible(current.find_elements(By.CSS_SELECTOR,
                        "[role='combobox'],select,input,button,.sc-select,.sc-dropdown"
                    ))
                    if candidates:
                        return candidates[0]
                    current = current.find_element(By.XPATH, "..")
                except Exception:
                    break
        for element in visible(d.find_elements(By.CSS_SELECTOR, "[role='combobox'],select,input")):
            description = norm(" ".join(filter(None, [element.get_attribute("placeholder"), element.get_attribute("aria-label"), element.text])))
            if norm(label) in description:
                return element
        return False

    ctl = WebDriverWait(driver, timeout).until(control)
    if ctl.tag_name.lower() == "select":
        from selenium.webdriver.support.ui import Select
        Select(ctl).select_by_visible_text(option)
        return
    current_text = norm((ctl.get_attribute("value") or "") + " " + (ctl.text or ""))
    if wanted in current_text:
        return
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", ctl)
    try:
        ctl.click()
    except Exception:
        driver.execute_script("arguments[0].click();", ctl)

    def exact_option(d):
        candidates = visible(d.find_elements(By.CSS_SELECTOR,
            "[role='option'],li,.sc-select__option,.sc-dropdown__option,.mat-option"
        ))
        for candidate in candidates:
            if norm(candidate.text or candidate.get_attribute("data-value") or candidate.get_attribute("aria-label")) == wanted:
                return candidate
        # Algunas opciones son div flotantes sin role. Solo se acepta texto exacto.
        for candidate in visible(d.find_elements(By.XPATH, "//*[normalize-space(text())=" + repr(option) + "]")):
            if candidate != ctl:
                return candidate
        return False

    target = WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(exact_option)
    try:
        target.click()
    except Exception:
        driver.execute_script("arguments[0].click();", target)
    def selection_confirmed(d):
        fresh = control(d)
        if not fresh:
            return False
        values = [fresh.get_attribute("value"), fresh.get_attribute("aria-label"), fresh.text]
        current = fresh
        for _ in range(3):
            try:
                current = current.find_element(By.XPATH, "..")
                values.append(current.text)
            except Exception:
                break
        expanded = (fresh.get_attribute("aria-expanded") or "false").lower()
        return expanded != "true" and any(wanted in norm(value) for value in values if value)

    try:
        WebDriverWait(driver, timeout).until(selection_confirmed)
    except TimeoutException as exc:
        raise RuntimeError(f"El portal no confirmó la selección '{option}'") from exc


def enabled_text_button(driver, label):
    wanted = norm(label)
    for element in visible(driver.find_elements(By.CSS_SELECTOR, "button,a,[role='button']")):
        try:
            if (
                norm(element.text) == wanted
                and element.is_enabled()
                and element.get_attribute("aria-disabled") != "true"
                and "disabled" not in norm(element.get_attribute("class"))
            ):
                return element
        except StaleElementReferenceException:
            continue
    return None


def file_inputs(driver):
    """Devuelve inputs de archivo incluso cuando React los mantiene ocultos."""
    found = list(driver.find_elements(By.CSS_SELECTOR, "input[type='file']"))
    try:
        shadow_inputs = driver.execute_script("""
            const result=[];
            const visit=root=>{
                if(!root || !root.querySelectorAll)return;
                for(const input of root.querySelectorAll('input[type="file"]')){
                    result.push(input);
                }
                for(const element of root.querySelectorAll('*')){
                    if(element.shadowRoot)visit(element.shadowRoot);
                }
            };
            visit(document);
            return result;
        """) or []
        found.extend(shadow_inputs)
    except Exception:
        pass
    unique = []
    identifiers = set()
    for element in found:
        try:
            identifier = element.id
        except Exception:
            identifier = id(element)
        if identifier not in identifiers:
            identifiers.add(identifier)
            unique.append(element)
    return unique


def reveal_file_input(driver, element):
    driver.execute_script("""
        const el=arguments[0];
        el.hidden=false;
        el.removeAttribute('hidden');
        el.style.display='block';
        el.style.visibility='visible';
        el.style.opacity='1';
        el.style.position='fixed';
        el.style.left='0';
        el.style.bottom='0';
        el.style.zIndex='2147483647';
    """, element)


def cdp_set_file_input(driver, file_path):
    """Carga el archivo por Chrome DevTools aunque el input esté oculto."""
    driver.execute_cdp_cmd("DOM.enable", {})
    document = driver.execute_cdp_cmd(
        "DOM.getFlattenedDocument", {"depth": -1, "pierce": True}
    )
    candidates = []
    for node in document.get("nodes", []):
        if str(node.get("nodeName", "")).upper() != "INPUT":
            continue
        raw_attributes = node.get("attributes", [])
        attributes = dict(zip(raw_attributes[0::2], raw_attributes[1::2]))
        if str(attributes.get("type", "")).lower() == "file":
            candidates.append(node)
    if not candidates:
        raise RuntimeError("Chrome no encontró el control interno para seleccionar el PDF")
    target = candidates[-1]
    arguments = {"files": [str(Path(file_path).resolve())]}
    if target.get("backendNodeId"):
        arguments["backendNodeId"] = target["backendNodeId"]
    elif target.get("nodeId"):
        arguments["nodeId"] = target["nodeId"]
    else:
        raise RuntimeError("El control de archivo no tiene identificador de Chrome")
    driver.execute_cdp_cmd("DOM.setFileInputFiles", arguments)


def choose_file_in_windows_dialog(file_path, timeout=20):
    """Escribe el PDF y pulsa Abrir en el selector nativo de Windows."""
    if os.name != "nt":
        return False
    user32 = ctypes.windll.user32
    WM_SETTEXT = 0x000C
    BM_CLICK = 0x00F5
    deadline = time.time() + timeout
    while time.time() < deadline:
        dialog = user32.FindWindowW("#32770", None)
        if dialog:
            # 1148 es el campo "Nombre de archivo" y 1 es el botón Abrir.
            edit = user32.GetDlgItem(dialog, 1148)
            open_button = user32.GetDlgItem(dialog, 1)
            if edit and open_button:
                user32.SendMessageW(edit, WM_SETTEXT, 0, str(Path(file_path).resolve()))
                user32.SendMessageW(open_button, BM_CLICK, 0, 0)
                return True
        time.sleep(0.25)
    return False


def upload_pdf(driver, file_path, section_text=None, timeout=600, status=lambda _message: None):
    file_path = str(Path(file_path).resolve())
    filename = Path(file_path).name
    if not section_text and norm(filename) in body_text(driver):
        return
    # San Cristóbal prepara el componente solamente después de un clic real en
    # "Subir archivo". Se activa siempre, aunque ya exista un input oculto.
    status(f"Haciendo clic en Subir archivo para {filename}...")
    click_text(driver, "Subir archivo", timeout=20)
    # El portal abre el selector nativo de Windows. Mientras esa ventana está
    # abierta Chrome bloquea los comandos de Selenium/CDP, por eso debe
    # completarse antes de volver a consultar el navegador.
    status(f"Seleccionando {filename} en la ventana de Windows...")
    if choose_file_in_windows_dialog(file_path, timeout=20):
        selected_input = None

        def native_uploaded(d):
            text = body_text(d)
            if norm(filename) in text and "cargando" not in text:
                return True
            if norm(section_text) == "factura":
                return bool(enabled_text_button(d, "Continuar")) or "datos adicionales" in text
            return "acepto las condiciones impositivas" in text

        WebDriverWait(driver, 90).until(native_uploaded)
        return

    time.sleep(0.5)
    try:
        inputs = WebDriverWait(driver, 15).until(lambda d: file_inputs(d) or False)
    except TimeoutException:
        inputs = []
    if section_text and len(inputs) > 1:
        # En cada pantalla actual del portal hay un solo cargador; si aparecieran
        # varios se prefiere el último, que corresponde a Documentación.
        inputs = inputs[-1:]
    selected_input = inputs[-1] if inputs else None

    def uploaded(d):
        text = body_text(d)
        try:
            input_value = norm(selected_input.get_attribute("value")) if selected_input is not None else ""
        except StaleElementReferenceException:
            input_value = ""
        if norm(filename) in input_value:
            return True
        # Si el usuario ya pulsó Continuar, el input anterior fue eliminado por
        # React. La aparición del paso 3 confirma que el PDF fue aceptado.
        if norm(section_text) == "factura" and "datos adicionales" in text:
            return True
        if norm(filename) in text and "cargando" not in text:
            return True
        if norm(section_text) == "factura":
            # En el paso 2 Continuar solo se habilita al terminar la subida.
            return bool(enabled_text_button(d, "Continuar"))
        # La documentación respaldatoria es opcional y Continuar puede estar
        # habilitado antes de adjuntar. Si el usuario ya avanzó, se reconoce la
        # revisión final por el texto de aceptación impositiva.
        return "acepto las condiciones impositivas" in text

    automatic_error = None
    try:
        status(f"Seleccionando {filename} en Chrome...")
        cdp_set_file_input(driver, file_path)
        WebDriverWait(driver, 90).until(uploaded)
        return
    except Exception as exc:
        automatic_error = exc

    # Respaldo para versiones del portal que exponen un input tradicional.
    if selected_input is not None:
        for attempt in range(2):
            try:
                if attempt:
                    reveal_file_input(driver, selected_input)
                status(f"Adjuntando automáticamente {filename}...")
                selected_input.send_keys(file_path)
                WebDriverWait(driver, 60).until(uploaded)
                return
            except Exception as exc:
                automatic_error = exc
                # React puede reemplazar el input después del primer intento.
                refreshed = file_inputs(driver)
                if refreshed:
                    selected_input = refreshed[-1]

    status(
        f"No pude adjuntar automáticamente {filename}. Adjuntalo manualmente en Chrome; "
        "el cargador continuará solo cuando termine la subida."
    )
    try:
        WebDriverWait(driver, timeout).until(uploaded)
    except TimeoutException as exc:
        detail = f" ({automatic_error})" if automatic_error else ""
        raise RuntimeError(f"No se confirmó la carga del PDF{detail}") from exc


def verify_portal_totals(driver, invoice, timeout=20):
    expected_net = money_decimal(invoice.neto)
    expected_tax = money_decimal(invoice.iva)
    expected_total = money_decimal(invoice.total)

    def amounts(d):
        result = {}
        # Leer únicamente los importes del formulario. El visor PDF también
        # contiene textos como "IVA 21.00" y, al buscar sobre todo el body,
        # ese porcentaje podía confundirse con el importe calculado de IVA.
        selectors = {
            "net": ".credit-memo-items__subtotal__amount",
            "tax": ".credit-memo-items__vat__amount",
            "total": ".additional-data__invoice-total-container__total",
        }
        for key, selector in selectors.items():
            for element in d.find_elements(By.CSS_SELECTOR, selector):
                matches = re.findall(common.MONEY, element.text or "")
                if matches:
                    result[key] = money_decimal(matches[-1])
                    break

        # Respaldo limitado al formulario izquierdo para cambios menores de
        # clases en el portal; nunca incluye el visor de la factura.
        if len(result) < 3:
            forms = d.find_elements(By.CSS_SELECTOR, "sc-additional-data form")
            raw = "\n".join(element.text for element in forms)
            for key, label in (("net", "Subtotal"), ("tax", "IVA"), ("total", "Total")):
                if key in result:
                    continue
                matches = re.findall(rf"{label}\s*\$?\s*({common.MONEY})", raw, re.I)
                if matches:
                    result[key] = money_decimal(matches[0])
        return result

    def confirmed(d):
        found = amounts(d)
        return (
            found.get("net") == expected_net
            and found.get("tax") == expected_tax
            and found.get("total") == expected_total
        )

    try:
        WebDriverWait(driver, timeout).until(confirmed)
    except TimeoutException as exc:
        found = amounts(driver)
        raise RuntimeError(
            "Los importes calculados por San Cristóbal no coinciden con la factura "
            f"(portal: {found or 'sin importes visibles'})"
        ) from exc


def wait_clickable_text(driver, label, timeout=90):
    def ready(d):
        return enabled_text_button(d, label) or False

    element = WebDriverWait(driver, timeout).until(ready)
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    try:
        element.click()
    except Exception:
        driver.execute_script("arguments[0].click();", element)
    return element


def ensure_login(driver, status=lambda _message: None):
    if "auth/ingresar" not in driver.current_url and not find_input(driver, "Contraseña", "field_password__input"):
        return
    driver.get(LOGIN_URL)
    WebDriverWait(driver, 30).until(lambda d: find_input(d, "CUIT", "field_userId__input"))
    username, password = load_credentials()
    if not username or not password:
        raise RuntimeError("Guardá el CUIT y la contraseña de San Cristóbal desde el panel")
    # El campo de San Cristóbal inserta los guiones automáticamente. Si se
    # escriben los guiones guardados, la máscara duplica el último y descarta
    # el dígito verificador. Por eso se envían únicamente los 11 números.
    username_digits = login_cuit_digits(username)
    cuit_field = find_input(driver, "CUIT", "field_userId__input")
    clear_and_type(driver, cuit_field, username_digits, numeric=True)
    if only_digits(cuit_field.get_attribute("value")) != username_digits:
        raise RuntimeError("El portal modificó el CUIT antes de iniciar sesión")
    clear_and_type(driver, find_input(driver, "Contraseña", "field_password__input"), password)
    wait_clickable_text(driver, "Ingresar", timeout=20)

    deadline = time.time() + 600
    announced = False
    validation_notice = ""
    while time.time() < deadline:
        if "auth/ingresar" not in driver.current_url and not find_input(driver, "Contraseña", "field_password__input"):
            status("Sesión iniciada en San Cristóbal.")
            return
        text = body_text(driver)
        problem = next((message for message in ("incorrect", "inval", "bloquead", "no coincide") if message in text), "")
        if problem and problem != validation_notice:
            status(
                "San Cristóbal mostró una validación. Corregí el acceso en Chrome y presioná Ingresar; "
                "el cargador seguirá automáticamente cuando entre al portal."
            )
            validation_notice = problem
        if not announced and time.time() > deadline - 585:
            if not problem:
                status("Si aparece un CAPTCHA, completalo en Chrome. El cargador continuará automáticamente.")
            announced = True
        time.sleep(1)
    raise RuntimeError("No se completó el inicio de sesión en San Cristóbal dentro de 10 minutos")


def navigate_to_claim(driver):
    if response_recorded(driver):
        wait_clickable_text(driver, "Cargar nuevo comprobante", timeout=45)
        WebDriverWait(driver, 60).until(lambda d: "numero de siniestro" in body_text(d))
        return
    if "numero de siniestro" in body_text(driver):
        return
    for label in ("Cargar", "Comprobantes", "Con número de siniestro"):
        click_text(driver, label, timeout=40)
        time.sleep(0.6)
    WebDriverWait(driver, 40).until(lambda d: "numero de siniestro" in body_text(d))


def find_claim_input(driver, timeout=30):
    """Localiza el control React del siniestro sin depender de un id fijo."""
    wanted = ("numero de siniestro", "nro de siniestro", "siniestro")

    def locate(d):
        candidates = []
        for element in visible(d.find_elements(By.CSS_SELECTOR, "input:not([type='hidden']):not([type='file']),textarea")):
            try:
                kind = (element.get_attribute("type") or "text").lower()
                if kind not in ("text", "tel", "number", "search"):
                    continue
                description = norm(" ".join(filter(None, [
                    element.get_attribute("placeholder"),
                    element.get_attribute("aria-label"),
                    element.get_attribute("name"),
                    element.get_attribute("id"),
                    element.get_attribute("data-testid"),
                ])))
                if any(label in description for label in wanted):
                    return element
                candidates.append(element)
            except StaleElementReferenceException:
                continue

        # Respaldo para versiones del portal que dejan el input sin atributos:
        # en el paso 1 existe un único campo de texto editable.
        if "numero de siniestro" in body_text(d) and len(candidates) == 1:
            return candidates[0]
        return False

    try:
        return WebDriverWait(
            driver, timeout, ignored_exceptions=(StaleElementReferenceException,)
        ).until(locate)
    except TimeoutException as exc:
        raise RuntimeError("No encontré el campo editable Número de Siniestro") from exc


def set_claim_value(driver, digits, timeout=30):
    """Completa y confirma el valor en el input controlado por React."""
    if len(digits) != 12:
        raise RuntimeError("El siniestro preparado no contiene exactamente 12 dígitos")

    field = find_claim_input(driver, timeout)
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", field)
    try:
        field.click()
    except Exception:
        driver.execute_script("arguments[0].click();", field)

    # Primer intento por teclado: permite que la máscara del portal coloque
    # automáticamente los guiones sin perder el estado interno de React.
    field.send_keys(Keys.CONTROL, "a")
    field.send_keys(Keys.BACKSPACE)
    field.send_keys(digits)
    field.send_keys(Keys.TAB)

    def confirmed(d):
        fresh = find_claim_input(d, timeout=2)
        return fresh if only_digits(fresh.get_attribute("value")) == digits else False

    try:
        return WebDriverWait(
            driver, 5, ignored_exceptions=(StaleElementReferenceException, RuntimeError)
        ).until(confirmed)
    except TimeoutException:
        # Respaldo para el componente controlado: usar el setter nativo y
        # disparar los mismos eventos que procesa React.
        field = find_claim_input(driver, timeout)
        driver.execute_script("""
            const el=arguments[0], value=arguments[1];
            const previous=el.value;
            const setter=Object.getOwnPropertyDescriptor(
                window.HTMLInputElement.prototype,'value'
            ).set;
            setter.call(el,value);
            if(el._valueTracker){el._valueTracker.setValue(previous)}
            try{
                el.dispatchEvent(new InputEvent('input',{
                    bubbles:true,inputType:'insertText',data:value
                }));
            }catch(_error){
                el.dispatchEvent(new Event('input',{bubbles:true}));
            }
            el.dispatchEvent(new Event('change',{bubbles:true}));
            el.dispatchEvent(new Event('blur',{bubbles:true}));
            el.blur();
        """, field, digits)
        try:
            return WebDriverWait(
                driver, 8, ignored_exceptions=(StaleElementReferenceException, RuntimeError)
            ).until(confirmed)
        except TimeoutException as exc:
            current = only_digits(find_claim_input(driver, timeout).get_attribute("value"))
            raise RuntimeError(
                f"San Cristóbal no confirmó el siniestro {digits}; el campo quedó en {current or 'vacío'}"
            ) from exc


def fill_claim_step(driver, invoice):
    digits = only_digits(invoice.siniestro)
    set_claim_value(driver, digits)
    # No intentar pulsar Validar mientras siga gris. Su habilitación confirma
    # que React recibió los 12 dígitos y no solo que el texto se ve en pantalla.
    wait_clickable_text(driver, "Validar", timeout=30)
    wait_clickable_text(driver, "Continuar", timeout=90)


def fill_invoice_upload_step(driver, invoice, status=lambda _message: None):
    WebDriverWait(driver, 45).until(lambda d: "factura" in body_text(d))
    upload_pdf(driver, invoice.archivo, "Factura", status=status)
    # Si el usuario ya pulsó Continuar mientras la automatización esperaba el
    # adjunto, no hay que buscar nuevamente el botón en el paso 3.
    if "datos adicionales" not in body_text(driver):
        wait_clickable_text(driver, "Continuar", timeout=120)
    WebDriverWait(driver, 60).until(lambda d: "datos adicionales" in body_text(d))


def fill_additional_data(driver, invoice, status=lambda _message: None):
    WebDriverWait(driver, 45).until(lambda d: "datos adicionales" in body_text(d))
    date_field = find_input(driver, "Fecha de comprobante", "Fecha")
    if not date_field:
        raise RuntimeError("No encontré Fecha de comprobante")
    status(f"Seleccionando la fecha {invoice.fecha} en el calendario...")
    set_date(driver, date_field, invoice.fecha)
    close_calendar(driver)
    status("Fecha confirmada. Completando los datos del comprobante...")
    select_dropdown_by_id(driver, "voucherType__input", invoice.tipo_comprobante, "Tipo de comprobante")
    select_dropdown_by_id(driver, "letter__input", invoice.letra, "Letra")
    point = exact_input(driver, "field_pointOfSale__input", "Punto de venta")
    receipt = exact_input(driver, "field_voucherNumber__input", "N° comprobante")
    authorization = exact_input(driver, "field_authorizationNumber__input", "N° código autorización")
    clear_and_type(driver, point, invoice.punto_venta, numeric=True)
    clear_and_type(driver, receipt, invoice.numero, numeric=True)
    try:
        select_dropdown_by_id(
            driver, "authorizationType__input", invoice.tipo_autorizacion, "Tipo de autorización"
        )
    except Exception:
        if "cae" not in body_text(driver):
            raise
    # El lector del portal suele completar el CAE. Se conserva ese valor y
    # solamente se escribe el de la factura cuando el campo sigue vacío.
    portal_cae = only_digits(authorization.get_attribute("value"))
    if not portal_cae:
        clear_and_type(driver, authorization, invoice.cae, numeric=True)
    elif len(portal_cae) != 14:
        raise RuntimeError(f"El CAE detectado por el portal quedó incompleto: {portal_cae}")
    currency = exact_input(driver, "field_currencyCode__input", "Moneda")
    if norm(currency.get_attribute("value")) != norm(invoice.moneda):
        clear_and_type(driver, currency, invoice.moneda)
    select_dropdown_by_id(driver, "province__input", invoice.provincia, "Provincia")

    select_dropdown_by_id(
        driver, "description-detail-description_0__input", invoice.rubro, "Rubro"
    )
    quantity = exact_input(driver, "field_quantity__input", "Cantidad")
    price = exact_input(driver, "field_unitPrice__input", "Precio Unitario")
    clear_and_type(driver, quantity, invoice.cantidad, numeric=True)
    clear_and_type(driver, price, money_text(invoice.neto), numeric=True)
    try:
        select_dropdown_by_id(driver, "taxPercentage__input", IVA_ALICUOTA, "IVA")
    except Exception:
        if "21%" not in body_text(driver):
            raise

    verify_portal_totals(driver, invoice)

    upload_pdf(driver, invoice.archivo, "Documentación", status=status)
    for checkbox in driver.find_elements(By.CSS_SELECTOR, "input[type='checkbox']"):
        try:
            parent_text = norm(checkbox.find_element(By.XPATH, "ancestor::*[contains(.,'Percepci')][1]").text)
            if "percepcion" in parent_text and checkbox.is_selected():
                driver.execute_script("arguments[0].click();", checkbox)
        except Exception:
            continue
    wait_clickable_text(driver, "Continuar", timeout=90)


def prepare_final_review(driver):
    WebDriverWait(driver, 60).until(lambda d: "acepto las condiciones impositivas" in body_text(d) or "enviar" in body_text(d))
    boxes = visible(driver.find_elements(By.CSS_SELECTOR, "input[type='checkbox'],[role='checkbox']"))
    target = None
    for box in boxes:
        try:
            container = box.find_element(By.XPATH, "ancestor::*[contains(.,'Acepto las condiciones')][1]")
            if container:
                target = box
                break
        except Exception:
            continue
    if not target:
        raise RuntimeError("No encontré la aceptación de condiciones impositivas")
    selected = target.is_selected() if target.tag_name.lower() == "input" else target.get_attribute("aria-checked") == "true"
    if not selected:
        try:
            target.click()
        except Exception:
            driver.execute_script("arguments[0].click();", target)
    WebDriverWait(driver, 20).until(lambda d: any(
        norm(element.text) == "enviar" and element.is_enabled()
        for element in visible(d.find_elements(By.CSS_SELECTOR, "button,[role='button']"))
    ))


def response_recorded(driver):
    return "el comprobante fue cargado con exito" in body_text(driver)


def submit_prepared(driver, prepare_next=False):
    wait_clickable_text(driver, "Enviar", timeout=30)
    WebDriverWait(driver, 90).until(response_recorded)
    if prepare_next:
        wait_clickable_text(driver, "Cargar nuevo comprobante", timeout=45)
        WebDriverWait(driver, 60).until(lambda d: "numero de siniestro" in body_text(d))
    return "ENVIADA"


def complete_invoice(driver, invoice, submit=False, status=lambda _message: None):
    ensure_login(driver, status)
    navigate_to_claim(driver)
    fill_claim_step(driver, invoice)
    fill_invoice_upload_step(driver, invoice, status=status)
    fill_additional_data(driver, invoice, status=status)
    prepare_final_review(driver)
    if not submit:
        return "LISTA_PARA_REVISAR"
    return submit_prepared(driver, prepare_next=True)


def reset_for_next(driver, status=lambda _message: None):
    """Recupera una pantalla intermedia sin arriesgar la factura siguiente."""
    status("Recuperando el portal para continuar con la próxima factura...")
    driver.get(LOGIN_URL)
    ensure_login(driver, status)
    navigate_to_claim(driver)


def log_path(folder):
    return Path(folder) / "registro_envios_san_cristobal.csv"


def sent_numbers(folder):
    path = log_path(folder)
    if not path.exists():
        return set()
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return {
            (row.get("factura") or "").strip() for row in csv.DictReader(stream)
            if (row.get("estado") or "").strip().upper() == "ENVIADA"
        }


def register(invoice, folder, status, detail=""):
    path = log_path(folder)
    new = not path.exists()
    fields = ["fecha_hora", "factura", "siniestro", "neto", "iva", "total", "archivo", "estado", "detalle"]
    with path.open("a", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        if new:
            writer.writeheader()
        writer.writerow({
            "fecha_hora": datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
            "factura": invoice.factura, "siniestro": invoice.siniestro,
            "neto": invoice.neto, "iva": invoice.iva, "total": invoice.total,
            "archivo": Path(invoice.archivo).name, "estado": status, "detalle": detail,
        })


def move_sent(invoice, folder):
    destination_dir = Path(folder) / "FACTURAS_ENVIADAS"
    destination_dir.mkdir(exist_ok=True)
    source = Path(invoice.archivo)
    if not source.exists():
        return
    destination = destination_dir / source.name
    if destination.exists():
        destination = destination_dir / f"{source.stem}_{datetime.now():%Y%m%d_%H%M%S}{source.suffix}"
    shutil.move(str(source), str(destination))

