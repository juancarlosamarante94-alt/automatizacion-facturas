import ctypes
import os
import json
from ctypes import wintypes
CREDENTIAL_TARGET = "CargadorFacturasAutosur/PagosRivadavia"

class CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
        ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
        ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.POINTER(ctypes.c_ubyte)),
        ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD),
        ("Attributes", wintypes.LPVOID), ("TargetAlias", wintypes.LPWSTR), ("UserName", wintypes.LPWSTR),
    ]


def save_credentials(username, password):
    if os.name != "nt":
        raise RuntimeError("Las credenciales solo se guardan en Windows")
    if not username or not password:
        raise ValueError("Ingresá CUIT y contraseña")
    blob = password.encode("utf-16-le")
    buffer = (ctypes.c_ubyte * len(blob)).from_buffer_copy(blob)
    credential = CREDENTIALW()
    credential.Type = 1  # CRED_TYPE_GENERIC
    credential.TargetName = CREDENTIAL_TARGET
    credential.CredentialBlobSize = len(blob)
    credential.CredentialBlob = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
    credential.Persist = 2  # CRED_PERSIST_LOCAL_MACHINE
    credential.UserName = username
    if not ctypes.windll.advapi32.CredWriteW(ctypes.byref(credential), 0):
        raise ctypes.WinError()


def load_credentials():
    if os.name != "nt":
        return "", ""
    pointer = ctypes.POINTER(CREDENTIALW)()
    if not ctypes.windll.advapi32.CredReadW(CREDENTIAL_TARGET, 1, 0, ctypes.byref(pointer)):
        return "", ""
    try:
        credential = pointer.contents
        raw = ctypes.string_at(credential.CredentialBlob, credential.CredentialBlobSize)
        return credential.UserName or "", raw.decode("utf-16-le")
    finally:
        ctypes.windll.advapi32.CredFree(pointer)


_raw_save = save_credentials
_raw_load = load_credentials

def save_access(user, cuit, password):
    import re
    cuit = re.sub(r"\D", "", cuit)
    if not user.strip() or len(cuit) != 11 or not password:
        raise ValueError("Completá usuario, CUIT de 11 dígitos y contraseña.")
    _raw_save(json.dumps([user.strip(), cuit]), password)

def load_access():
    username, password = _raw_load()
    if not username:
        return "", "", ""
    user, cuit = json.loads(username)
    return user, cuit, password
