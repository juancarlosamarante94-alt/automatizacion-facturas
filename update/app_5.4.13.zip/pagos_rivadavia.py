"""Consulta de solo lectura: nunca marca cheques como recibidos."""
import base64
import io
import json
import os
import re
import tempfile
import time
from pathlib import Path
from urllib.parse import urljoin, urlparse
import urllib.request
import unicodedata
import fitz
from selenium import webdriver
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException, NoSuchFrameException, ElementClickInterceptedException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support.wait import WebDriverWait

LOGIN = 'https://www.sistemas.segurosrivadavia.com/sistemas/login/login.php?u=B'
DEFAULT_FOLDER = r'C:\Users\Usuario\Desktop\pagos rivadavia'

def no_payments(text):
    text = ' '.join(text.lower().split())
    return 'no existen pagos para el comprobante' in text

def consultation_url(current_url):
    parsed=urlparse(current_url)
    host=(parsed.hostname or '').lower()
    if parsed.scheme!='https' or not (host=='segurosrivadavia.com' or host.endswith('.segurosrivadavia.com')):
        raise RuntimeError('La sesión no está en el portal de Rivadavia. Volvé a iniciar la búsqueda.')
    return parsed.scheme+'://'+parsed.netloc+'/sistemas/beneficiarios/consulta_pagos.php'

class StableDetail:
    """Espera contenido y geometría sin cambios durante un intervalo continuo."""
    def __init__(self, seconds=1.5):
        self.seconds=seconds
        self.signature=None
        self.since=None
    def observe(self, signature, valid=True, now=None):
        now=time.monotonic() if now is None else now
        if not valid:
            self.signature=None;self.since=None
            return False
        if signature!=self.signature:
            self.signature=signature;self.since=now
            return False
        return self.since is not None and now-self.since>=self.seconds


def heading(cell):
    text=cell.text or cell.get_attribute('textContent') or ''
    # Normalizar espacios no separables, acentos y saltos de línea del encabezado.
    text=unicodedata.normalize('NFKD',text).lower()
    return ' '.join(''.join(c for c in text if not unicodedata.combining(c)).split())

def invoices(text):
    result = []
    for line in text.splitlines():
        if not line.strip():
            continue
        m = re.fullmatch(r'\s*(\d{1,5})\s*[-;/\t]\s*(\d{1,8})\s*', line)
        if not m:
            raise ValueError('Factura inválida: ' + line + '. Usá punto-número, una por línea.')
        value = m[1].zfill(4) + '-' + m[2].zfill(8)
        if value not in result:
            result.append(value)
    if not result:
        raise ValueError('Ingresá al menos una factura.')
    return result

def screenshot_pdf(png):
    doc = fitz.open()
    image = fitz.open(stream=png, filetype='png')
    rect = image[0].rect
    # A4 horizontal; divide capturas altas en páginas sin reducir la letra.
    width, height, margin = 842, 595, 24
    scale = (width - 2 * margin) / rect.width
    slice_height = (height - 2 * margin) / scale
    y = 0
    while y < rect.height:
        clip = fitz.Rect(0, y, rect.width, min(rect.height, y + slice_height))
        pix = image[0].get_pixmap(clip=clip)
        page = doc.new_page(width=width, height=height)
        page.insert_image(fitz.Rect(margin, margin, width-margin, margin+clip.height*scale), stream=pix.tobytes('png'))
        y += slice_height
    image.close()
    return doc

def combined_pdf(destination, captures, retentions):
    doc=fitz.open()
    page=None
    y=24
    width,height,margin=842,595,24
    def new_page():
        return doc.new_page(width=width,height=height)
    def draw(raw):
        nonlocal page,y
        im=fitz.open(stream=raw,filetype='png')
        h=im[0].rect.height*(width-2*margin)/im[0].rect.width
        if h>height-2*margin:
            raise ValueError('Una fila supera el alto imprimible; requiere revisión para no cortar datos.')
        if page is None or y+h>height-margin:
            page=new_page();y=margin
        page.insert_image(fitz.Rect(margin,y,width-margin,y+h),stream=raw)
        y+=h
        im.close()
    for capture in captures:
        if not isinstance(capture,dict):
            draw(capture);y+=12;continue
        header=capture['header']
        def image_height(raw):
            im=fitz.open(stream=raw,filetype='png');r=im[0].rect;im.close()
            return r.height*(width-2*margin)/r.width
        hh=image_height(header)
        first=image_height(capture['rows'][0]) if capture['rows'] else 0
        if page is None or y+26+hh+first>height-margin:
            page=new_page();y=margin
        page.insert_text((margin,y+12),capture['title'],fontsize=11);y+=22
        draw(header)
        for raw in capture['rows']:
            rh=image_height(raw)
            if y+rh>height-margin:
                page=new_page();y=margin
                if hh+rh>height-2*margin:raise ValueError('Fila demasiado alta para imprimir completa.')
                draw(header)
            draw(raw)
        y+=16
    for raw in retentions:
        part=fitz.open(stream=raw,filetype='pdf')
        if part.needs_pass and not part.authenticate(''):
            raise ValueError('La retención requiere contraseña.')
        doc.insert_pdf(part);part.close()
    if not doc.page_count:raise ValueError('No hay páginas para guardar.')
    destination=Path(destination);temp=destination.with_suffix('.tmp.pdf')
    try:
        doc.save(temp,garbage=4,deflate=True);doc.close()
        with fitz.open(temp) as check:
            if not check.page_count:raise ValueError('PDF vacío.')
        os.replace(temp,destination)
    finally:temp.unlink(missing_ok=True)


def aligned_cell(cells, header_rect):
    center=header_rect['x']+header_rect['width']/2
    matches=[]
    for cell in cells:
        rect=cell.rect
        if rect['width']>0 and rect['x']-1 <= center <= rect['x']+rect['width']+1:
            matches.append(cell)
    if len(matches)!=1:
        raise RuntimeError('No se pudo alinear la celda con su encabezado. No se abrió ningún importe.')
    return matches[0]

class Portal:
    def __init__(self, stopped, status):
        self.stopped, self.status = stopped, status
        options = webdriver.ChromeOptions()
        options.add_experimental_option('prefs', {'credentials_enable_service': False, 'profile.password_manager_enabled': False})
        self.driver = webdriver.Chrome(options=options)
        self.driver.set_window_size(1440, 1000)
        self.driver.set_page_load_timeout(60)
        self.main_handle=self.driver.current_window_handle
        self.step="Inicio"
    def check(self):
        if self.stopped.is_set():
            raise InterruptedError('Búsqueda detenida.')
    def find_context(self, predicate):
        d = self.driver
        d.switch_to.default_content()
        def visit(depth):
            value = predicate()
            if value:
                return value
            if depth > 5:
                return None
            frames = d.find_elements(By.CSS_SELECTOR, 'frame,iframe')
            for frame in frames:
                d.switch_to.frame(frame)
                value = visit(depth+1)
                if value:
                    return value
                d.switch_to.parent_frame()
            return None
        return visit(0)
    def wait(self, predicate, seconds=45):
        def poll(_):
            self.check()
            try:
                return self.find_context(predicate)
            except (StaleElementReferenceException, NoSuchFrameException, ElementClickInterceptedException):
                self.driver.switch_to.default_content()
                return False
        return WebDriverWait(self.driver, seconds).until(poll)
    def links(self, text):
        return next((e for e in self.driver.find_elements(By.CSS_SELECTOR, 'a,button,input[type=submit],input[type=button]') if e.is_displayed() and (e.text.strip() or e.get_attribute('value') or '').lower() == text.lower()), None)
    def click(self, text):
        self.wait(lambda: self._click_found(self.links(text)))
    @staticmethod
    def _click_found(element):
        if element is None:
            return False
        if not element.is_displayed() or not element.is_enabled():
            return False
        element.click()
        return True

    def login(self, user, cuit, password):
        self.access=(user,cuit,password)
        self.driver.get(LOGIN)
        for key, value in [('usuario', user), ('cuit', re.sub(r'\D','',cuit)), ('password', password)]:
            element = self.driver.find_element(By.ID, key)
            element.clear()
            element.send_keys(value)
        self.wait(lambda: self._click_found(next(iter(self.driver.find_elements(By.ID, 'btn_ingresar')), None)), 120)
        self.status('Accediendo. Si aparece una validación, completala en Chrome; sigo esperando.')
        submitted_tokens = set()
        def access_ready():
            link = next((e for e in self.driver.find_elements(By.TAG_NAME,'a') if 'Consulta Gral. de Pagos' in e.text),None)
            if link:
                self.status('Ingreso confirmado. Continuando búsqueda.')
                return link
            # Solo observa la respuesta que generó la resolución manual.
            tokens = self.driver.find_elements(By.CSS_SELECTOR, 'textarea[name="g-recaptcha-response"],textarea[name="h-captcha-response"],input[name="cf-turnstile-response"]')
            for element in tokens:
                token = element.get_attribute('value') or ''
                if token and token not in submitted_tokens:
                    buttons = self.driver.find_elements(By.ID, 'btn_ingresar')
                    if buttons and buttons[0].is_displayed():
                        buttons[0].click()
                        submitted_tokens.add(token)
                    break
            return False
        self.status('Esperando ingreso. Si aparece CAPTCHA, resolvelo en Chrome; continuaré automáticamente (hasta 10 minutos).')
        self.wait(access_ready, 600)
    def search(self, invoice):
        for attempt in range(3):
            try:
                return self._search_once(invoice)
            except (StaleElementReferenceException, NoSuchFrameException, ElementClickInterceptedException) as exc:
                if attempt == 2:
                    raise RuntimeError("El portal renovó controles durante: "+self.step+". Error original: "+type(exc).__name__) from exc
                self.status("El portal renovó la página. Reintentando consulta " + str(attempt+1) + "/2...")
                self.driver.switch_to.default_content()
        return []

    def _search_once(self, invoice):
        # El menú lateral no existe en todas las pantallas del portal.
        # Navegar al formulario en el origen de la sesión conserva sus cookies.
        self.check()
        self.step='Abrir formulario de consulta'
        self.status('Abriendo consulta de pagos para '+invoice)
        self.driver.switch_to.window(self.main_handle)
        self.driver.switch_to.default_content()
        url=consultation_url(self.driver.current_url)
        self.driver.get(url)
        login_fields=self.driver.find_elements(By.ID,'password')
        if any(e.is_displayed() for e in login_fields):
            self.status('La sesión venció. Reingresando; si aparece CAPTCHA, completalo en Chrome.')
            self.login(*self.access)
            self.driver.get(url)
        def form():
            for e in self.driver.find_elements(By.TAG_NAME,'select'):
                if e.is_displayed() and any(o.text.strip()=='Factura' for o in Select(e).options):
                    return e
        self.step='Seleccionar Factura'
        def select_invoice():
            control=form()
            if control is None:return False
            selected=Select(control)
            if selected.first_selected_option.text.strip()!='Factura':
                selected.select_by_visible_text('Factura')
                return False
            return True
        self.wait(select_invoice)
        def fields():
            control=form()
            if control is None:return []
            row=control.find_element(By.XPATH,'./ancestor::*[.//input[not(@type="hidden")]][1]')
            return [e for e in row.find_elements(By.TAG_NAME,'input') if e.is_displayed() and (e.get_attribute('type') or 'text') in ('text','number','tel')]
        for index,value in enumerate(invoice.split('-')):
            self.step='Completar '+('punto de venta' if index==0 else 'número de factura')
            def fill():
                controls=fields()
                if len(controls)!=2:return False
                field=controls[index]
                if re.sub(r'\D','',field.get_attribute('value') or '').lstrip('0')==value.lstrip('0'):return True
                field.clear()
                # El portal puede recrear controles al vaciar: buscar de nuevo.
                controls=fields()
                if len(controls)!=2:return False
                controls[index].send_keys(value)
                return False
            self.wait(fill)
        self.step='Aplicar búsqueda'
        self.click('Aplicar')
        def result_ready():
            body = self.driver.find_element(By.TAG_NAME,'body').text.lower()
            if no_payments(body):
                return 'NO_PAYMENTS'
            return self.links('Consulta') or ('sin resultados' in body) or ('no se encontraron' in body)
        outcome = self.wait(result_ready)
        if outcome == 'NO_PAYMENTS':
            self.click('Aceptar')
            self.wait(lambda: not no_payments(self.driver.find_element(By.TAG_NAME,'body').text))
            self.status('Sin pago encontrado. Continuando con la próxima factura.')
            return []
        body = self.driver.find_element(By.TAG_NAME,'body').text
        if not self.links('Consulta'):
            return []
        # Captura la pantalla completa, incluidos resultados debajo del pliegue.
        if re.search(r'Página\s+\d+\s*/\s*(?:[2-9]|[1-9]\d+)\b', body):
            raise RuntimeError('Hay varias páginas de pagos; requiere revisión manual en esta primera versión.')
        # La lista inicial solo filtra la factura: no se imprime.
        rows = self.payment_links()
        results_url = self.driver.current_url
        saved = []
        for index in range(len(rows)):
            self.check()
            links = self.payment_links()
            self.step='Abrir Consulta del pago'
            links[index].click()
            self.wait(lambda: 'Retención' in self.driver.find_element(By.TAG_NAME,'body').text)
            if re.search(r'Página\s+\d+\s*/\s*(?:[2-9]|[1-9]\d+)\b', self.driver.find_element(By.TAG_NAME,'body').text):
                raise RuntimeError('Hay varias páginas de cheques; requiere revisión manual.')
            saved.extend(self.read_cheques(invoice=invoice))
            # El último cheque ya está completo: devolver los datos para generar
            # el PDF antes de efectuar cualquier navegación adicional.
            if index + 1 < len(rows):
                self.driver.get(results_url)
                self.wait(lambda: self.links('Consulta'))
        # Si hay más páginas, fallar explícitamente para no declarar completo un respaldo parcial.
        if re.search(r'Página\s+\d+\s*/\s*[2-9]\d*', body):
            raise RuntimeError('Hay varias páginas de pagos. Requiere revisión; no se declaró completada la factura.')
        return saved
    def open_new_cheques(self):
        self.check()
        self.driver.switch_to.window(self.main_handle)
        self.driver.switch_to.default_content()
        url=consultation_url(self.driver.current_url).replace('consulta_pagos.php','lista_cheques.php')
        # Preferir el acceso real del menú cuando está disponible.
        menu=self.find_context(lambda: next((a for a in self.driver.find_elements(By.TAG_NAME,'a') if a.is_displayed() and a.text.strip().lower()=='consulta de cheques'),None))
        if menu is not None:menu.click()
        else:self.driver.get(url)
        if any(e.is_displayed() for e in self.driver.find_elements(By.ID,'password')):
            self.login(*self.access);self.driver.get(url)
        self.wait(lambda: 'Consulta Lista de Cheques' in self.driver.find_element(By.TAG_NAME,'body').text)
        return self.cheque_entries()

    def cheque_entries(self):
        empty_stable=StableDetail(seconds=1.5)
        def listing():
            if any(e.is_displayed() for e in self.driver.find_elements(By.CSS_SELECTOR,'.blockUI.blockOverlay')):
                empty_stable.observe(None,valid=False);return False
            for table in self.driver.find_elements(By.TAG_NAME,'table'):
                if not table.is_displayed():continue
                for row in table.find_elements(By.TAG_NAME,'tr'):
                    heads=row.find_elements(By.XPATH,'./th|./td')
                    labels=[heading(c) for c in heads]
                    if not all(any(word in label for label in labels) for word in ('retenc','cheque','empresa','fecha')):continue
                    boxes=table.find_elements(By.CSS_SELECTOR,'input[type=checkbox]')
                    if boxes:return table,heads
                    # Una tabla vacía también debe mantenerse estable; el título solo
                    # no demuestra que terminó de cargarse la lista.
                    if empty_stable.observe(table.text):return table,heads
                    return False
            text=self.driver.find_element(By.TAG_NAME,'body').text.lower()
            if any(t in text for t in ('no existen cheques','no se encontraron cheques','sin cheques','no hay cheques')):
                if empty_stable.observe(text):return 'EMPTY'
            else:empty_stable.observe(None,valid=False)
            return False
        self.status('Esperando la tabla de cheques pendientes...')
        try:found=self.wait(listing,60)
        except TimeoutException as exc:
            raise RuntimeError('No se cargó o reconoció la tabla de cheques en 60 segundos. No se marcó ningún cheque.') from exc
        if found=='EMPTY':return []
        table,heads=found
        def head(label):
            matches=[c for c in heads if label in heading(c)]
            if len(matches)!=1:raise RuntimeError('Encabezado de cheques ambiguo: '+label)
            return matches[0]
        cols=[head('empresa').rect,head('cheque').rect,head('fecha').rect]
        entries=[]
        for row in table.find_elements(By.TAG_NAME,'tr'):
            boxes=row.find_elements(By.CSS_SELECTOR,'input[type=checkbox]')
            if not boxes:continue
            cells=row.find_elements(By.XPATH,'./td|./th')
            values=[aligned_cell(cells,rect).text.strip() for rect in cols]
            if not all(values):raise RuntimeError('El cheque no tiene empresa, número o fecha.')
            entries.append({'key':'|'.join(values),'cheque':values[1],'fecha':values[2],'row':row,'box':boxes[0]})
        return entries

    def mark_received(self,key):
        self.check()
        entries=self.open_new_cheques()
        target=next((e for e in entries if e['key']==key),None)
        if target is None:
            raise RuntimeError('El cheque no aparece para confirmar el marcado. Revisar en Rivadavia.')
        # Desmarcar todas las demás filas: solo se envía el cheque respaldado.
        for entry in entries:
            box=entry['box']
            wanted=entry['key']==key
            if box.is_selected()!=wanted:box.click()
        self.click('Marcar recibidos')
        settled=StableDetail(seconds=1.0)
        def disappeared(_):
            # Confirmar el cambio consultando nuevamente la lista real.
            self.check()
            try:
                keys=tuple(e['key'] for e in self.cheque_entries())
                return settled.observe(keys,valid=key not in keys)
            except (StaleElementReferenceException,NoSuchFrameException,RuntimeError):
                settled.observe(None,valid=False)
                return False
        WebDriverWait(self.driver,45).until(disappeared)

    def read_cheques(self,invoice=None,wanted_key=None):
        saved=[]
        tables = self.driver.find_elements(By.TAG_NAME,'table')
        table = next((t for t in tables if 'Retención' in t.text and 'Cheque' in t.text),None)
        if table is None:
            raise RuntimeError('No se identificó la tabla de detalle de pago.')
        header_row = next((row for row in table.find_elements(By.TAG_NAME,'tr')
            if any('retenci' in cell.text.strip().lower() for cell in row.find_elements(By.XPATH,'./th|./td'))), None)
        if header_row is None:
            raise RuntimeError('No se encontró el encabezado Retención.')
        # Incluye también el TD vacío de la casilla; mezclar solo TH
        # con los TD de datos desplazaba la columna al importe bruto.
        header_cells = header_row.find_elements(By.XPATH,'./th|./td')
        def header(label):
            matches=[c for c in header_cells if label in c.text.strip().lower()]
            if len(matches)!=1:raise RuntimeError('Encabezado ambiguo: '+label)
            return matches[0]
        retention_header=header('retenci')
        cheque_header=header('cheque')
        company_header=header('empresa')
        date_header=header('fecha')
        gross_header=header('bruto')
        cheque_capture = None
        data_rows = [r for r in table.find_elements(By.TAG_NAME,'tr') if r.find_elements(By.CSS_SELECTOR,'input[type=checkbox]')]
        if not data_rows:
            raise RuntimeError('No se identificó el cheque para agrupar el respaldo.')
        for r in data_rows:
            cells = r.find_elements(By.XPATH,'./td|./th')
            retention_cell = aligned_cell(cells, retention_header.rect)
            cheque_cell = aligned_cell(cells, cheque_header.rect)
            company_cell = aligned_cell(cells, company_header.rect)
            date_cell = aligned_cell(cells, date_header.rect)
            key = '|'.join(c.text.strip() for c in [company_cell,cheque_cell,date_cell])
            if not cheque_cell.text.strip():
                raise RuntimeError('El pago no tiene identificador para agrupar el respaldo.')
            if wanted_key is not None and key!=wanted_key:continue
            cheque_capture={'title':'Listado de cheques','header':header_row.screenshot_as_png,'rows':[r.screenshot_as_png]}
            cheque_number=cheque_cell.text.strip()
            pdfs=[]
            retention_links=retention_cell.find_elements(By.TAG_NAME,'a')
            if not retention_links and any(c in '123456789' for c in retention_cell.text):
                raise RuntimeError('La retención tiene importe pero no se encontró su enlace PDF.')
            self.step='Descargar retención'
            for a in retention_links:
                pdfs.append(self.download_retention(a))
            # Al cerrar retenciones puede cambiar el contexto del frame.
            self.wait(lambda: 'Retención' in self.driver.find_element(By.TAG_NAME,'body').text)
            self.step='Abrir detalle desde Importe bruto'
            # La generación del PDF puede renovar la tabla completa.
            def fresh_gross():
                for current_table in self.driver.find_elements(By.TAG_NAME,'table'):
                    heads=current_table.find_elements(By.XPATH,'.//tr/th|.//tr/td')
                    header_cell=next((c for c in heads if c.text.strip().lower() in ('imp. bruto','importe bruto')),None)
                    if header_cell is None:continue
                    for current_row in current_table.find_elements(By.TAG_NAME,'tr'):
                        current_cells=current_row.find_elements(By.XPATH,'./td|./th')
                        if not current_cells:continue
                        if cheque_number in [c.text.strip() for c in current_cells]:
                            return aligned_cell(current_cells,header_cell.rect)
                return False
            gross_cell=self.wait(fresh_gross)
            gross_links=gross_cell.find_elements(By.TAG_NAME,'a')
            if len(gross_links)!=1:raise RuntimeError('No se identificó el enlace de Importe bruto.')
            self.step='Leer detalle completo del pago'
            paid_numbers, detail_captures = self.payment_detail(gross_links[0])
            if invoice is not None and invoice not in paid_numbers:
                raise RuntimeError('El detalle no incluye la factura buscada; no se completó el pago.')
            saved.append({'key':key,'numbers':paid_numbers,'captures':[cheque_capture]+detail_captures,'pdfs':pdfs})
            self.status('Retención descargada. Preparando el respaldo del pago...')
        return saved

    def table_capture(self,table,header,title):
        rows=table.find_elements(By.TAG_NAME,'tr')
        return {'title':title,'header':header.screenshot_as_png,'rows':[r.screenshot_as_png for r in rows if r.id!=header.id and r.is_displayed() and r.find_elements(By.XPATH,'./td|./th')]}

    def payment_detail(self,link):
        d=self.driver;old=d.current_window_handle;handles=set(d.window_handles);url=d.current_url
        link.click()
        def ready(_):
            self.check()
            for h in [h for h in d.window_handles if h not in handles]+[old]:
                d.switch_to.window(h)
                def locate():
                    for table in d.find_elements(By.TAG_NAME,'table'):
                        for row in table.find_elements(By.TAG_NAME,'tr'):
                            cells=row.find_elements(By.XPATH,'./td|./th')
                            if any(re.search(r'n[°ºo]?\.?\s*factura',c.text.lower()) for c in cells):return table,row,cells
                    return False
                found=self.find_context(locate)
                if found:
                    table,header,cells=found
                    text=table.text
                    loaded=bool(re.search(r'\b\d{1,5}\s*-\s*\d{1,8}\b',text)) and bool(re.search(r'\btotal\b',text,re.I))
                    loaded=loaded and d.execute_script('return document.readyState === "complete" && (!document.fonts || document.fonts.status === "loaded")')
                    overlays=d.find_elements(By.CSS_SELECTOR,'.blockUI.blockOverlay')
                    loaded=loaded and not any(e.is_displayed() for e in overlays)
                    rect=table.rect
                    signature=(d.current_window_handle,d.current_url,text,round(rect['width']),round(rect['height']))
                    if settled.observe(signature,valid=loaded):return found
                    return False
            return False
        numbers=[];captures=[]
        try:
            while True:
                self.step='Esperar detalle cargado y estable'
                self.status('Esperando todas las filas del detalle antes de leer y capturar...')
                settled=StableDetail()
                def safe_ready(driver):
                    try:return ready(driver)
                    except (StaleElementReferenceException,NoSuchFrameException):
                        settled.observe(None,valid=False)
                        return False
                table,header,cells=WebDriverWait(d,90,poll_frequency=0.25).until(safe_ready)
                self.step='Capturar detalle completo'
                before_text=table.text
                factura_header=next(c for c in cells if re.search(r'n[°ºo]?\.?\s*factura',c.text.lower()))
                for row in table.find_elements(By.TAG_NAME,'tr'):
                    if row.id==header.id:continue
                    cells=row.find_elements(By.XPATH,'./td|./th')
                    if not cells:continue
                    try:text=aligned_cell(cells,factura_header.rect).text.strip()
                    except RuntimeError:continue
                    for number in re.findall(r'\b\d{1,5}\s*-\s*\d{1,8}\b',text):
                        normalized=invoices(number)[0]
                        if normalized not in numbers:numbers.append(normalized)
                capture=self.table_capture(table,header,'Detalle completo del pago')
                if table.text!=before_text:
                    raise RuntimeError('El detalle cambió mientras se capturaba. Se conserva pendiente para no generar un PDF incompleto.')
                captures.append(capture)
                self.status('Detalle leído y capturado. Preparando PDF de este pago...')
                body=d.find_element(By.TAG_NAME,'body').text
                pages=re.search(r'Página\s+(\d+)\s*/\s*(\d+)',body)
                if not pages or int(pages[1])>=int(pages[2]):break
                candidates=[a for a in d.find_elements(By.TAG_NAME,'a') if a.is_displayed() and (a.text.strip() in ('›','»','>') or 'siguiente' in (a.get_attribute('title') or '').lower())]
                if len(candidates)!=1:raise RuntimeError('El detalle tiene más páginas y no se identificó Siguiente. Se mantiene pendiente.')
                before=header
                candidates[0].click()
                WebDriverWait(d,30).until(lambda _: ('Página '+str(int(pages[1])+1)) in d.find_element(By.TAG_NAME,'body').text)
            if not numbers:raise RuntimeError('No se encontraron números de factura en el detalle del pago.')
            return numbers,captures
        finally:
            for h in list(d.window_handles):
                if h not in handles:d.switch_to.window(h);d.close()
            d.switch_to.window(old)
            if d.current_url!=url:d.get(url)

    def payment_links(self):
        self.wait(lambda: self.links('Consulta'))
        return [e for e in self.driver.find_elements(By.TAG_NAME,'a') if e.is_displayed() and e.text.strip()=='Consulta']
    def capture(self):
        # CDP captura el documento superior con todos sus frames visibles.
        d=self.driver
        metrics=d.execute_cdp_cmd('Page.getLayoutMetrics', {})
        size=metrics.get('cssContentSize',metrics['contentSize'])
        return base64.b64decode(d.execute_cdp_cmd('Page.captureScreenshot', {'captureBeyondViewport':True,'fromSurface':True,'clip':{'x':0,'y':0,'width':size['width'],'height':size['height'],'scale':1}})['data'])
    def download_retention(self, link):
        d=self.driver
        old=d.current_window_handle
        handles=set(d.window_handles)
        href=link.get_attribute('href') or ''
        parsed = urlparse(href)
        # El enlace ejecuta la generación; no es el PDF descargable todavía.
        if not (parsed.scheme in ('http','https') and parsed.path.lower().endswith('.pdf')):
            self.status('Generando comprobante de retención. Esperando el PDF...')
            link.click()
            def popup_ready(_):
                self.check()
                for handle in d.window_handles:
                    if handle not in handles:
                        d.switch_to.window(handle)
                        url=d.current_url
                        if urlparse(url).path.lower().endswith('.pdf'):
                            return url
                        # Algunos visores alojan el archivo dentro de embed/iframe.
                        for embedded in d.find_elements(By.CSS_SELECTOR,'embed[src],iframe[src]'):
                            url=embedded.get_attribute('src') or ''
                            if urlparse(url).path.lower().endswith('.pdf'):return url
                d.switch_to.window(old)
                return False
            href=WebDriverWait(d,120).until(popup_ready)
        url=urljoin(d.current_url,href)
        host=urlparse(url).hostname or ''
        if not (host=='segurosrivadavia.com' or host.endswith('.segurosrivadavia.com')):
            raise RuntimeError('Destino de retención inesperado.')
        cookie='; '.join(c['name']+'='+c['value'] for c in d.get_cookies() if host.endswith(c['domain'].lstrip('.')))
        request=urllib.request.Request(url, headers={'Cookie':cookie,'User-Agent':d.execute_script('return navigator.userAgent')})
        try:
            with urllib.request.urlopen(request,timeout=60) as response:
                raw=response.read()
            if not raw.startswith(b'%PDF-'):
                raise RuntimeError('El enlace no devolvió un PDF de retención válido.')
            return raw
        finally:
            if d.current_window_handle!=old:
                d.close(); d.switch_to.window(old)
