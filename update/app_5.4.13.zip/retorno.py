"""Restaura únicamente los archivos de aplicación de V5.3.4."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile

def restore(pid):
    root=Path(__file__).resolve().parent
    # Espera a que cierre la interfaz antes de reemplazar sus archivos.
    time.sleep(3)
    stamp=time.strftime('%Y%m%d_%H%M%S')
    backup=root.parent/('respaldo_antes_retorno_'+stamp)
    shutil.copytree(root,backup)
    with zipfile.ZipFile(root/'respaldo'/'5.3.4.zip') as z:
        for info in z.infolist():
            target=(root/info.filename).resolve()
            if not target.is_relative_to(root):raise ValueError('Ruta inválida en respaldo')
        z.extractall(root)
    # Abre directamente V5.3.4 sin ejecutar la búsqueda de actualizaciones.
    subprocess.Popen([sys.executable,str(root/'interfaz.py')],cwd=root)

if __name__=='__main__':restore(int(sys.argv[1]))
