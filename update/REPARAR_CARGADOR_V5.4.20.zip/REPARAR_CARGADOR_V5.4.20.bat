@echo off
chcp 65001 >nul
setlocal
set "DEST=%LOCALAPPDATA%\CargadorFacturasAutosur\App"
if not exist "%DEST%" (
  echo No se encontro la aplicacion en: %DEST%
  echo Instala o abre el Cargador de facturas Autosur y volve a ejecutar este reparador.
  pause
  exit /b 1
)
echo Cerrando el cargador si esta abierto...
taskkill /F /IM pythonw.exe >nul 2>&1
taskkill /F /IM python.exe >nul 2>&1
if exist "%DEST%\interfaz_pagos.py" copy /Y "%DEST%\interfaz_pagos.py" "%DEST%\interfaz_pagos.py.antes_v5.4.20" >nul
copy /Y "%~dp0interfaz_pagos.py" "%DEST%\interfaz_pagos.py" >nul || goto :error
copy /Y "%~dp0version.txt" "%DEST%\version.txt" >nul || goto :error
echo.
echo Reparacion V5.4.20 aplicada correctamente.
echo Volve a abrir el Cargador de facturas Autosur.
pause
exit /b 0
:error
echo.
echo No se pudo aplicar la reparacion. Cerra la aplicacion y ejecuta este archivo otra vez.
pause
exit /b 1
