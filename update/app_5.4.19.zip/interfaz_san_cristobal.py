import html
import json
import os
import threading
import time
import urllib.parse
from pathlib import Path

import san_cristobal as motor


EDITABLE = [
    ("punto_venta", "Punto"), ("numero", "Comprobante"),
    ("siniestro", "Siniestro"), ("neto", "Neto"), ("iva", "IVA"),
    ("total", "Total"), ("fecha", "Fecha"), ("cae", "CAE"),
    ("tipo_comprobante", "Tipo"), ("letra", "Letra"),
]


class AppState:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.lock = threading.Lock()
        self.rows = []
        self.message = ""
        self.running = False
        self.waiting_review = False
        self.promote_to_batch = threading.Event()
        self.worker_thread = None
        self.corrections_path = self.folder / "correcciones_san_cristobal.json"
        self.load()

    def corrections(self):
        try:
            return json.loads(self.corrections_path.read_text(encoding="utf-8"))
        except Exception:
            return {}

    def load(self):
        self.folder.mkdir(parents=True, exist_ok=True)
        saved = self.corrections()
        sent = motor.sent_numbers(self.folder)
        rows = []
        for path in sorted(self.folder.glob("*.pdf")):
            try:
                invoice = motor.parse_invoice(path, strict=False)
                for key, value in saved.get(path.name, {}).items():
                    if hasattr(invoice, key) and value:
                        setattr(invoice, key, value)
                valid, reason = invoice.validate()
                status = "ENVIADA" if invoice.factura in sent else "VALIDADA" if valid else "REVISAR"
                rows.append({"invoice": invoice, "valid": valid, "reason": reason, "status": status})
            except Exception as exc:
                invoice = motor.Invoice(archivo=str(path.resolve()))
                rows.append({"invoice": invoice, "valid": False, "reason": str(exc), "status": "REVISAR"})
        with self.lock:
            self.rows = rows

    def save_form(self, values):
        corrections = self.corrections()
        with self.lock:
            for index, row in enumerate(self.rows):
                invoice = row["invoice"]
                file_data = corrections.setdefault(Path(invoice.archivo).name, {})
                for key, _label in EDITABLE:
                    value = (values.get(f"r{index}_{key}", [""])[0] or "").strip()
                    if key in ("neto", "iva", "total"):
                        value = motor.money_text(value)
                    elif key == "siniestro":
                        value = motor.normalize_claim(value)
                    elif key == "punto_venta":
                        value = motor.only_digits(value).zfill(4) if value else ""
                    elif key == "numero":
                        value = motor.only_digits(value).zfill(8) if value else ""
                    elif key == "fecha" and value:
                        value = motor.normalize_date(value)
                    setattr(invoice, key, value)
                    file_data[key] = value
                valid, reason = invoice.validate()
                status = "ENVIADA" if row["status"] == "ENVIADA" else "VALIDADA" if valid else "REVISAR"
                row.update(valid=valid, reason=reason, status=status)
        self.corrections_path.write_text(json.dumps(corrections, ensure_ascii=False, indent=2), encoding="utf-8")

    def save_credentials(self, values):
        username = (values.get("username", [""])[0] or "").strip()
        password = values.get("password", [""])[0] or ""
        if not password:
            self.message = "Ingresá la contraseña para guardar las credenciales."
            return
        try:
            motor.save_credentials(username, password)
            self.message = "Credenciales guardadas de forma cifrada en Windows."
        except Exception as exc:
            self.message = "No pude guardar las credenciales: " + str(exc)

    def mark_sent(self, index):
        with self.lock:
            if self.running:
                self.message = "Esperá a que termine la carga actual."
                return
            if index < 0 or index >= len(self.rows):
                self.message = "No encontré la factura seleccionada."
                return
            row = self.rows[index]
            invoice = row["invoice"]
        try:
            motor.register(invoice, self.folder, "ENVIADA", "Marcada manualmente desde la interfaz")
            motor.move_sent(invoice, self.folder)
            with self.lock:
                row["status"] = "ENVIADA"
                row["reason"] = ""
                self.message = f"{invoice.factura} fue marcada como enviada."
        except Exception as exc:
            self.message = f"No pude marcar {invoice.factura}: {exc}"

    def capture_error(self, driver, invoice, error=None):
        try:
            user_profile = Path(os.environ.get("USERPROFILE", str(Path.home())))
            folder = user_profile / "Desktop" / "ERRORES_CARGADOR"
            folder.mkdir(parents=True, exist_ok=True)
            safe = (invoice.factura or Path(invoice.archivo).stem).replace("/", "-")
            stamp = time.strftime('%Y%m%d_%H%M%S')
            driver.save_screenshot(str(folder / f"{safe}_{stamp}.png"))
            (folder / f"{safe}_{stamp}.txt").write_text(
                f"Factura: {invoice.factura}\nArchivo: {invoice.archivo}\n"
                f"URL: {driver.current_url}\nError: {error or 'sin detalle'}\n",
                encoding="utf-8",
            )
            diagnostic = driver.execute_script("""
                const visible=el=>{
                    const r=el.getBoundingClientRect(), s=getComputedStyle(el);
                    return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden';
                };
                const months=['enero','febrero','marzo','abril','mayo','junio',
                    'julio','agosto','septiembre','setiembre','octubre','noviembre','diciembre'];
                const nodes=[...document.querySelectorAll('div,span,button,td')];
                const month=nodes.find(el=>visible(el) && months.includes((el.textContent||'').trim().toLowerCase()));
                let root=month;
                while(root && root!==document.body){
                    const r=root.getBoundingClientRect();
                    const nums=[...root.querySelectorAll('button,[role="button"],td,span,div')]
                        .filter(el=>visible(el) && /^\\d{1,2}$/.test((el.textContent||'').trim()));
                    if(nums.length>=20 && r.width>=200 && r.width<=500 && r.height>=180 && r.height<=550)break;
                    root=root.parentElement;
                }
                root=root || document.body;
                const items=[...root.querySelectorAll('*')].filter(el=>{
                    if(!visible(el))return false;
                    const text=(el.textContent||'').trim();
                    return ['BUTTON','SVG','PATH','TD'].includes(el.tagName) ||
                        el.getAttribute('role') || /^\\d{1,4}$/.test(text) || months.includes(text.toLowerCase());
                }).slice(0,500).map(el=>{
                    const r=el.getBoundingClientRect();
                    return {
                        tag:el.tagName,text:(el.textContent||'').trim(),class:el.getAttribute('class'),
                        role:el.getAttribute('role'),ariaLabel:el.getAttribute('aria-label'),
                        title:el.getAttribute('title'),disabled:el.getAttribute('disabled'),
                        x:Math.round(r.x),y:Math.round(r.y),width:Math.round(r.width),height:Math.round(r.height),
                        html:el.outerHTML.slice(0,2000)
                    };
                });
                return {url:location.href, rootHtml:root.outerHTML, items};
            """)
            (folder / f"{safe}_{stamp}_calendario.json").write_text(
                json.dumps(diagnostic, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            (folder / f"{safe}_{stamp}_pagina.html").write_text(
                driver.page_source, encoding="utf-8"
            )
        except Exception:
            pass

    def run(self, submit):
        with self.lock:
            if self.running:
                if submit and self.waiting_review and self.worker_thread:
                    self.message = "Enviando la prueba y continuando el lote..."
                    self.promote_to_batch.set()
                else:
                    self.message = "Ya hay una carga en curso."
                return
            targets = [row for row in self.rows if row["valid"] and row["status"] != "ENVIADA"]
            if not targets:
                self.message = "No hay facturas validadas pendientes."
                return
            self.running = True
            self.waiting_review = False
            self.promote_to_batch = threading.Event()
            promote = self.promote_to_batch
            self.message = "Abriendo Chrome y preparando San Cristóbal..."

        def worker():
            driver = None
            sent = errors = 0
            batch_mode = submit
            try:
                driver = motor.start_chrome()
                for position, row in enumerate(targets, 1):
                    invoice = row["invoice"]
                    row["status"] = "CARGANDO"
                    self.message = f"Cargando {position} de {len(targets)}: {invoice.factura}..."
                    try:
                        result = motor.complete_invoice(driver, invoice, submit=False, status=lambda msg: setattr(self, "message", msg))
                        if batch_mode:
                            if result != "LISTA_PARA_REVISAR":
                                raise RuntimeError("la factura no llegó a la revisión final")
                            result = motor.submit_prepared(driver, prepare_next=True)
                        if result == "LISTA_PARA_REVISAR":
                            row["status"] = "LISTA PARA REVISAR"
                            self.message = f"{invoice.factura} está completa. Revisala y presioná Enviar, o iniciá el lote."
                            with self.lock:
                                self.waiting_review = True
                            deadline = time.time() + 1800
                            manual = False
                            while time.time() < deadline:
                                if motor.response_recorded(driver):
                                    motor.register(invoice, self.folder, "ENVIADA")
                                    motor.move_sent(invoice, self.folder)
                                    row["status"] = "ENVIADA"
                                    self.message = f"{invoice.factura} fue enviada y registrada."
                                    sent += 1
                                    manual = True
                                    break
                                if promote.is_set():
                                    with self.lock:
                                        self.waiting_review = False
                                    batch_mode = True
                                    result = motor.submit_prepared(driver, prepare_next=True)
                                    break
                                time.sleep(0.75)
                            with self.lock:
                                self.waiting_review = False
                            if manual:
                                break
                            if result == "LISTA_PARA_REVISAR":
                                row["status"] = "VALIDADA"
                                self.message = "La prueba quedó pendiente de envío."
                                break
                        motor.register(invoice, self.folder, "ENVIADA")
                        motor.move_sent(invoice, self.folder)
                        row["status"] = "ENVIADA"
                        sent += 1
                    except Exception as exc:
                        row["status"] = "ERROR"
                        row["reason"] = str(exc)
                        motor.register(invoice, self.folder, "ERROR", str(exc))
                        self.capture_error(driver, invoice, exc)
                        errors += 1
                        if batch_mode and position < len(targets):
                            try:
                                motor.reset_for_next(driver, status=lambda msg: setattr(self, "message", msg))
                            except Exception as recovery_error:
                                row["reason"] += " | No se pudo recuperar el portal: " + str(recovery_error)
                                self.message = "El lote se detuvo para evitar cargar la próxima factura en una pantalla incorrecta."
                                break
                if batch_mode:
                    self.message = f"Proceso terminado: {sent} enviadas y {errors} con error."
            except Exception as exc:
                self.message = "No se pudo iniciar la carga: " + str(exc)
            finally:
                with self.lock:
                    self.waiting_review = False
                    self.running = False
                    if self.worker_thread is threading.current_thread():
                        self.worker_thread = None

        thread = threading.Thread(target=worker, daemon=True)
        with self.lock:
            self.worker_thread = thread
        thread.start()


STYLE = """
:root{font-family:Segoe UI,Arial,sans-serif;color:#172033;background:#f1f3fa}*{box-sizing:border-box}body{margin:0}
.top{background:#20228a;color:white;padding:20px 28px}.top h1{margin:0;font-size:25px}.top p{margin:6px 0 0;opacity:.88}.top a{color:white}
.wrap{max-width:1550px;margin:20px auto;padding:0 18px}.panel{background:white;border-radius:14px;box-shadow:0 4px 18px #18224d18;padding:18px;margin-bottom:16px}
.notice{padding:12px 15px;background:#eef0ff;border-left:4px solid #4448ed;border-radius:7px;margin-bottom:15px}.credentials{display:flex;gap:10px;align-items:end;flex-wrap:wrap}.credentials label{font-size:12px;color:#536078}.credentials input{display:block;margin-top:5px;width:260px}
.table-wrap{overflow:auto;border:1px solid #dce1ed;border-radius:10px}table{border-collapse:collapse;width:100%;min-width:1500px}th{background:#eef0fb;text-align:left;font-size:12px;color:#505b76;padding:10px;position:sticky;top:0}td{padding:9px;border-top:1px solid #e6e8f1;vertical-align:top}
input{width:130px;border:1px solid #bdc5d6;border-radius:6px;padding:8px;font-size:13px}input.wide{width:165px}.file{min-width:150px;font-weight:600}.reason{font-size:12px;color:#a12424;max-width:230px}
.badge{display:inline-block;padding:5px 8px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap}.ok{background:#dff6e8;color:#146c3b}.bad{background:#ffe4e3;color:#a12424}.sent{background:#e2e9ff;color:#2647a1}.work{background:#fff0c9;color:#875d00}
.actions{display:flex;gap:10px;align-items:center;margin-top:16px;flex-wrap:wrap}button{border:0;border-radius:8px;padding:11px 18px;font-weight:700;cursor:pointer}.save{background:#e5e8f5;color:#25315f}.test{background:#f5b942;color:#4b3500}.send{background:#4145e7;color:white}.reload{background:#dcefe5;color:#17613b}.summary{margin-left:auto;color:#4d5b6a;font-weight:600}.manual{display:block;margin-top:8px;padding:7px 9px;background:#fff1cc;color:#765300;font-size:11px}.hint{color:#657086;font-size:12px}
"""


def render(state):
    with state.lock:
        rows = list(state.rows)
        running = state.running
    try:
        username, stored_password = motor.load_credentials()
    except Exception:
        username, stored_password = "", ""
    body_rows = []
    for index, row in enumerate(rows):
        invoice = row["invoice"]
        status = row["status"]
        css = "sent" if status == "ENVIADA" else "ok" if status == "VALIDADA" else "work" if status in ("CARGANDO", "LISTA PARA REVISAR") else "bad"
        cells = [f'<td class="file">{html.escape(Path(invoice.archivo).name)}</td>']
        for key, _label in EDITABLE:
            value = html.escape(str(getattr(invoice, key)))
            wide = " wide" if key in ("siniestro", "cae", "tipo_comprobante") else ""
            cells.append(f'<td><input class="{wide}" name="r{index}_{key}" value="{value}"></td>')
        manual = "" if status == "ENVIADA" or running else (
            f'<button class="manual" name="action" value="mark_sent:{index}" '
            f'onclick="return confirm(\'¿Confirmás que {html.escape(invoice.factura or Path(invoice.archivo).name)} ya fue enviada?\')">Marcar enviada</button>'
        )
        reason = row["reason"] if not row["valid"] or status == "ERROR" else ""
        cells.append(f'<td><span class="badge {css}">{html.escape(status)}</span>{manual}<div class="reason">{html.escape(reason)}</div></td>')
        body_rows.append("<tr>" + "".join(cells) + "</tr>")
    headers = "".join(f"<th>{html.escape(label)}</th>" for _key, label in EDITABLE)
    valid = sum(1 for row in rows if row["valid"] and row["status"] != "ENVIADA")
    invalid = sum(1 for row in rows if not row["valid"])
    message = f'<div class="notice">{html.escape(state.message)}</div>' if state.message else ""
    refresh = '<meta http-equiv="refresh" content="8">' if state.running else ""
    password_label = "Contraseña guardada" if stored_password else "Sin contraseña guardada"
    return f"""<!doctype html><html><head><meta charset="utf-8">{refresh}<title>San Cristóbal · Cargador V5.4.14</title><style>{STYLE}</style></head><body>
    <div class="top"><h1>San Cristóbal · Cargador V5.4.14</h1><p><a href="http://127.0.0.1:__HOME_PORT__/">← Plataformas</a> · {html.escape(str(state.folder))}</p></div>
    <div class="wrap">{message}<div class="panel"><form method="post"><div class="credentials">
    <label>CUIT de acceso<input name="username" value="{html.escape(username)}" placeholder="30-61532797-9"></label>
    <label>Contraseña<input type="password" name="password" placeholder="{password_label}"></label>
    <button class="save" name="action" value="credentials">Guardar credenciales</button>
    <span class="hint">Se guardan cifradas para tu usuario de Windows. Si aparece CAPTCHA, completalo en Chrome y la carga continuará.</span>
    </div></form></div><div class="panel"><form method="post"><div class="table-wrap"><table><thead><tr><th>Archivo</th>{headers}<th>Resultado</th></tr></thead><tbody>{''.join(body_rows)}</tbody></table></div>
    <div class="actions"><button class="reload" name="action" value="reload">Actualizar carpeta</button><button class="save" name="action" value="save">Guardar y validar</button><button class="test" name="action" value="test">Probar primera sin enviar</button><button class="send" name="action" value="batch" onclick="return confirm('¿Confirmás el envío automático del lote validado a San Cristóbal?')">Enviar lote validado</button><span class="summary">Validadas: {valid} · Para revisar: {invalid}</span></div></form></div></div></body></html>"""


def handler_for(state, home_port):
    from http.server import BaseHTTPRequestHandler

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _format, *_args):
            pass

        def do_GET(self):
            page = render(state).replace("__HOME_PORT__", str(home_port)).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(page)))
            self.end_headers()
            self.wfile.write(page)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0"))
            values = urllib.parse.parse_qs(self.rfile.read(length).decode("utf-8"), keep_blank_values=True)
            action = values.get("action", ["save"])[0]
            if action == "credentials":
                state.save_credentials(values)
            elif action.startswith("mark_sent:"):
                if not state.running:
                    state.save_form(values)
                try:
                    state.mark_sent(int(action.split(":", 1)[1]))
                except Exception:
                    state.message = "No pude identificar la factura."
            else:
                state.save_form(values)
                if action == "reload":
                    if state.running:
                        state.message = "Esperá a que termine la carga antes de actualizar."
                    else:
                        state.load()
                        state.message = "Carpeta actualizada y PDF revisados nuevamente."
                elif action == "test":
                    state.run(False)
                elif action == "batch":
                    state.run(True)
                else:
                    state.message = "Datos guardados y validados."
            self.send_response(303)
            self.send_header("Location", "/")
            self.end_headers()

    return Handler

